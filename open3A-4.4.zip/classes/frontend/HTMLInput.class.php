<?php
/*
 *  This file is part of phynx.

 *  phynx is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  phynx is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;
class HTMLInput {
	private $type;
	private $name;
	private $value;
	private $options;
	private $onclick = null;
	private $onchange = null;
	private $oninput = null;
	#private $onblur = null;
	protected $style = null;
	private $id = null;
	private $onkeyup = "";
	private $onkeydown = null;
	private $isSelected = false;
	protected $isDisabled = false;
	private $isDisplayMode = false;
	private $tabindex;
	private $multiEditOptions;
	private $autocompleteBrowser = true;
	protected $onblur;
	protected $onenter;
	private $onfocus;
	private $className;
	private $requestFocus = "";
	private $autocomplete;
	private $connectTo;
	private $placeholder;
	private $callback;
	private $maxlength;
	private $size;
	private $rows;
	private $autocorrect = true;
	private $spellcheck = true;
	private $title;
	private $parentValue;
	private $data = array();
	private $inputmode;
	private $buttonClear = false;
	private $buttonKeyboard = false;
	private $buttonKeyboardStyle = "margin-left:-30px;color:grey;";
	private $buttonClearStyle = "margin-left:-30px;color:grey;";
	private $buttonClearAction;
	private $required = false;
	private $requiredPattern;
	private $min;
	private $max;
	private $step;
	
	public function parentValue($PV){
		$this->parentValue = $PV;
	}
	
	public function __construct($name, $type = "text", $value = null, $options = null){
		$this->name = $name;
		$this->type = $type;
		$this->value = $value;
		$this->options = $options;
	}

	public function title($title){
		$this->title = $title;
	}
	
	public function data($key, $value){
		$this->data[$key] = $value;
	}
	
	public function maxlength($length){
		$this->maxlength = $length;
	}
	
	public function size($size){
		$this->size = $size;
	}
	
	public function rows($rows){
		$this->rows = $rows;
		$this->style .= "min-height:auto;height:auto;";
	}
	
	public function autocomplete($targetClass, $onSelectionFunction = null, $hideOnSelection = false, $getACData3rdParameter = null, ?Button $ButtonEmptyValues = null){
		$cal = new Button("Suche", "./images/i2/details.png", "icon");
					
		$this->autocomplete = array($targetClass, $onSelectionFunction, $hideOnSelection, $getACData3rdParameter == null ? "null" : $getACData3rdParameter, $ButtonEmptyValues, $cal);
		
		return $cal;
	}
	
	public function autocorrect($bool){
		$this->autocorrect = $bool;
	}
	
	public function spellcheck($bool){
		$this->spellcheck = $bool;
	}
	
	public function setType($type){
		$this->type = $type;
	}
	
	public function getName(){
		return $this->name;
	}
	
	public function setName($name){
		$this->name = $name;
	}
	
	public function getType(){
		return $this->type;
	}
	
	public function placeholder($text){
		$this->placeholder = T::_($text);
	}

	public function setClass($className){
		$this->className = $className;
	}

	public function activateMultiEdit($targetClass, $targetClassID, $onSuccessFunction = "", $doBefore = null){
		if(strpos($onSuccessFunction, "function(") !== 0)
				$onSuccessFunction = "function(transport){ $onSuccessFunction }";
		
		$this->multiEditOptions = array($targetClass, $targetClassID, $onSuccessFunction, $doBefore);
	}

	public function setOptions($options, $labelField = null, $zeroEntry = "Bitte auswählen…", $additionalOptions = null){
		if(is_object($options) AND $options instanceof Collection AND $labelField != null){
			if($zeroEntry !== null)
				$this->options = array("0" => $zeroEntry);
			else
				$this->options = array();
			
			while($t = $options->getNextEntry())
				$this->options[$t->getID()] = $t->A($labelField);
		} else
			$this->options = $options;
		
		if($additionalOptions != null)
			foreach($additionalOptions AS $k => $v)
				$this->options[$k] = $v;
	}

	public function autocompleteBrowser($value){
		$this->autocompleteBrowser = $value;
	}

	public function tabindex($index){
		$this->tabindex = $index;
	}

	public function isDisplayMode($b){
		$this->isDisplayMode = $b;
	}

	public function id($id){
		$this->id = $id;
	}

	public function getID($createRandom = false){
		if($createRandom AND $this->id === null)
			$this->id = $this->name.($this->autocomplete === null ? "_".random_int (100, 100000) : "");
			
		return $this->id;
	}
	
	public function style($style){
		$this->style = $style;
	}

	public function onclick($function){
		$this->onclick = $function;
	}

	public function oninput($function){
		$this->oninput = $function;
	}

	public function onchange($function){
		$this->onchange = $function;
	}

	public function onblur($function){
		$this->onblur = $function;
	}

	public function onfocus($function){
		$this->onfocus = $function;
	}

	public function onkeyup($function){
		$this->onkeyup .= $function;
	}

	public function onkeydown($function){
		$this->onkeydown = $function;
	}

	public function getValue(){
		return $this->value;
	}

	public function requestFocus($setToLast = false){
		if($this->id === null)
			$this->id = "Field".rand(100, 1000000);
		
		$this->requestFocus = "<script type=\"text/javascript\">setTimeout(function() { \$j('#$this->id').trigger('focus'); ".($setToLast ? "var strLength = \$j('#$this->id').val().length; \$j('#$this->id')[0].setSelectionRange(strLength, strLength);;" : "")." }, 200);</script>";
	}
	
	public function onEnter($function){
		$this->onkeyup .= "if(event.keyCode == 13) { ".$function." }";
		$this->onenter = $function;
	}
	
	public function onDoneNext($formID){
		$next = "var fields = document.$formID.elements; for(var i = 0; i < fields.length; i++) { if(fields[i] == this){ if(fields[i].value == '') return false; fields[i+1].focus(); return false; } }";
		if($this->type == "select"){
			$this->onchange($next);
			return;
		}
		
		$this->onkeydown .= "if(event.keyCode == 13) { ".$next." }";
		#$this->onEnter($next);
	}
	
	public function mode($mode){
		$this->inputmode = $mode;
	}
	
	public function buttonClear($style = null, $action = null){
		$this->buttonClear = true;
		$this->buttonClearStyle = $style;
		$this->buttonClearAction = $action;
	}
	
	public function buttonKeyboard($style = null){
		$this->buttonKeyboard = true;
		$this->buttonKeyboardStyle = $style;
	}

	public function isSelected($bool){
		$this->isSelected = $bool;
	}
	
	public function min($min){
		$this->min = $min;
	}
	
	public function step($step){
		$this->step = $step;
	}
	
	public function max($max){
		$this->max = $max;
	}
	
	public function required($pattern = null){
		$this->required = true;
		$this->requiredPattern = $pattern;
	}
	
	public function pattern($pattern = null){
		$this->requiredPattern = $pattern;
	}

	public function setValue($v){
		$this->value = $v;
	}

	public function getCallback(){
		return $this->callback;
	}
	
	public function isDisabled($bool){
		$this->isDisabled = $bool;
	}
	
	public function connectTo($elementID){
		$this->connectTo = $elementID;
	}

	public function  __toString() {
		#$style = "";
		if($this->type == "date" AND strpos($this->style."", "width:") === false) $this->style .= "width:calc(100% - 28px);";
		#if($this->style != null) $style = " style=\"$this->style\"";

		switch($this->type){
			/*case "JSONMultiText":
				$data = json_decode($this->value);
				
				print_r($data);
				
				$L = new HTMLList();
				$L->noDots();
				$L->addListStyle("padding:0px;");
				
				foreach($data AS $k => $v){
					$IL = new HTMLInput($this->name."_$k", "text", $v);
					$BL = new Button("Element hinzufügen");
					$L->addItem($IL);
					$L->addItemStyle("margin-left:0px;");
				}
				
				$I = new HTMLInput($this->name, "textarea", $this->value);
				$I->id($this->name);
				
				return $L.$I;
			break;*/
			
			case "colorHSL":
				#$this->value = "hsl(100 50% 50%)";
				if(preg_match_all("/hsl\(([0-9]{1,3})\s+([0-9]{1,3})\%\s+([0-9]{1,3})\%\)/ismU", $this->value, $matches)){
					$vHue = $matches[1][0];
					$vSat = $matches[2][0];
					$vBri = $matches[3][0];
				} else {
					$vHue = 266;
					$vSat = 100;
					$vBri = 50;
					$this->value = "hsl($vHue $vSat% $vBri%)";
				}
				$style = "<style type=\"text/css\" id=\"".$this->name."Style\">.{$this->name}Picker { --picker-hue:$vHue; --picker-saturation:$vSat; --picker-luminosity:$vBri; }</style>";
				
				$oninput = "\$j('[name=".$this->name."]').val('hsl('+\$j('[name=".$this->name."HUE]').val()+' '+\$j('[name=".$this->name."Saturation]').val()+'% '+\$j('[name=".$this->name."Brightness]').val()+'%)').trigger('input').trigger('keydown'); \$j('#".$this->name."Style').html('.{$this->name}Picker { --picker-hue: '+\$j('[name=".$this->name."HUE]').val()+'; --picker-saturation: '+\$j('[name=".$this->name."Saturation]').val()+'; --picker-luminosity: '+\$j('[name=".$this->name."Brightness]').val()+';');";
				
				$hue = '<input name="'.$this->name.'HUE" type="range" class="color-slider" min="0" max="360" value="'.$vHue.'" style="width:100%;--_slider-thumb-width:5px;background: linear-gradient(to right, hsl(0 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(1 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(2 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(3 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(4 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(5 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(6 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(7 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(8 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(9 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(10 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(11 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(12 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(13 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(14 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(15 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(16 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(17 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(18 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(19 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(20 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(21 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(22 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(23 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(24 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(25 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(26 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(27 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(28 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(29 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(30 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(31 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(32 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(33 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(34 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(35 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(36 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(37 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(38 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(39 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(40 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(41 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(42 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(43 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(44 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(45 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(46 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(47 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(48 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(49 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(50 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(51 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(52 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(53 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(54 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(55 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(56 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(57 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(58 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(59 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(60 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(61 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(62 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(63 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(64 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(65 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(66 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(67 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(68 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(69 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(70 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(71 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(72 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(73 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(74 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(75 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(76 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(77 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(78 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(79 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(80 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(81 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(82 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(83 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(84 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(85 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(86 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(87 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(88 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(89 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(90 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(91 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(92 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(93 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(94 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(95 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(96 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(97 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(98 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(99 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(100 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(101 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(102 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(103 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(104 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(105 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(106 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(107 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(108 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(109 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(110 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(111 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(112 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(113 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(114 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(115 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(116 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(117 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(118 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(119 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(120 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(121 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(122 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(123 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(124 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(125 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(126 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(127 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(128 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(129 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(130 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(131 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(132 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(133 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(134 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(135 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(136 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(137 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(138 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(139 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(140 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(141 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(142 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(143 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(144 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(145 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(146 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(147 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(148 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(149 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(150 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(151 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(152 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(153 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(154 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(155 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(156 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(157 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(158 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(159 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(160 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(161 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(162 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(163 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(164 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(165 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(166 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(167 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(168 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(169 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(170 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(171 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(172 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(173 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(174 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(175 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(176 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(177 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(178 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(179 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(180 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(181 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(182 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(183 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(184 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(185 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(186 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(187 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(188 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(189 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(190 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(191 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(192 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(193 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(194 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(195 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(196 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(197 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(198 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(199 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(200 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(201 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(202 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(203 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(204 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(205 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(206 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(207 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(208 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(209 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(210 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(211 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(212 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(213 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(214 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(215 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(216 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(217 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(218 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(219 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(220 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(221 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(222 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(223 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(224 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(225 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(226 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(227 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(228 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(229 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(230 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(231 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(232 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(233 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(234 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(235 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(236 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(237 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(238 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(239 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(240 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(241 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(242 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(243 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(244 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(245 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(246 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(247 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(248 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(249 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(250 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(251 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(252 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(253 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(254 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(255 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(256 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(257 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(258 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(259 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(260 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(261 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(262 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(263 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(264 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(265 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(266 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(267 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(268 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(269 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(270 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(271 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(272 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(273 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(274 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(275 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(276 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(277 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(278 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(279 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(280 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(281 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(282 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(283 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(284 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(285 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(286 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(287 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(288 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(289 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(290 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(291 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(292 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(293 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(294 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(295 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(296 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(297 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(298 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(299 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(300 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(301 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(302 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(303 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(304 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(305 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(306 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(307 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(308 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(309 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(310 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(311 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(312 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(313 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(314 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(315 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(316 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(317 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(318 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(319 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(320 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(321 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(322 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(323 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(324 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(325 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(326 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(327 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(328 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(329 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(330 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(331 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(332 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(333 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(334 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(335 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(336 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(337 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(338 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(339 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(340 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(341 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(342 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(343 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(344 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(345 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(346 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(347 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(348 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(349 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(350 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(351 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(352 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(353 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(354 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(355 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(356 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(357 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(358 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(359 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)), hsl(360 calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%)));" oninput="'.$oninput.'" />';
				$saturation = '<input name="'.$this->name.'Saturation" type="range" class="color-slider" min="0" max="100" value="'.$vSat.'" style="width:100%;margin-top:5px;--_slider-thumb-width:5px;background: linear-gradient(to right in hsl, hsl(var(--picker-hue) 0% calc(var(--picker-luminosity) * 1%)), hsl(var(--picker-hue) 50% calc(var(--picker-luminosity) * 1%)), hsl(var(--picker-hue) 100% calc(var(--picker-luminosity) * 1%)));" oninput="'.$oninput.'" />';
				$brightness = '<input name="'.$this->name.'Brightness" type="range" class="color-slider" min="0" max="100" value="'.$vBri.'" style="width:100%;margin-top:5px;--_slider-thumb-width:5px;background: linear-gradient(to right in hsl, hsl(var(--picker-hue) calc(var(--picker-saturation) * 1%) 0%), hsl(var(--picker-hue) calc(var(--picker-saturation) * 1%) 10%), hsl(var(--picker-hue) calc(var(--picker-saturation) * 1%) 20%), hsl(var(--picker-hue) calc(var(--picker-saturation) * 1%) 30%), hsl(var(--picker-hue) calc(var(--picker-saturation) * 1%) 40%), hsl(var(--picker-hue) calc(var(--picker-saturation) * 1%) 50%), hsl(var(--picker-hue) calc(var(--picker-saturation) * 1%) 60%), hsl(var(--picker-hue) calc(var(--picker-saturation) * 1%) 70%), hsl(var(--picker-hue) calc(var(--picker-saturation) * 1%) 80%), hsl(var(--picker-hue) calc(var(--picker-saturation) * 1%) 90%), hsl(var(--picker-hue) calc(var(--picker-saturation) * 1%) 100%));" oninput="'.$oninput.'" />';
				
				$I = new HTMLInput($this->name, "text", $this->value);
				$I->style("transition:background-color .1s; background-color:hsl(var(--picker-hue) calc(var(--picker-saturation) * 1%) calc(var(--picker-luminosity) * 1%))");
				$I->oninput($this->oninput);
				
				$B = new Button("Farbe wählen", "./images/i2/colorWheel.png", "icon");
				$B->style("float:right;");
				$B->addClass("mouseoverFade ");
				$B->onclick("\$j('#{$this->name}PickerPop').css('top', \$j(this).offset().top + \$j(this).height() / 2).css('left', \$j(this).offset().left + \$j(this).width() / 2).fadeToggle();");
				
				return $style."<div class=\"{$this->name}Picker\"><div id=\"{$this->name}PickerPop\" class=\"popup\" style=\"display:none;position:absolute;padding:5px;background-color:white;width:400px;\">".$hue.$saturation.$brightness."</div>$B".$I."</div>";
			break;
			
			case "hue":
				return '<input name="'.$this->name.'Picker" type="range" class="color-slider" min="0" step="0.1" max="360" value="'.$this->value.'" style="--_slider-thumb-width:5px;--slider-color-stops: red, yellow, lime, aqua, blue, magenta, red" oninput="'.$this->oninput.' $j(\'[name='.$this->name.']\').val(this.value);" /><input type="text" name="'.$this->name.'" value="'.$this->value.'" onkeyup="$j(\'[name='.$this->name.'Picker]\').val(this.value);" style="margin-top:5px;"/>';
			break;
			
			case "brightness":
				return '<input name="'.$this->name.'" type="range" class="color-slider" min="0" max="100" value="'.$this->value.'" style="--_slider-thumb-width:5px;--slider-color-stops: black, white" oninput="'.$this->oninput.'" />';
			break;
			
			case "audio":
				return "<audio controls preload=\"auto\" autobuffer style=\"$this->style\"><source src=\"$this->value\"></audio>";
			break;
		
			case "search":
				$currentId = ($this->id != null ? $this->id : $this->name.rand(100, 100000000));
				$enter = "if(\$j('#$currentId').val() != ''){ \$j('#SB$currentId').fadeOut(200, function(){ \$j('#SA$currentId').fadeIn();}); } else { \$j('#SA$currentId').fadeOut(200, function(){ \$j('#SB$currentId').fadeIn(); }); }";
				
				$I = new HTMLInput($this->name, "text", $this->value, $this->options);
				$I->style($this->style);
				$I->placeholder($this->placeholder);
				$I->onEnter($this->onenter.$enter);
				#$I->onEnter(" ");
				$I->id($currentId);
				
				$BSearch = new Button("Suchen", "question_mark", "iconicG");
				$BSearch->style("margin-left:5px;");
				$BSearch->id("SB$currentId");
				$BSearch->onclick($this->onenter.$enter);
				#$BSearch->id("searchMailsInfo");

				$BSearchClear = new Button("Suche beenden", "x_alt", "iconicR");
				$BSearchClear->style("margin-left:5px;display:none;");
				$BSearchClear->id("SA$currentId");
				$BSearchClear->onclick("\$j('#$currentId').val('').trigger('blur'); $this->onenter$enter");
				#$BSearchClear->id("searchMailsClear");

				return $I.$BSearch.$BSearchClear.$this->requestFocus;
			break;
		
			case "HTMLInline":
				if($this->isDisplayMode) 
					return $this->value;
				
				$currentId = ($this->id != null ? $this->id : $this->name).rand(100, 100000000);
				
				$I = new HTMLInput($this->name, "textarea", $this->value, $this->options);
				$I->id($currentId);
				$I->style($this->style != null ? $this->style : "height:300px;");
				
				$buttons = "bold italic underline | bullist numlist | link | fullscreen";

				$js = '$j("#'.$currentId.'").tinymce({
				menubar: false,
				statusbar: false,
				license_key: "gpl",
				toolbar1: "'.$buttons.'",
				skin: "oxide'.(mUserdata::getUDValueS("phynxColor", "standard") == "darkMode" ? "-dark" : "").'",
				plugins: [
					"lists",
					"link",
					"image",
					"code",
					"autoresize",
					"fullscreen",
					"save"/*,
					"paste"*/
				],
				paste_as_text: true,
				browser_spellcheck : true,
				content_css : ["./styles/standard/colors.css", "./styles/tinymce/inline.css"'.(mUserdata::getUDValueS("phynxColor", "standard") == "darkMode" ? ", \"./styles/darkMode/colors.css\"" : "").'],
				convert_urls : false,
				license_key: "gpl",
				extended_valid_elements : "img[class|src|border=0|alt|title|hspace|vspace|width|height|align|onmouseover|onmouseout|name],blockquote[cite|class|dir<ltr?rtl|id|lang|onclick|ondblclick|onkeydown|onkeypress|onkeyup|onmousedown|onmousemove|onmouseout|onmouseover|onmouseup|style|title|type],div[align<center?justify?left?right|class|dir<ltr?rtl|id|lang|onclick|ondblclick|onkeydown|onkeypress|onkeyup|onmousedown|onmousemove|onmouseout|onmouseover|onmouseup|style|title]",
				language : "de",
				paste_data_images:true,
				entity_encoding : "raw",
				min_height: 30,
				setup: function(ed) {
					ed.on("keyup", function(event) {
					
						if(event.keyCode == 83 && event.ctrlKey){
							$j("#'.$currentId.'").parent().parent().parent().find("[name=currentSaveButton]").trigger("click");
							return;
						}
							
						$j("#'.$currentId.'").parent().parent().parent().find("[name=currentSaveButton]").closest("tr").addClass("recentlyChanged");
					});
				}
			});';
				
				return $I.OnEvent::script($js);
			break;
		
			case "HTMLEditor":
				throw new Exception("HTMLEditor no longer supported!");
				/*$B = new Button("in HTML-Editor\nbearbeiten","editor");
				$B->windowRme("Wysiwyg","","getEditor","","WysiwygGUI;FieldClass:{$this->options[0]};FieldClassID:{$this->options[1]};FieldName:{$this->options[2]}");
				$B->className("backgroundColor2");

				return $B->__toString();*/
			break;
		
			case "TextEditor":
				#return "<input ".(isset($this->events[$as]) ? $eve : "")." style=\"background-image:url(./images/navi/editor.png);".(isset($this->inputStyle[$as]) ? "".$this->inputStyle[$as]."" : "")."\" type=\"button\" class=\"bigButton backgroundColor2\" onclick=\"TextEditor.show('$as','$this->FormID');\" value=\"".$this->texts["in Editor bearbeiten"]."\" /><textarea style=\"display:none;\" name=\"".$as."\" id=\"".$as."\">".$this->attributes->$as."</textarea>";
				$B = new Button("in Editor\nbearbeiten","editor");
				$B->className("backgroundColor2");
				$B->onclick("TextEditor.show('$this->name','{$this->options[0]}');");

				$ITA = new HTMLInput($this->name, "textarea", $this->value);
				$ITA->id($this->name);
				$ITA->style("display:none;");
				
				return $B->__toString().$ITA;
			break;
		
			case "nicEdit":
				$BO = array("'{$this->options[0]}'", "'{$this->options[1]}'");
				if(isset($this->options[2]))
					$BO[] = "'{$this->options[2]}'";
					
				$B = new Button("in Editor\nbearbeiten","editor");
				$B->doBefore("Overlay.showDark(); %AFTER");
				$B->popup("", "Editor", "nicEdit", "-1", "editInPopup", $BO, "", "Popup.presets.editor");
				$B->className("backgroundColor2");

				$ITA = new HTMLInput($this->name, "hidden", $this->value);
				
				return $B->__toString().$ITA;
			break;
		
			case "tinyMCE":
				$BO = array("'{$this->options[0]}'", "'{$this->options[1]}'");
				if(isset($this->options[2]))
					$BO[] = "'{$this->options[2]}'";
				if(isset($this->options[3]))
					$BO[] = "'{$this->options[3]}'";
					
				$B = new Button("in Editor\nbearbeiten","editor");
				$B->doBefore("Overlay.showDark(); %AFTER");
				$B->popup("", "Editor", "tinyMCE", "-1", "editInPopup", $BO, "", "Popup.presets.editor");
				$B->className("backgroundColor2");
				$B->id($this->id);
				$B->style($this->style);
				
				$ITA = new HTMLInput($this->name, "hidden", $this->value);
				
				return $B->__toString().$ITA;
			break;
		
			case "multiInput":
				return "<input
					class=\"multiEditInput2\"
					type=\"text\"
					".($this->style != null ? " style=\"$this->style\"" : "")."
					value=\"".htmlspecialchars($this->value)."\"
					onfocus=\"oldValue = this.value;\"
					id=\"".$this->options[2]."ID".$this->options[1]."\"
					onblur=\"if(oldValue != this.value) saveMultiEditInput('".$this->options[0]."','".$this->options[1]."','".$this->options[2]."');\"
					onkeydown=\"if(event.keyCode == 13) saveMultiEditInput('".$this->options[0]."','".$this->options[1]."','".$this->options[2]."');\"/>";
			break;

			/*case "customSelection":
				$B = new Button("Eintrag auswählen...", "gutschrift");
				$B->type("LPBig");
				$B->style("float:right;margin-left:10px;");
				#				 "contentRight"		"callingPluginID"  "selectPlugin"
				$B->customSelect($this->options[0], $this->options[1], $this->options[2], $this->options[3]);

				return $B."<input type=\"text\" name=\"$this->name\" value=\"$this->value\" />";
			break;*/

			case "textarea":
				if($this->isDisplayMode) return nl2br($this->value);

				if($this->multiEditOptions != null){
					$this->id($this->name."ID".$this->multiEditOptions[1]);
					$this->onfocus .= " contentManager.oldValue = this.value;";
					$this->onkeyup .= "if(event.keyCode == 13) saveMultiEditInput('".$this->multiEditOptions[0]."','".$this->multiEditOptions[1]."','".$this->name."'".($this->multiEditOptions[2] != null ? ", ".$this->multiEditOptions[2] : "").");";
					$this->onblur .= "if(contentManager.oldValue != this.value) saveMultiEditInput('".$this->multiEditOptions[0]."','".$this->multiEditOptions[1]."','".$this->name."'".($this->multiEditOptions[2] != null ? ", ".$this->multiEditOptions[2] : "").");";
				
				}

				return "<textarea
					".($this->placeholder != null ? " placeholder=\"$this->placeholder\"" : "")."
					".($this->style != null ? " style=\"$this->style\"" : "")."
					name=\"$this->name\"
					".($this->rows !== null ? "rows=\"$this->rows\"" : "")."
					".(!$this->autocorrect ? "autocorrect=\"off\"" : "")."
					".(!$this->spellcheck ? "spellcheck=\"false\"" : "")."
					".($this->className != null ? "class=\"$this->className\"" : "")."
					".($this->onkeyup != null ? "onkeyup=\"$this->onkeyup\"" : "")."
					".($this->onblur != null ? "onblur=\"$this->onblur\"" : "")."
					".($this->onfocus != null ? "onfocus=\"$this->onfocus\"" : "")."
					".($this->onkeyup != null ? "onkeyup=\"$this->onkeyup\"" : "")."
					".($this->isDisabled ? "disabled=\"disabled\"" : "")."
					".($this->id != null ? "id=\"$this->id\"" : "").">$this->value</textarea>";
			break;

			case "file-CC":
				$this->options["action"] = "./index.php";
				
			case "file":
				$physion = Session::physion();

				$currentId = ($this->id != null ? $this->id : $this->name).rand(100, 100000000);
				
				if(isset($this->options["autoUpload"]) AND !$this->options["autoUpload"])
					$this->callback = "QQUploader$currentId.uploadStoredFiles();";

				return "
					<div id=\"progress_$currentId\" style=\"height:10px;width:95%;display:none;\" class=\"\">
						<div id=\"progressBar_$currentId\" style=\"height:10px;width:0%;\" class=\"backgroundColor1\"></div>
					</div>
					<div id=\"$currentId\" style=\"width:100%;$this->style\"></div>
					<script type=\"text/javascript\">
						QQUploader$currentId = new qq.FileUploader({
							maxSizePossible: '".ini_get("upload_max_filesize")."B',
							uploadButtonText: '".T::_("Datei auswählen")."',
							dragText: '".T::_("Datei hier ablegen zum Hochladen")."',
							sizeLimit: ".Util::toBytes(ini_get("upload_max_filesize")).",
							element: \$j('#$currentId')[0],
							action: '".(($this->options != null AND isset($this->options["action"])) ? $this->options["action"] : "./interface/set.php")."',
							params: {
								'class': '".(($this->options == null OR !isset($this->options["class"])) ? "TempFile" : $this->options["class"])."'
								,'id':'-1'
								".(($this->options != null AND isset($this->options["path"])) ? ",'path':'".$this->options["path"]."'" : "")."
								".(($this->options != null AND isset($this->options["targetFilename"])) ? ",'targetFilename':'".$this->options["targetFilename"]."'" : "")."
								".($physion ? ",'physion':'$physion[0]'" : "")."
							},
							".((isset($this->options["autoUpload"])) ? "autoUpload: ".($this->options["autoUpload"] ? "true" : "false")."," : "")."
							".((isset($this->options["multiple"])) ? "multiple: ".($this->options["multiple"] ? "true" : "false")."," : "")."
							onSubmit: function(id, fileName){ \$j('#progress_$currentId').css('display', 'block');},
							onComplete: function(id, fileName, transport){ \$j('progress_$currentId').css('display', 'none'); $this->onchange },
							onProgress: function(id, fileName, loaded, total){ \$j('#progressBar_$currentId').css('width', Math.ceil((loaded / total) * 100)+'%'); }});
					</script>";
			break;

			case "selectColor":
				$optColors = [];

				foreach($this->options AS $color)
					$optColors[] = "<div class=\"isColorSelection\" data-value=\"$color\" style=\"background: linear-gradient(90deg, $color 5px, $color 20px, rgba(".implode(", ", Util::hex2rgb($color)).", 0.2) 10px);cursor:pointer;padding:5px;padding-left:25px;box-sizing:border-box;\">$color</div>";
		
				$S = new HTMLInput($this->name, "text", $this->value);
				$S->onclick("\$j('#{$this->name}Select').css('width', \$j(this).width()).show();");
				$S->onblur("var target = \$j(event.explicitOriginalTarget); if(event.explicitOriginalTarget.nodeName == '#text') target = target.parent(); if(target.hasClass('isColorSelection')) { var newVal = target.data('value');  \$j(event.originalTarget).val(newVal).css('background', 'linear-gradient(90deg, '+newVal+' 5px, '+newVal+' 20px, transparent 10px)').trigger('keydown').focus(); } \$j('#{$this->name}Select').hide();");
				$S->setClass("selectColor");
				$S->style("padding-left:25px;background: linear-gradient(90deg, $this->value 5px, $this->value 20px, transparent 10px);");

				return $S."<div id=\"{$this->name}Select\" style=\"z-index:10;background-color:white;display:none;position:absolute;max-height:200px;overflow:auto;border-radius:4px;\">".implode("", $optColors)."</div>";
			break;
			
			case "time":
				$this->type = "text";
				if($this->multiEditOptions != null)
					$this->id($this->name."ID".$this->multiEditOptions[1]);
				
				if(!$this->id)
					$this->id = rand(100000, 9999999).$this->name;
				
				#$this->onkeyup .= "if(\$j(this).val().length == 2 && \$j(this).val().lastIndexOf(':') == -1) \$j(this).val(\$j(this).val()+':'); ";
				if($this->connectTo)
					$this->onkeyup .= "contentManager.connectedTimeInput(event, '$this->id', '$this->connectTo'); ";
				else
					$this->onkeyup .= "contentManager.timeInput(event, '$this->id'); ";
				
			case "time2":
				if($this->type == "time2")
					$this->type = "time";
				
				
			case "radio1":
			case "date":
			case "month":
			case "email":
			case "text":
			case "hidden":
			case "submit":
			case "number":
			case "button":
			case "range":
			case "password":
			case "checkbox":
			case "readonly":
			case "fileold":
			case "color":
				$JS = "";
				#if($this->type == "radio1")
				#	$this->type = "radio";
				
				if($this->type == "month")
					$this->pattern("[0-9]{4}-[0-9]{2}");
				
				if($this->type == "fileold")
					$this->type = "file";
				
				if($this->isDisplayMode) {
					if($this->type == "checkbox") return Util::catchParser($this->value, "load", "", $this->style);
					if($this->type == "hidden") return "";
					if($this->type == "password") return str_repeat("*", mb_strlen($this->value));
					return $this->value."";
				}

				if($this->multiEditOptions != null){
					$this->id($this->name."ID".$this->multiEditOptions[1]);
					$action = "saveMultiEditInput('".$this->multiEditOptions[0]."','".$this->multiEditOptions[1]."','".$this->name."'".($this->multiEditOptions[2] != null ? ", ".$this->multiEditOptions[2] : "").");";
						
					if($this->type == "checkbox")
						$this->onchange = $action;
					else {
						$this->onfocus .= " contentManager.oldValue = this.value;";
						$this->onkeyup .= "var doSave = function(){ if(event.keyCode == 13) $action }; var me = this; ".($this->multiEditOptions[3] != null ? $this->multiEditOptions[3] : "doSave();");
						$this->onblur .= "if(contentManager.oldValue == this.value) return; $action";
					}
					
					if($this->type == "date")
						$this->onchange .= $action;
				}		
				
				$cal = "";
				$B2 = "";
				if($this->type == "date") {
					if($this->id == null) $this->id = rand(10000,90000);

					#$cal = new Button("Kalender anzeigen","calendar", "iconic");
					#$cal->onclick("\$j('#$this->id').focus();");
					#$cal->style("float:right;");

					$this->value = $this->value != "" ? date("Y-m-d", Util::CLDateParserE($this->value, "store")) : $this->value;
					
					#$JS = "<script type=\"text/javascript\">\$j('#$this->id').datepicker();</script>";
					
					#$this->type = "text";
				}

				$value = "value=\"".htmlspecialchars($this->value."")."\"";
				if($this->type == "checkbox") $value = $this->value == "1" ? "checked=\"checked\"" : "";

				$data = "";
				foreach($this->data AS $k => $v)
					$data .= " data-$k=\"$v\"";
				
				

				if($this->autocomplete != null){
					if($this->id == null)
						$this->id = $this->name;
					
					/*$this->onfocus .= " ACInputHasFocus=true; AC.start(this);";
					$this->onblur .= " ACInputHasFocus = false; AC.end(this);";
					$this->onkeyup .= " AC.update(event.keyCode, this, '".$this->autocomplete[0]."');";*/
					$this->autocompleteBrowser = false;
					
					
					$cal = $this->autocomplete[5];#new Button("Suche", "./images/i2/details.png");
					$cal->onclick("$('$this->id').style.display = ''; $('$this->id').value = ''; $('$this->id').focus();");
					if($cal->getStyle() == "")
						$cal->style("float:right;");
					
					if($this->autocomplete[4] != null){
						$B2 = $this->autocomplete[4];
						$B2->style("float:right;margin-left:5px;");
						if(strpos($this->style."", "width") === false)
							$this->style .= "width:80%";
					} else {
						if(strpos($this->style."", "width") === false)
							$this->style .= "width:90%";
					}
					
					
					if($this->autocomplete[1] == null){
						$cal->onclick("$('{$this->id}Display').style.display = ''; $('{$this->id}Display').value = ''; $('{$this->id}').value = ''; $('{$this->id}Display').focus();");
						
						$IN = new HTMLInput($this->name, "hidden", htmlspecialchars($this->value.""));
						$IN->id($this->name);
						if($this->onchange){
							$IN->onchange($this->onchange);
							$this->onchange = "";
						}
						$JS .= $IN;
						
						$this->autocomplete[1] = "function(selection){ if(!selection) return false; var oldVal = \$j('#$this->id').val(); \$j('#$this->id').val(selection.value); if(\$j('#$this->id').val() != oldVal) \$j('#$this->id').trigger('change'); $('{$this->id}Display').value = selection.label; return false; }";
						
						if($this->value != ""){
							$C = substr($this->autocomplete[0], 1)."GUI";
							$C = new $C($this->value);
							
							$value = "value=\"".htmlspecialchars($C->ACLabel($this->value, (is_array($this->autocomplete[3]) ? $this->autocomplete[3] : array($this->autocomplete[3])))."")."\"";
						}
						
						$this->onkeyup .= "if(\$j('[name={$this->name}Display]').val() == '') {  \$j('[name=$this->name]').val(''); } ";
						
						$this->id.= "Display";
						$this->name .= "Display";
						$this->onkeyup .= "\$j('[name=$this->name]').val(this.value);";
						
					}
					
					 $JS .= OnEvent::script("var OnSelectCallback$this->id = ".$this->autocomplete[1]."; \$j(\"input#$this->id\").autocomplete({
						source: function(request, response){ 
							 ".OnEvent::rme($this->autocomplete[0], "getACData", array("'$this->name'", "request.term", is_array($this->autocomplete[3]) ? "'".json_encode($this->autocomplete[3])."'" : $this->autocomplete[3]), "function(transport){ response(jQuery.parseJSON(transport.responseText)); }")."
							 
						},
						select: function(event, ui) { if(typeof ui.item.script == 'string') { var F = new Function(ui.item.script); return F(); } var r = OnSelectCallback$this->id(ui.item, event); ".($this->autocomplete[2] ? "$('$this->id').style.display = 'none';" : "")." return r; },
						/*change: function(event, ui) { var r = OnSelectCallback$this->id(ui.item, event); ".($this->autocomplete[2] ? "$('$this->id').style.display = 'none';" : "")." return r; }*/
					}).data(\"ui-autocomplete\")._renderItem = function( ul, item ) {
						return \$j( \"<li>\" )
							.data( \"item.ui-autocomplete\", item )
							.append( \"<a>\" + item.label + (item.description ? \"<br /><small>\"+item.description+\"</small>\" : \"\")+\"</a>\" )
							.appendTo( ul );
					};");
				}
				
				$useType = $this->type;
				if($useType == "radio1")
					$useType = "radio";
				
				$BC = "";
				if($this->buttonClear){
					$BC = new Button("Leeren", "x_alt", "iconic");
					$BC->style($this->buttonClearStyle);
					if($this->buttonClearAction == null)
						$BC->onclick("\$j('[name=$this->name]').val('').focus();");
					else
						$BC->onclick($this->buttonClearAction);
				}
				
				$BK = "";
				if($this->buttonKeyboard){
					$BK = new Button("Tastatur", "pen_alt2", "iconic");
					$BK->style($this->buttonKeyboardStyle);
					$BK->onclick("\$j('[name=$this->name]').prop('inputMode', 'text').focus();");
				}
				
				$eye = "";
				if($this->type == "password"){
					$eye = new Button("Passwort anzeigen", "eye", "iconic");
					$eye->onclick("if(\$j('[name=$this->name]').prop('type') == 'password') \$j('[name=$this->name]').prop('type', 'text'); else \$j('[name=$this->name]').prop('type', 'password');");
					$eye->style("margin-left:-30px;color:grey;");
				}
				
				return "$B2$cal<input
					".($this->min !== null ? " min=\"$this->min\"" : "")."
					".($this->step != null ? " step=\"$this->step\"" : "")."
					".($this->max !== null ? " max=\"$this->max\"" : "")."
					".($this->required ? " required" : "")."
					".($this->requiredPattern ? " pattern=\"$this->requiredPattern\"" : "")."
					".($this->inputmode != null ? " inputmode=\"$this->inputmode\"" : "")."
					".($this->maxlength != null ? " maxlength=\"$this->maxlength\"" : "")."
					".($this->placeholder != null ? " placeholder=\"$this->placeholder\"" : "")."
					".($this->style != null ? " style=\"$this->style\"" : "")."
					".(is_bool($this->autocompleteBrowser) AND $this->autocompleteBrowser === false ? "autocomplete=\"off\"" : "")."
					".(!is_bool($this->autocompleteBrowser) ? "autocomplete=\"$this->autocompleteBrowser\"" : "")."
					".($this->className != null ? "class=\"$this->className\"" : "")."
					".($this->onclick != null ? "onclick=\"$this->onclick\"" : "")."
					".($this->onblur != null ? "onblur=\"$this->onblur\"" : "")."
					".($this->onfocus != null ? "onfocus=\"$this->onfocus\"" : "")."
					".($this->onkeyup != null ? "onkeyup=\"$this->onkeyup\"" : "")."
					".($this->onkeydown != null ? "onkeydown=\"$this->onkeydown\"" : "")."
					".($this->tabindex != null ? "tabindex=\"$this->tabindex\"" : "")."
					".($this->title != null ? "title=\"$this->title\"" : "")."
					".($this->isSelected ? "checked=\"checked\"" : "")."
					".($this->type == "file" ? "size=\"1\"" : "")."
					".($this->type == "readonly" ? "readonly=\"readonly\"" : "")."
					name=\"$this->name\"
					$data
					".($this->isDisabled ? "disabled=\"disabled\"" : "")."
					type=\"".($useType != "readonly" ? $useType : "text" )."\"
					".($this->onchange != null ? "onchange=\"$this->onchange\"" : "")."
					".($this->oninput != null ? "oninput=\"$this->oninput\"" : "")."
					".($this->id != null ? "id=\"$this->id\"" : "")."
					$value />$BC$BK$eye$this->requestFocus$JS";
			break;

			case "option":
				$data = "";
				foreach($this->data AS $k => $v)
					$data .= " data-$k=\"$v\"";
				
				return "<option".($this->style != null ? " style=\"$this->style\"" : "")." $data ".($this->isDisabled ? "disabled=\"disabled\"" : "")." ".($this->isSelected ? "selected=\"selected\"" : "")." value=\"$this->value\">$this->name</option>";
			break;

			case "optgroup":
				$html = "<optgroup label=\"".htmlentities($this->name)."\">";
				
				foreach($this->options AS $k => $v){
					if(is_object($v)){
						$v->isSelected(false);
						if($this->parentValue == $k OR $v->getValue() == $this->parentValue)
							$v->isSelected(true);
					}
					$html .= $v;
				}
				
				$html .= "</optgroup>";
				
				return $html;
			break;
		
			case "radio":
				$html = "";
				foreach($this->options AS $k => $v)
					$html .= "<div style=\"margin-bottom:5px;\"><input name=\"$this->name\" value=\"$k\" ".($k == $this->value ? "checked=\"checked\"" : "")." style=\"float:left;margin-right:5px;\" type=\"radio\">$v</div>";
				
				return $html;
			break;
		
			case "select":
			case "select-multiple":
				
				if($this->type == "select-multiple")
					$values = trim($this->value."") != "" ? explode(";:;", $this->value) : array();

				if($this->isDisplayMode) {
					if($this->type == "select-multiple"){
						$ex = explode(";:;", $this->value);
						foreach($ex AS $k => $v){
							
							if(isset($this->options[$v]) AND is_object($this->options[$v]))
								$ex[$k] = $this->options[$v]->__toString();
							
							if(isset($this->options[$v]) AND !is_object($this->options[$v]))
								$ex[$k] = $this->options[$v];
							
							
						}
						
						return implode(", ", $ex);
					}
					
					if(isset($this->options[$this->value]) AND is_object($this->options[$this->value]))
						return $this->options[$this->value]->__toString();
						
					if(!isset($this->options[$this->value]) OR $this->options[$this->value] === null)
						return "";
					
					return $this->options[$this->value];
				}
				
				if($this->multiEditOptions != null){
					$this->onchange .= "saveMultiEditInput('".$this->multiEditOptions[0]."','".$this->multiEditOptions[1]."','".$this->name."'".($this->multiEditOptions[2] != null ? ", ".$this->multiEditOptions[2] : "").");";
					$this->id($this->name."ID".$this->multiEditOptions[1]);
				}

				$html = "<select 
					".($this->required ? " required" : "")." 
					".($this->requiredPattern != null ? " pattern=\"$this->requiredPattern\"" : "")."
					".($this->onblur != null ? "onblur=\"$this->onblur\"" : "")." 
					".($this->onfocus != null ? "onfocus=\"$this->onfocus\"" : "")." 
					".($this->size ? "size=\"$this->size\"" : "")." 
					".($this->isDisabled ? "disabled=\"disabled\"" : "")." 
					".($this->className != null ? "class=\"$this->className\"" : "")."
					".($this->type == "select-multiple" ? " multiple=\"multiple\"" : "")."
					".($this->style != null ? " style=\"$this->style\"" : "")." 
					".($this->onchange != null ? "onchange=\"$this->onchange\"" : "")." 
					name=\"$this->name\" 
					".($this->id != null ? "id=\"$this->id\"" : "").">";

				if($this->options != null AND is_array($this->options))
					foreach($this->options AS $k => $v)
						if(!is_object($v)) {
							if($this->type == "select"){
								$isThisIt = ($this->value."" == $k."");
								if($this->value."" === "" AND $k."" === "0")
									$isThisIt = false;
							} else
								$isThisIt = in_array($k, $values);
							
							$html .= "<option ".($isThisIt ? "selected=\"selected\"" : "")." value=\"$k\">$v</option>";
						}
						else {
							if($v->getType() == "optgroup")
								$v->parentValue($this->value);
							
							$v->isSelected(false);
							if($this->value == $k OR $this->value."" == $v->getValue()."")
								$v->isSelected(true);
							$html .= $v;
						}


				$html .= "</select>";

				return $html;
			break;
			
			default:
				return "Typ '$this->type' unbekannt!";
		}
		
	}
}
?>