<?php
/*
 *  This file is part of phynx.

 *  phynx is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  phynx is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;

class CalculatorGUI implements icontextMenu {
	public function getContextMenuHTML($identifier) {
		$I = new HTMLInput("CalculatorRechner");
		$I->onEnter(OnEvent::rme($this, "calculate", array("\$j('input[name=CalculatorRechner]').val()"), "function(t){ if(t.responseText != '##') { var e = jQuery.Event('keyup'); e.which = 13; e.keyCode = 13; \$j('$identifier').val(t.responseText).trigger('keydown').trigger(e); console.log(e);".OnEvent::closeContext()." } }"));
		
		$I->requestFocus(true);

		echo $I;
		
		echo "<div id=\"CalculatorErgebnisse\"></div>";
		echo "<p>Dieser Rechner unterstützt +, -, *, / sowie Klammern.</p>";
		echo OnEvent::script("\$j('input[name=CalculatorRechner]').val(\$j('$identifier').val());");
	}

	public static function formula($formula){
		Util::alienAutloaderLoad(Util::getRootPath()."libraries/math-parser/vendor/autoload.php");
		$format = Util::getLangNumbersFormat(Session::getLanguage());
		
		if($format[0] != ".")
			$formula = preg_replace("/([0-9]+)$format[0]([0-9]+)/", "$1.$2", $formula);
		
		$precision = 2;

		try {
			$parser = new FormulaParser\FormulaParser($formula, $precision);
			$result = $parser->getResult();
		} catch (\Exception $e) {
			die("##");
		}
		Util::alienAutloaderUnload();
		return $result[1];
	}
	
	public function calculate($formula){
		Util::alienAutloaderLoad(Util::getRootPath()."libraries/math-parser/vendor/autoload.php");
		$format = Util::getLangNumbersFormat(Session::getLanguage());
		
		if($format[0] != ".")
			$formula = preg_replace("/([0-9]+)$format[0]([0-9]+)/", "$1.$2", str_replace(".", "", $formula));

		$precision = 2;

		try {
			$parser = new FormulaParser\FormulaParser($formula, $precision);
			$result = $parser->getResult();
		} catch (\Exception $e) {
			die("##");
		}
		Util::alienAutloaderUnload();
		echo Util::CLNumberParserZ($result[1]);
	}
}
?>