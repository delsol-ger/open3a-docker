<?php
/**
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses></http:>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
trait traitBild {
	public function sideButtonBild(HTMLGUIX $gui, $label = "Bilder"){
		if(!Session::isPluginLoaded("mFile"))
			return;
		
		$class = str_replace("GUI", "", $this->getClearClass());
		$gui->addSideRow($this->getPic());
		$B = mFileGUI::getPublicManagerButton($class, $this->getID(), true, $class."Bild", OnEvent::rme($this, "getPic", "1", "function(t){ \$j('#{$class}BildAnzeige').replaceWith(t.responseText) }"), false, "{position: 'left'}");
		$B->label($label);
		
		$gui->addSideButton($B);
		return $B;
	}
	
	public function getPicPath(){
		$class = str_replace("GUI", "", get_class($this));
		if($this->A($class."Bild") == "")
			return null;

		return $this->A($class."Bild");
	}
	
	public function getPic(){
		$class = str_replace("GUI", "", get_class($this));
		$filename = $this->getPicPath();
		
		if($filename == null)
			return "<div id=\"{$class}BildAnzeige\"></div>";
		
		#$data = file_get_contents($filename);
		
		$Image = "<img style=\"max-width:150px;\" src=\"".$filename."\">";
		
		return "<div id=\"{$class}BildAnzeige\">$Image</div>";
	}
	
	public function saveMultiEditField($field, $value){
		$this->changeA($field, $value);
		$this->saveMe();
	}
}
