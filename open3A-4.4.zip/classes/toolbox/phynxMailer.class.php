<?php
/*
 *  This file is part of phynx.

 *  phynx is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  phynx is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;
class phynxMailer {
	private $exceptions = false;
	private $to = array();
	private $cc = array();
	private $bcc = array();
	private $from = array();
	private $subject = "";
	private $body = "";
	private $attachments = array();
	private $stringAttachments = [];
	private $embedded = [];
	private $skipOwn = false;
	private $smtpData = [];
	private $dsn;
	private $bodyAlt;
	private $mailer;
	private $replyTo;
	public static $SMTPLog = [];
	public static $SMTPLogPause = false;
	private $usedOAUTH = false;
	
	function __construct($to = null, $subject = null, $body = null) {
		if($to != null)
			$this->to($to);
		
		if($subject != null)
			$this->subject($subject);
		
		if($body != null)
			$this->body($body);
	}
	
	function SMTPData($host, $user, $password, $port = null){
		$this->smtpData = ["host" => $host, "user" => $user, "pass" => $password, "port" => $port];
	}
	
	function getSMTPParams(){
		return $this->smtpData;
	}
	
	function dsn($Success, $Delay, $Failure){
		$this->dsn = array($Success, $Delay, $Failure);
	}
	
	function bcc($bcc){
		$this->bcc[] = $bcc;
	}
	
	function cc($cc){
		$this->cc[] = $cc;
	}
	
	function body($body){
		$this->body = $body;
	}
	
	function bodyAlt($text){
		$this->bodyAlt = $text;
	}
	
	function subject($subject){
		$this->subject = $subject;
	}
	
	function to($email, $name = ""){
		if(strpos($email, ",") !== false){
			foreach(explode(",", $email) AS $rec)
				$this->to[] = array($rec, $name);
			
			return;
		}
		$this->to[] = array($email, $name);
	}
	
	function replyTo($email){
		$this->replyTo = $email;
	}
	
	function from($email, $name, $sender = null){
		$this->from = array($email, $name, $sender);
	}
	
	function attach($filename, $attachmentName = ""){
		$this->attachments[] = [$filename, $attachmentName];
	}
	
	function attachString($data, $attachmentName = "", $encoding = "auto", $type = ""){
		if($encoding == "auto")
			$encoding = PHPMailer::ENCODING_BASE64;
		$this->stringAttachments[] = [$data, $attachmentName, $encoding, $type];
	}
	
	function embed($filename, $cid){
		$this->embedded[] = [$filename, $cid];
	}
	
	function skipOwnServer($bool){
		$this->skipOwn = $bool;
	}
	
	private function checkAuthData(PHPMailer $mimeMail2, $from){
		$senderDomain = substr($from[0], stripos($from[0], "@") + 1);
		if(Session::isPluginLoaded("mOpenSSL")){
			$Z = anyC::getFirst("OpenSSL", "OpenSSLEmailAddress", $from);
			
			if($Z){
				$cert = tempnam(sys_get_temp_dir(), 'cert');
                $certOk = file_put_contents($cert, $Z->A("OpenSSLCertificate"));
				
                $private = tempnam(sys_get_temp_dir(), 'private');
                $privateOk = file_put_contents($private, $Z->A("OpenSSLPrivateKey"));
				
                $chain = tempnam(sys_get_temp_dir(), 'mailsign');
                $chainOk = file_put_contents($chain, $Z->A("OpenSSLChain"));
				
				if($certOk AND $privateOk AND $chainOk)
					$mimeMail2->sign($cert, $private, $Z->A("OpenSSLPrivateKeyPassword"), $chain);
			}
		}
		
		$CH = Util::getCloudHost();
		if($CH AND isset($CH->emailServer) AND $CH->emailServer != ""){
			$mimeMail2->IsSMTP();
			$mimeMail2->Host = $CH->emailServer;
			$mimeMail2->SMTPAuth = true;
			$mimeMail2->Username = $CH->emailUser;
			$mimeMail2->Password = $CH->emailPassword;
			
			if(!$CH->forceOwnSMTPServer)
				$this->skipOwn = true;
			
			#$MailServerSet = true;
		}
		
		try {
			$MailServerSet = false;
			$MailServer = LoginData::get("MailServerUserPass");
			if ($MailServer != null AND $MailServer->A("server") != "" AND !$this->skipOwn) {
				$mimeMail2->IsSMTP();
				$MailServerSet = $MailServer;
				
				$mimeMail2->Host = $MailServer->A("server");
				
				if(strpos($mimeMail2->Host, ":465") !== false)
					$mimeMail2->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
				
				$mimeMail2->SMTPAuth = $MailServer->A("benutzername") != "";
				$mimeMail2->Username = $MailServer->A("benutzername");
				$mimeMail2->Password = $MailServer->A("passwort");
			}

			$MailServer = null;
			for($i = 2; $i <= 5; $i++){
				if($this->skipOwn)
					break;
				
				if($MailServer == null AND $i > 2)
					break;

				$MailServer = LoginData::get("MailServer{$i}UserPass");
				if($MailServer == null OR $MailServer->A("server") == "" OR $MailServer->A("optionen") == "" OR strtolower($MailServer->A("optionen")) != strtolower($senderDomain)) 
					continue;
				
				$mimeMail2->IsSMTP();
				$MailServerSet = $MailServer;
				
				$mimeMail2->Host = $MailServer->A("server");
				
				if(strpos($mimeMail2->Host, ":465") !== false)
					$mimeMail2->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
				
				$mimeMail2->SMTPAuth = $MailServer->A("benutzername") != "";
				$mimeMail2->Username = $MailServer->A("benutzername");
				$mimeMail2->Password = $MailServer->A("passwort");
			}
			
		} catch (Exception $e) {
			$MailServer = null;
		}
		
		if(!$MailServerSet AND $CH != null AND isset($CH->forceOwnSMTPServer) AND $CH->forceOwnSMTPServer === true AND !$this->skipOwn)
			throw new Exception("Bitte tragen Sie einen eigenen Mailserver ein, um den zuverlässigen Mailversand in Ihrem Namen zu gewährleisten. Melden Sie sich dazu als Admin-Benutzer am System an und tragen Sie den Mailserver im Cloud-Reiter ein.");

		
		$this->checkOAUTH($mimeMail2, $from, $MailServerSet);
	}
	
	private function checkOAUTH(PHPMailer $mimeMail2, $mailfrom, $MailServer){
		if(!$MailServer OR (!strpos($MailServer->A("server"), "gmail.com") AND strpos($MailServer->A("server"), "smtp.office365.com") === false))
			return;

		if(strpos($MailServer->A("server"), "smtp.office365.com") !== false AND $MailServer->A("optionen3") == "")
			return;
		
		$clientId = $MailServer->A("benutzername");
		$clientSecret = $MailServer->A("passwort");
		#echo "<pre>";
		#print_r($MailServer->getA());
		#echo "</pre>";
		#$mimeMail2->Username = "";
		#$mimeMail2->Password = "";
		
		/*if(strpos($mailfrom, "<") !== false){
			$mailfrom = mb_substr($mailfrom, mb_strpos($mailfrom, "<") + 1);
			if(mb_strpos($mailfrom, ">") !== false)
				$mailfrom = mb_substr($mailfrom, 0, mb_strpos($mailfrom, ">"));
		}*/
		
		Util::alienAutloaderLoad(Util::getRootPath()."ubiquitous/OAuth/vendor/autoload.php");
		require_once Util::getRootPath()."ubiquitous/OAuth/OAuthTokenProvider.php";
		require_once Util::getRootPath()."ubiquitous/OAuth/OAuth.php";
		
		if(strpos($MailServer->A("server"), "gmail.com")){
			$provider = new League\OAuth2\Client\Provider\Google(
				[
					'clientId' => $clientId,
					'clientSecret' => $clientSecret,
				]
			);
		}
		
		if(strpos($MailServer->A("server"), "smtp.office365.com") !== false){
			$provider =  new Greew\OAuth2\Client\Provider\Azure([
				'clientId' => $clientId,
				'clientSecret' => $clientSecret,
				'tenantId' => $MailServer->A("optionen3")
			]);
		}
		
		$OA = new OAuth(['provider' => $provider,
			'clientId' => $clientId,
			'clientSecret' => $clientSecret,
			'refreshToken' => $MailServer->A("optionen2"),
			'userName' => $mailfrom,
			]);
		
		/*$provider = new Stevenmaguire\OAuth2\Client\Provider\Microsoft([
				'clientId' => $clientId,
				'clientSecret' => $clientSecret,
				"redirectUri" => "https://www.open3a.de/OAuth/get_oauth_token.php"
			]);

		#$provider->urlAPI = "https://outlook.office365.com/.default";
		#$provider->scope = "Mail.Send";
		$provider->urlAPI = "https://graph.microsoft.com/v1.0/";
		$provider->scope = "openid  SMTP.Send Mail.Send offline_access profile email User.Read";*/
		
		/*$provider =  new Greew\OAuth2\Client\Provider\Azure([
			'clientId' => $clientId,
			'clientSecret' => $clientSecret,
			'tenantId' => "57a45359-7bec-4e2e-9ccf-fc76ee137828",
		]);*/

		
		#$this->smtp_params['user'] = "open3A2.".$this->smtp_params['user']."."."57a45359-7bec-4e2e-9ccf-fc76ee137828";
		#$this->smtp_params['pass'] = $clientSecret;
		#print_r($this->smtp_params);
		#echo "<pre>".base64_decode($OA->getOauth64())."</pre>";
		#$this->smtp_params["xoauth2"] = $OA->getOauth64();
		$mimeMail2->setOAuth($OA);
		$mimeMail2->AuthType = 'XOAUTH2';
		#$mimeMail2->SMTPAuth = true;
		#$mimeMail2->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
		
		$this->usedOAUTH = true;
	}
	
	function send(){
		if(!count($this->from) AND Session::currentUser())
			$this->from(Session::currentUser()->A("UserEmail"), Session::currentUser()->A("name"));
		
		if(!count($this->from) AND !Session::currentUser())
			$this->from("support@open3A.de", "open3A");
		
		$from = $this->from;
		
		$mimeMail2 = $this->mailer = new PHPMailer($this->exceptions);
		$mimeMail2->setLanguage("de", Util::getRootPath()."/libraries/mailer/languages/");
		
		if($this->replyTo)
			$mimeMail2->addReplyTo($this->replyTo);
		
		$this->checkAuthData($mimeMail2, $from[0]);
		
		if(count($this->smtpData)){
			$mimeMail2->IsSMTP();
			
			$mimeMail2->Host = $this->smtpData["host"];
			$mimeMail2->SMTPAuth = $this->smtpData["user"] != "";
			$mimeMail2->Username = $this->smtpData["user"];
			$mimeMail2->Password = $this->smtpData["pass"];
			if($this->smtpData["port"] !== null)
				$mimeMail2->Port = $this->smtpData["port"];
		}
		
		if(is_array($this->dsn)){
			$dsn = [];
			if($this->dsn[0])
				$dsn[] = "SUCCESS";
			if($this->dsn[1])
				$dsn[] = "DELAY";
			if($this->dsn[2])
				$dsn[] = "FAILURE";
			
			$mimeMail2->dsn = implode(",", $dsn);
		}
		
		$mimeMail2->CharSet = "UTF-8";
		$mimeMail2->Subject = $this->subject;
		
		$mimeMail2->From = $from[0];
		if(isset($from[2]))
			$mimeMail2->Sender = $from[2];
		$mimeMail2->FromName = $from[1];
		
		if(strpos($this->body, "<p") !== false AND strpos($this->body, "</p>") !== false)
			$mimeMail2->IsHTML();
		
		$mimeMail2->Body = $this->body;
		foreach($this->to AS $to)
			$mimeMail2->AddAddress($to[0], $to[1]);
		
		if($this->bodyAlt != null)
			$mimeMail2->AltBody = $this->bodyAlt;
		
		$mimeMail2->SMTPOptions = array(
			'ssl' => array(
				'verify_peer' => false,
				'verify_peer_name' => false,
				'allow_self_signed' => true
			)
		);
		
		foreach($this->bcc AS $bcc)
			$mimeMail2->addBCC($bcc);
		
		foreach($this->cc AS $cc)
			$mimeMail2->addCC($cc);
		
		foreach($this->attachments AS $attachment)
			$mimeMail2->AddAttachment($attachment[0], $attachment[1]);
		
		foreach($this->stringAttachments AS $attachment)
			$mimeMail2->addStringAttachment(...$attachment);
		
		foreach($this->embedded AS $embedded)
			$mimeMail2->addEmbeddedImage($embedded[0], $embedded[1]);
		
		phynxMailer::$SMTPLog = [];
		$mimeMail2->SMTPDebug = 3;
		$mimeMail2->Debugoutput = function($str, $level) {
			if(phynxMailer::$SMTPLogPause){
				if(trim($str) == "CLIENT -> SERVER: .")
					phynxMailer::$SMTPLogPause = false;
				else
					return;
			}
			
			phynxMailer::$SMTPLog[] = $str.(mb_substr($str, -1) != "\n" ? "\n" : "");
			
			if(trim($str) == "CLIENT -> SERVER: DATA"){
				phynxMailer::$SMTPLogPause = true;
				phynxMailer::$SMTPLog[] = "…\n";
			}
		};
		
		if(!$mimeMail2->Send()){
			if($this->usedOAUTH)
				Util::alienAutloaderUnload();
			
			throw new Exception("E-Mail: Failed to send e-mail! ".$mimeMail2->ErrorInfo);
		}
		
		if($this->usedOAUTH)
			Util::alienAutloaderUnload();
		
		if(Session::isPluginLoaded("mOpenSSL") AND isset($Z) AND $Z){
			if(file_exists($cert))
				unlink($cert);

			if(file_exists($private))
				unlink($private);

			if(file_exists($chain))
				unlink($chain);
		}
		
		$this->smtpData = ["host" => $mimeMail2->Host, "user" => $mimeMail2->Username, "pass" => $mimeMail2->Password, "port" => $mimeMail2->Port];
		
		return true;
	}
	
	function getSMTPLog(){
		return implode("", self::$SMTPLog);
	}
}
?>