<?php
/**
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses></http:>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
trait traitMwSt {

	public static function parserMwSt($w, $l, $E){
		$class = str_replace("GUI", "", get_class($E));
		$kat = new Kategorien();
		$kat->addAssocV3("type","=","mwst");

		$valuesFixed = [];
		foreach($kat->getArrayWithValues() AS $v)
			$valuesFixed[Util::parseFloat("de_DE", str_replace("%", "", $v)).""] = 
				Util::CLNumberParserZ(Util::parseFloat("de_DE",str_replace("%","",$v)),"load");

		if(!isset($valuesFixed[(float) $E->A($class."MwSt")])) //nicht existierenden MwSt-Satz trotzdem zur Auswahl anbieten, sonst erkennt man es nicht
			$valuesFixed[$E->A($class."MwSt").""] = Util::CLNumberParserZ($E->A($class."MwSt"));

		$B = new Button("MwSt-Sätze bearbeiten", "./images/i2/edit.png", "icon");
		$B->popup("", "MwSt-Sätze bearbeiten", "Artikel", $E->getID(), "mwstEdit");
		$B->style("float:right;");
		
		$I = new HTMLInput($class."MwSt", "select", $w, $valuesFixed);
		$I->style("width:70px;text-align:right;");
		
		$IC = new HTMLInput($class."MwStCode", "select", $E->A($class."MwStCode"), Artikel::$mwstCodes);
		$IC->style("width:calc(100% - 28px - 25px - 70px);");
		
		if(!Util::port("mFeRD", new ArtikelGUI(-1)))
			$IC = "";
		
		return $B.$I."<span style=\"display:inline-block;width:25px;\">%</span>".$IC;
	}
}
