<?php
/**
 *  This file is part of plugins.

 *  plugins is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  plugins is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses></http:>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;

class Upsell extends PersistentObject {
	
	public static function getButtonBigL($mode, $method){
		$B = new Button("Weitere Funktionen", "plus", "iconicL");
		$B->pop("Upsell", -1, "showExtensions", ["'$mode'", "'$method'"], "{width: 800}");
		return $B;
	}
	
	public static function getButtonBig($mode, $method){
		$B = new Button("Weitere Funktionen", "plus", "iconicL");
		#$B->style("float:right;");
		$B->pop("Upsell", -1, "showFunctions", ["'$mode'", "'$method'"], "{width: 800}");
		#$B->popup("", "Seriennummern bearbeiten", "mSeriennummer", "-1", "managePosten", array(), "", "{hPosition: 'center', width:800, top:30}");
		#if($doBefore)
		#	$B->doBefore("$doBefore %AFTER");
		
		return $B;
	}
	
	public static function getButtonSmall($mode, $method){
		$B = new Button("Weitere Funktionen", "plus", "iconicG");
		$B->style("float:right;");
		$B->pop("Upsell", -1, "showFunctions", ["'$mode'", "'$method'"], "{width: 800}");
		#$B->popup("", "Seriennummern bearbeiten", "mSeriennummer", "-1", "managePosten", array(), "", "{hPosition: 'center', width:800, top:30}");
		#if($doBefore)
		#	$B->doBefore("$doBefore %AFTER");
		
		return $B;
	}
}
?>