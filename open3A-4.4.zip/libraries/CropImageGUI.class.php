<?php
/**
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses></http:>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
class CropImageGUI {
	public static function css(){
		return "<style type=\"text/css\">".file_get_contents(Util::getRootPath()."libraries/cropper/cropper.min.css")."</style>";
	}
	
	public static function loadAndCrop($target, $imagePath, $ratio = "1/1", $saveFunction = "function(){ }"){
		return "\$j('$target').html('<img onload=\"contentManager.". str_replace("#", "", $target)." = new Cropper(this, {aspectRatio: $ratio, wheelZoomRatio: 0.05, background: false, viewMode: 1});\" style=\"width:300px;\" src=\"'+$imagePath+'\" />');";
	}

}
