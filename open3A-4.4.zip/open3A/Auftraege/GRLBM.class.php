<?php
/*
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;
class GRLBM extends PersistentObject implements iCloneable, iRepeatable, iDeletable2 {

	public $AdresseObj = null;
	public $isCopy = false;
	protected $letterType = "";
	public $CustomizerTeilzahlungen = false;
	public $CustomizerPostenAddLabelInsertOrigin = true;
	protected $newPostenMessageBestand = "";
	public static $ignoreLock = false;
	public static $lockable = array("R", "G", "T");
		
	// <editor-fold defaultstate="collapsed" desc="getOnDeleteEvent">
	public function getOnDeleteEvent(){
		return "function() { contentManager.reloadFrameRight(); contentManager.reloadFrameLeft(); }";
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="getOnDeleteQuestion">
	public function getOnDeleteQuestion(){
		return "Soll dieser Beleg und alle Positionen wirklich gelöscht werden?";
	}
	// </editor-fold>
	
	function newAttributes() {
		$A = parent::newAttributes();
		
		#if(Session::isPluginLoaded("mFeRD"))
		#	$A->GRLBMCalcModePosten = 1;
		
		return $A;
	}
	
	function __construct($ID, $parsers = true){
		#$this->myAdapterClass = "GRLBMAdapter";
		parent::__construct($ID);
		
		if($parsers){
			$this->setParser("datum","Util::CLDateParser");
			$this->setParser("lieferDatum","Util::CLDateParserE");
			#$this->setParser("rabatt","Util::CLNumberParserZ");
			#$this->setParser("rabattInW","Util::CLNumberParserZ");
			$this->setParser("leasingrate","Util::CLNumberParserZ");
			$this->setParser("payedWithSkonto","Util::CLNumberParserZ");
			$this->setParser("GRLBMpayedDate","Util::CLDateParserE");
			#$this->setParser("versandkosten", "Util::CLNumberParserZ");
			#$this->setParser("versandkostenMwSt", "Util::CLNumberParserZ");
		}
		
		$this->customize();
	}

	// <editor-fold defaultstate="collapsed" desc="makeAB">
	public function makeAB(){
		$this->changeA("isB", "1");
		$this->changeA("isA", "0");
		$this->changeA("isEMailedTime", "0");
		$this->changeA("isEMailed", "0");
		#$this->changeA("isPayed", "1");
		$this->changeA("prefix", Stammdaten::getActiveStammdaten()->getPrefix("B"));

		$Auftrag = new Auftrag($this->A("AuftragID"));
		
		if(Aspect::joinPoint("updateTB", $this, __METHOD__, [], true)){
			$T = new Textbausteine();
			$TBO = $T->getTBs("oben", "B", true);

			$T = new Textbausteine();
			$TBU = $T->getTBs("unten", "B", true);

			$T = new Textbausteine();
			$TBZ = $T->getTBs("zahlungsbedingungen", "B", true);

			$this->changeA("textbausteinObenID", isset($TBO[0][0]) ? $TBO[0][0] : 0);
			$this->changeA("textbausteinUntenID", isset($TBU[0][0]) ? $TBU[0][0] : 0);
			$this->changeA("zahlungsbedingungenID", isset($TBZ[0][0]) ? $TBZ[0][0] : 0);

			if(Session::isPluginLoaded("Kunden") AND $Auftrag->A("kundennummer") > 0){
				$K = Kappendix::getKappendixToKundennummer($Auftrag->A("kundennummer"));
				if($K AND $K->A("BTextbausteinOben"))
					$this->changeA("textbausteinObenID", $K->A("BTextbausteinOben"));

				if($K AND $K->A("BTextbausteinUnten"))
					$this->changeA("textbausteinUntenID", $K->A("BTextbausteinUnten"));

				if($K AND $K->A("BZahlungsbedingungen"))
					$this->changeA("zahlungsbedingungenID", $K->A("BZahlungsbedingungen"));
			}
		}
		$this->changeA("datum", Util::CLDateParser(time()));
		#$this->changeA("lieferDatum", Util::CLDateParser(time()));

		if(Session::isPluginLoaded("mAnsprechpartner")){
			$ARecipient = Ansprechpartner::getAnsprechpartner("Adresse", $Auftrag->A("kundennummer"), "B");
			if($ARecipient != null)
				$this->changeA("GRLBMAnsprechpartnerID", $ARecipient->getID());
		}
		
		$this->saveMe(true, false);

		#$Auftrag = new Auftrag($this->A("AuftragID"));
		$Auftrag->updateStatus("B", true);
		
		// <editor-fold defaultstate="collapsed" desc="Aspect:jP">
		return Aspect::joinPoint("after", $this, __METHOD__, true);
		// </editor-fold>
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="getRepeatableActions">
	public function getRepeatableActions(){
		$t = array("cloneForRepeatable" => "kopieren", "cloneAndMail" => "kopieren und per E-Mail an Kunde verschicken");
		#if($_SESSION["S"]->checkForPlugin("mDrucker")) {
		#	$t["cloneAndPrintOriginal"] = "kopieren und Original drucken";
		#	$t["cloneAndPrintWithCopy"] = "kopieren und Original und Kopie drucken";
		#}

		if(Session::isPluginLoaded("SP"))
			$t["cloneAndMailSigned"] = "kopieren und über signaturportal an Kunde verschicken";

		if(Session::isPluginLoaded("PL"))
			$t["cloneAndMailSigned"] = "kopieren und über PixelLetter an Kunde verschicken";
		
		return $t;
	}
	// </editor-fold>

	private $fullPosten = [];
	public function getFullPosten(){
		if(count($this->fullPosten))
			return $this->fullPosten;
		
		$this->getSumOfPosten();
		
		return $this->fullPosten;
	}
	
	// <editor-fold defaultstate="collapsed" desc="getSumOfPosten">
	private $ges_netto;
	private $ges_brutto;
	private $ges_ek1;
	private $ges_mwst;
	private $ges_groups;
	private $mwst;
	public $getSumOfPostenLog = [];
	public function getSumOfPosten($returnArray = false, $saveValues = false, $calcUpToPostenID = null){
		$this->fullPosten = [];
		
		$this->loadMe();
		$aC = new mPosten();
		$aC->addAssocV3("GRLBMID", "=", $this->getID());
		
		$this->ges_netto = array();
		$this->ges_brutto = array();
		$this->ges_mwst = array();
		$this->ges_groups = array();
		$this->ges_ek1 = 0;
		$this->mwst = array();
		
		$inAltTitle = false;
		$inRabattTitle = false;
		$inRabattTitleValue = 0;
		while($t = $aC->n()){
			if($t->A("PostenAddLine") AND strpos($t->A("PostenAddLine"), "[") === 0 OR strpos($t->A("PostenAddLine"), "{") === 0){
				$titles = json_decode($t->A("PostenAddLine"));
				foreach($titles AS $Tit){
					if(isset($Tit->isalternative) AND $Tit->isalternative == "1")
						$inAltTitle = true;
					if(isset($Tit->isalternative) AND $Tit->isalternative == "0")
						$inAltTitle = false;
					
					if(isset($Tit->rabatt) AND $Tit->rabatt > 0){
						$inRabattTitle = true;
						$inRabattTitleValue = $Tit->rabatt;
					}
					if(isset($Tit->rabatt) AND ($Tit->rabatt == "" OR $Tit->rabatt == 0))
						$inRabattTitle = false;
				}
			}
			
			if($inRabattTitle AND $t->A("rabatt") == 0)
				$t->changeA("rabatt", $inRabattTitleValue);
			
			if($inAltTitle)
				$t->changeA("PostenIsAlternative", "3");
			
			if($t->A("PostenAddSum")){
				$inAltTitle = false;
				$inRabattTitle = false;
			}
			
			if($t->A("PostenIsAlternative") !== null AND $t->A("PostenIsAlternative") > 0)
				continue;
			
			#if($t->A("PostenIsLaufend") !== null AND $t->A("PostenIsLaufend") > 0)
			#	continue;
			
			$t->AA("gesamt_netto", $this->ges_netto);
			$t->AA("gesamt_brutto", $this->ges_brutto);
			$t->AA("gesamt_mwst", $this->ges_mwst);
			
			$this->getSumOfPostenInt($t);
			#echo "<pre>";
			#echo $t->getID().":\n";
			#print_r($this->ges_netto);
			#echo "</pre>";
			
			$this->fullPosten[$t->getID()] = $t;
			
			if($calcUpToPostenID != null AND $calcUpToPostenID == $t->getID())
				break;
		}

		$gesamtNettoOhneRZ = array_sum($this->ges_netto);
		
		$rabatte = [];
		$rabatt = $this->A("rabatt");
		if($this->hasParser("rabatt"))
			$rabatt = Util::CLNumberParserZ($this->A("rabatt"), "store");
		
		if($rabatt != 0){
			$aC = new mPosten();
			$aC->addAssocV3("PostenID", "=", "-9999999"); //don't load a thing!
			#print_r($this->ges_groups);
			foreach($this->ges_groups AS $group => $sums){
				$calcRabatt = Util::kRound($sums["netto"] * ((float) $rabatt / 100));
				$rabatte[$group] = [
					"rabattBetrag" => $calcRabatt,
					"rabattSatz" => $rabatt,
					"mwstSatz" => $sums["mwstSatz"], 
					"mwstCode" => $sums["mwstCode"]
				];
				#$rabatte[$sums["mwstSatz"]] = $calcRabatt;
				$aC->addVirtualPosten(1, "", "", "", $calcRabatt * -1, $sums["mwstSatz"], 0, null, "", ["mwstCode" => $sums["mwstCode"]]);
			}
				
			#foreach($this->ges_netto AS $key => $value){
			#	$rabatte[$key] = Util::kRound($value * ($rabatt / 100));
			#	$aC->addVirtualPosten(1,"", "", "", Util::kRound($value * ($rabatt / 100)) * -1, $key, 0);
			#}
			
			while($t = $aC->n())
				$this->getSumOfPostenInt($t);
				
		}
		
		$zuschlaege = [];
		if($this->A("GRLBMZuschlag") !== null){ //from CustomizerZuschlagGUI
			
			$zuschlag = $this->A("GRLBMZuschlag");
			if($this->hasParser("GRLBMZuschlag"))
				$zuschlag = Util::CLNumberParserZ($this->A("GRLBMZuschlag"), "store");
			if($zuschlag != 0){
				foreach($this->ges_groups AS $group => $sums){
					$calcZuschlag = Util::kRound($sums["netto"] * ($zuschlag / 100));
					#$zuschlaege[$key] = Util::kRound($value * ($zuschlag / 100));
					$zuschlaege[$group] = [
						"zuschlagBetrag" => $calcZuschlag,
						"zuschlagSatz" => $zuschlag,
						"mwstSatz" => $sums["mwstSatz"], 
						"mwstCode" => $sums["mwstCode"]
					];
					#$rabatte[$sums["mwstSatz"]] = $calcRabatt;
					$aC->addVirtualPosten(1, "", "", "", $calcZuschlag, $sums["mwstSatz"], 0, null, "", ["mwstCode" => $sums["mwstCode"]]);
				}
			}
			while($t = $aC->n())
				$this->getSumOfPostenInt($t);
			/*
			if($zuschlag != 0){
				$aC = new mPosten();
				$aC->addAssocV3("PostenID", "=", "-9999999"); //don't load a thing!
				foreach($this->ges_netto AS $key => $value){
					$zuschlaege[$key] = Util::kRound($value * ($zuschlag / 100));
					$aC->addVirtualPosten(1,"", "", "", Util::kRound($value * ($zuschlag / 100)), $key, 0);
				}

				while($t = $aC->n())
					$this->getSumOfPostenInt($t);

			}*/
		}
		
		/**
		 * VERSANDKOSTEN
		 */
		$Versand = $this->A("versandkosten");
		if($this->hasParser("versandkosten"))
			$Versand = Util::CLNumberParserZ($this->A("versandkosten"), "store");
			
		if($Versand != 0 AND $calcUpToPostenID == null){

			$aC = new mPosten();
			$aC->addAssocV3("PostenID", "=", "-9999999"); //don't load a thing!
			$aC->addVirtualPosten(1, "", "Versandkosten", "", $Versand, $this->A("versandkostenMwSt"), 0, null, "", ["mwstCode" => ($this->A("versandkostenMwSt") == 0 ? "Z" : "S")]);
			
			while($t = $aC->n())
				$this->getSumOfPostenInt($t);
			
			#if(!isset($this->ges_brutto[$this->A("versandkostenMwSt")]))
			#	$this->ges_brutto[$this->A("versandkostenMwSt")] = 0;
			
			#if(!isset($this->ges_netto[$this->A("versandkostenMwSt")]))
			#	$this->ges_netto[$this->A("versandkostenMwSt")] = 0;

			
			#$this->ges_brutto[$this->A("versandkostenMwSt")] += $Versand * ((100 + $this->A("versandkostenMwSt")) / 100);
			#$this->ges_netto[$this->A("versandkostenMwSt")] += $Versand;
			#$this->ges_ek1 += $Versand;

			#if(array_search($this->A("versandkostenMwSt"), $this->mwst) === false)
			#	$this->mwst[] = $this->A("versandkostenMwSt");
			
		}
		
		
		$this->getSumOfPostenLog["GRLBMCalcModeSum"] = $this->A("GRLBMCalcModeSum");
		//Netto-Modus: fixes mwst and gros sum afterwards
		if($this->A("GRLBMCalcModeSum") == 1){
			$this->getSumOfPostenLog["totalFixOrig"] = [$this->ges_netto, $this->ges_brutto, $this->ges_mwst];
			foreach($this->ges_netto AS $key => $value){
				$ust = Util::kRound($value * ($key / 100));
				$this->ges_brutto[$key] = $value + $ust;
				$this->ges_mwst[$key] = $ust;
			}
			$this->getSumOfPostenLog["totalFixAfter"] = [$this->ges_netto, $this->ges_brutto, $this->ges_mwst];
		}
		
		//Brutto-Modus: fixes mwst and net sum afterwards
		if($this->A("GRLBMCalcModeSum") == 0){
			$this->getSumOfPostenLog["totalFixOrig"] = [$this->ges_netto, $this->ges_brutto, $this->ges_mwst];
			foreach($this->ges_netto AS $key => $value){
				$ust = $this->ges_brutto[$key] - Util::kRound($this->ges_brutto[$key] / (1 + $key / 100));
				$this->ges_netto[$key] = $this->ges_brutto[$key] - $ust; //Fucks up with 2 items with 0,81 net each: net result is 1,61 //20190816: seems to work with altered ust calculation (from gros)
				$this->ges_mwst[$key] = $ust;
			}
			$this->getSumOfPostenLog["totalFixAfter"] = [$this->ges_netto, $this->ges_brutto, $this->ges_mwst];
		}
			
		if($this->A("GRLBMCalcModeSum") == 2) {} // do nothing (Altteilsteuer)!
		
		if($this->A("isAbschlussrechnung") == "1" AND $calcUpToPostenID == null){
			$oC = Abschlussrechnung::getTeilUndAbschlagBelege($this);
			Aspect::joinPoint("alterDeducted", $this, __METHOD__, [$oC]);
			#$oC->addAssocV3("GRLBMReferenz", "=", $this->A("GRLBMReferenz")); //Nur Teil-/Abschlagsrechnungen mit Bezug auf gleiche AB
			
			while($r = $oC->getNextEntry()){
				$subSum = $r->getSumOfPosten(true);
				
				if($r->A("GRLBMTeilzahlungenSumme") !== null AND $r->A("GRLBMTeilzahlungenSumme") > 0){
					$mwst = array_keys($subSum[5])[0];
					
					$this->ges_brutto[$mwst] -= $r->A("GRLBMTeilzahlungenSumme");
					$netto = Util::kRound($r->A("GRLBMTeilzahlungenSumme") / ((100 + $mwst) / 100));
					$this->ges_netto[$mwst] -= $netto;
					$this->ges_mwst[$mwst] -= $r->A("GRLBMTeilzahlungenSumme") - $netto;
					
					continue;
				}
				
				$aC = new mPosten();
				$aC->addAssocV3("PostenID", "=", "-9999999"); //don't load a thing!
				foreach($subSum[10] AS $sums)
					$aC->addVirtualPosten(1, "", "", "", $sums["netto"] * -1, $sums["mwstSatz"], 0, null, "", ["mwstCode" => $sums["mwstCode"]]);
				
				
				while($t = $aC->n())
					$this->getSumOfPostenInt($t);
				
				#$subSum = $r->getSumOfPosten(true);
				
				/*foreach($subSum[5] AS $mwst => $value){
					if(!isset($this->ges_brutto[$mwst]))
						$this->ges_brutto[$mwst] = 0;
					
					$this->ges_brutto[$mwst] -= $value;
				}
				
				foreach($subSum[6] AS $mwst => $value){
					if(!isset($this->ges_netto[$mwst]))
						$this->ges_netto[$mwst] = 0;
				
					$this->ges_netto[$mwst] -= $value;
				}
				
				foreach($subSum[7] AS $mwst => $value){
					if(!isset($this->ges_mwst[$mwst]))
						$this->ges_mwst[$mwst] = 0;
					
					$this->ges_mwst[$mwst] -= $value;
				}
				*/
				$this->ges_ek1 -= $subSum[4];
				
			}
		}
		
		$ges_brutto = array_sum($this->ges_brutto);
		$ges_brutto = Aspect::joinPoint("alterGesBrutto", $this, __METHOD__, array($ges_brutto), $ges_brutto);
		$this->ges_mwst = Aspect::joinPoint("alterGesMwSt", $this, __METHOD__, array($this->ges_mwst), $this->ges_mwst);
		
		
		if($saveValues) {
			$this->changeA("nettobetrag", array_sum($this->ges_netto));
			$this->changeA("bruttobetrag", Util::kRound($ges_brutto));
			$this->changeA("steuern", array_sum($this->ges_mwst));
			$this->changeA("ek1betrag", $this->ges_ek1);
			$this->saveMe();
		}
		

		if(!$returnArray)
			return $ges_brutto;
		
		return array(
			array_sum($this->ges_netto), 
			array_sum($this->ges_mwst), #1
			$ges_brutto, 
			$this->mwst, #3
			$this->ges_ek1, 
			$this->ges_brutto, #5
			$this->ges_netto, 
			$this->ges_mwst, #7
			$rabatte,
			$zuschlaege,
			$this->ges_groups, #10
			$gesamtNettoOhneRZ #11
		); 
	}
	
	private function getSumOfPostenInt($t){
		$prices = $t->prices($this);
		$mwst = Util::kRound($prices["mwstProzent"])."";#$t->A("mwst");
		
		if(!isset($this->ges_netto[$mwst]))
			$this->ges_netto[$mwst] = 0;
		
		if(!isset($this->ges_brutto[$mwst]))
			$this->ges_brutto[$mwst] = 0;
		
		if(!isset($this->ges_mwst[$mwst]))
			$this->ges_mwst[$mwst] = 0;
		
		if(!isset($this->ges_groups[$prices["mwstGroup"]]))
			$this->ges_groups[$prices["mwstGroup"]] = [
				"netto" => 0, 
				"mwstBetrag" => 0, 
				"mwstSatz" => $prices["mwstProzent"], 
				"mwstCode" => $prices["mwstCode"], 
				"brutto" => 0
			];
		
		
		$this->getSumOfPostenLog[$t->getID()] = $prices;
		
		$this->ges_netto[$mwst] += $prices["nettoGesamt"];
		$this->ges_brutto[$mwst] += $prices["bruttoGesamt"];
		$this->ges_mwst[$mwst] += $prices["mwstBetragGesamt"];
		$this->ges_ek1 += $prices["ek1Gesamt"];
		
		$this->ges_groups[$prices["mwstGroup"]]["netto"] += $prices["nettoGesamt"];
		$this->ges_groups[$prices["mwstGroup"]]["mwstBetrag"] += $prices["mwstBetragGesamt"];
		$this->ges_groups[$prices["mwstGroup"]]["brutto"] += $prices["bruttoGesamt"];
		
		
		if(array_search($mwst, $this->mwst) === false)
			$this->mwst[] = $mwst;
		
		/*if($t->A("steuer") !== null){
			if(!isset($this->artikelsteuern[$t->A("steuer")]))
				$this->artikelsteuern[$t->A("steuer")] = 0;

			$this->artikelsteuern[$t->A("steuer")] += $nettopreis * ($t->A("steuer") / 100);
		}*/

	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="cloneForRepeatable">
	public function cloneForRepeatable(Repeatable $R){
		$this->loadMe();

		$_SESSION["BPS"]->registerClass("cloneGRLBM");
		$_SESSION["BPS"]->setACProperty("datum", date("d.m.Y", $R->getNextDate()));
		$_SESSION["BPS"]->setACProperty("lieferDatum", date("d.m.Y", $R->getNextDate()));
		if($R->A("RepeatableInterval") == "1Month")
			$_SESSION["BPS"]->setACProperty("GRLBMCustomField3", date("m/Y", $R->getNextDate()));
		if($R->A("RepeatableInterval") == "1Year")
			$_SESSION["BPS"]->setACProperty("GRLBMCustomField3", date("Y", $R->getNextDate()));

		$this->changeA("GRLBMReferenz", "Repeatable:".$R->getID());
		
		return $this->cloneMe(true);
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="printMe">
	private function printMe($copy){
		if($this->A == null) $this->loadMe();
		
		$Auftrag = new AuftragGUI($this->A->AuftragID);
		$Auftrag->loadMe();
		#$_SESSION["BPS"]->registerClass("GRLBMGUI");
		#$_SESSION["BPS"]->setACProperty("myID", $this->ID);
		
		$_SESSION["BPS"]->registerClass("mGRLBMGUI");
		$_SESSION["BPS"]->setACProperty("type", $this->getMyPrefix());
		
		$Auftrag->printLetter($this->ID, $copy ? "true" : "false");
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="cloneAndPrintOriginal">
	public function cloneAndPrintOriginal(Repeatable $R){
		$newID = $this->cloneForRepeatable($R);

		$G = new GRLBM($newID);
		$G->printMe(false);
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="cloneAndMail">
	public function cloneAndMail(Repeatable $R){
		$newID = $this->cloneForRepeatable($R);

		#$_SESSION["BPS"]->setProperty("Brief","GRLBMID",$newID);

		$G = new GRLBM($newID);

		$A = new AuftragGUI($G->A("AuftragID"));
		try {
			$A->sendViaEmail($newID, "", "", "", false);
		} catch(Exception $e){
			return "ERROR: ".$e->getMessage()."\n";
		}
		
		return $newID;
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="cloneAndMailSigned">
	public function cloneAndMailSigned(Repeatable $R){
		$newID = $this->cloneForRepeatable($R);

		$_SESSION["BPS"]->setProperty("Brief","GRLBMID",$newID);

		$G = new GRLBM($newID);

		$A = new AuftragGUI($G->A("AuftragID"));
		try {
			$A->sendGRLBMToCustomer($newID, "sign", false);
		} catch(Exception $e){
			return "ERROR: ".$e->getMessage()."\n";
		}
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="cloneAndPrintWithCopy">
	public function cloneAndPrintWithCopy(Repeatable $R){
		$newID = $this->cloneForRepeatable($R);
		
		$G = new GRLBM($newID);
		$G->printMe(false);
		$G->printMe(true);
	}
	//  </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="cloneMe">
	function cloneMe($quiet = false, $AuftragID = null, $date = null, $updatePrices = false){
		if($this->A == null) 
			$this->loadMe();
		
		$_SESSION["BPS"]->setActualClass("clone".get_class($this));
		$bps = $_SESSION["BPS"]->getAllProperties();
		if($bps != -1 AND count($bps) > 0)
			foreach($bps AS $key => $value)
				if(isset($this->A->$key))
					$this->A->$key = $value;
		
		
		if($AuftragID !== null)
			$this->A->AuftragID = $AuftragID;
		$this->A->nummer = mStammdaten::getNextNumberFor($this->getMyPrefix(), new Auftrag($this->A("AuftragID")));
		if(!isset($bps["datum"]) OR trim($bps["datum"]) == "")
			$this->A->datum = Util::CLDateParser(time());#date("d.m.Y");
		
		if($date)
			$this->A->datum = Util::CLDateParser($date);
		
		if(!isset($bps["lieferDatum"]))
			$this->A->lieferDatum = Util::CLDateParser(time());#date("d.m.Y");
		
		$this->A->isPrinted = 0;
		$this->A->isPrintedCopy = 0;
		$this->A->isPayed = 0;
		$this->A->isEMailed = 0;
		
		if($this->A("isB") == "1"){
			$this->A->isB = 0;
			$this->A->isA = 1;
		}
		$oldGRLBMID = $this->ID;


		$Auftrag = new Auftrag($this->A->AuftragID);
		$Auftrag->updateDatum($this->hasParsers ? Util::CLDateParser($this->A("datum"), "store") : $this->A("datum"));

		if($Auftrag->A("kundennummer") > 0){
			$Kappendix = Kappendix::getKappendixToKundennummer($Auftrag->A("kundennummer"));
			if($Kappendix){
				$this->A->zahlungsziel = time() + $Kappendix->A("KappendixZahlungsziel") * 3600 * 24;

				if($this->hasParser("zahlungsziel"))
					$this->A->zahlungsziel = Util::CLDateParser ($this->A->zahlungsziel);
			}
		}

		$newGRLBMID = $this->newMe();
		
		$_SESSION["BPS"]->registerClass("clonePosten");
		$_SESSION["BPS"]->setACProperty("GRLBMID",$newGRLBMID);
		
		Posten::$recalcBeleg = false;
		$mP = new mPosten();
		$mP->cloneAllToGRLBM($oldGRLBMID, $updatePrices, $Auftrag->A("kundennummer"));
		Posten::$recalcBeleg = true;
		
		if(!$quiet)
			echo $this->A->AuftragID;
		else
			return $newGRLBMID;
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="deleteMe">
	function deleteMe(){
		$ps = mUserdata::getPluginSpecificData("Auftraege");
		if(isset($ps["pluginSpecificCantRemoveBelegOthers"])){
			$Auftrag = new Auftrag($this->A("AuftragID"));
			if($Auftrag->A("UserID") != Session::currentUser()->getID())
				Red::alertD("Sie dürfen nur eigene Belege löschen!");
		}
		if(isset($ps["pluginSpecificCantRemoveBeleg"]))
			Red::alertD("Sie dürfen keine Belege löschen!");
		
		if(!self::$ignoreLock AND $this->isLocked())
			Red::alertD ("Dieser Beleg kann nicht mehr bearbeitet werden!", !defined("PHYNX_VIA_INTERFACE"));
		
		$mP = new anyC();
		$mP->setCollectionOf("Posten");
		$mP->addAssocV3("GRLBMID","=",$this->ID);
		#$mP->lCV3();
		
		/*if($mP->numLoaded() > 0)
			die("alert:AuftraegeMessages.A001");*/
		
		$forceDelete = false;
		if($this->getMyPrefix() == "B")
			$forceDelete = true;
		Posten::$recalcBeleg = false;
		while($t = $mP->getNextEntry()){
			$t->resetParsers();
			$t->deleteMe($forceDelete);
		}
		Posten::$recalcBeleg = true;
		
		if(Session::isPluginLoaded("mStammdaten")){
			try {
			$S = Stammdaten::getActiveStammdaten();
			$Auftrag = new Auftrag($this->A("AuftragID"));
			if($Auftrag->A("AuftragStammdatenID") > 0)
				$S = new Stammdaten($Auftrag->A("AuftragStammdatenID"));
			
			if($S->A("templateReNr") == "BelegnummernEditor")
				BelegnummernEditor::rewind($this, $Auftrag, $S);
			
			if($S->A("templateReNr") == "BelegnummernEditor2")
				BelegnummernEditor2::rewind($this, $Auftrag, $S);
			
			} catch (Exception $e){ }
		}
		
		$Auftrag = new Auftrag($this->A("AuftragID"));
		if($this->A("isM")){
			$GRLBM = new GRLBM($this->A("AuftragID"));
			$Auftrag = new Auftrag($GRLBM->A("AuftragID"));
		}
		
		$TG = new GRLBM($this->getID(), false);
		$F = new Factory("GRLBMArchiv");
		$F->sA("GRLBMArchivGRLBMID", $TG->getID());
		$F->sA("GRLBMArchivWhat", $TG->getMyPrefix());
		$F->sA("GRLBMArchivNummer", $TG->A("nummer"));
		$F->sA("GRLBMArchivData", json_encode($TG->getA(), JSON_UNESCAPED_UNICODE));
		$F->sA("GRLBMArchivUserID", Session::currentUser()->getID());
		$F->sA("GRLBMArchivUserName", Session::currentUser()->A("name"));
		$F->sA("GRLBMArchivTime", time());
		$F->sA("GRLBMArchivAuftragAdresseID", $Auftrag->A("AdresseID"));
		$F->store();
		
		parent::deleteMe();
		
		if(Session::isPluginLoaded("mGRLBMService") AND ($this->A("isWhat") == "S" OR $this->A("isWhat") == "Au"))
			GRLBMService::delete($this->getID());
		
		if($this->A("isM") AND Session::isPluginLoaded("mSync") AND strpos($GRLBM->A("GRLBMReferenz"), "Sync:") === 0){
			$SID = str_replace("Sync:", "", $GRLBM->A("GRLBMReferenz"));
			$S = new SyncGet($SID);
			$S->callback($GRLBM->A("GRLBMReferenznummer"), $GRLBM->status());
		}
		
		$Auftrag->updateStatus("-", true);
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="getA">
	function getA(){
		if($this->A == null) $this->loadMe();
		return $this->A;
	}
	// </editor-fold>

	public function A($attributeName, $unparsedValue = false) {
		if(strpos($attributeName, "GRLBMService") === 0 AND Session::isPluginLoaded("mGRLBMService") AND $this->getID() != -1 AND ($this->A("isWhat") == "S" OR $this->A("isWhat") == "Au") AND parent::A($attributeName) === null){
			$this->A = GRLBMService::mergeAttributes($this->getID(), $this->getA(), $this->hasParsers);
			
			if($this->hasParsers)
				GRLBMService::parsers($this);
		}
		
		return parent::A($attributeName, $unparsedValue);
	}
	
	// <editor-fold defaultstate="collapsed" desc="updateTBs">
	function updateTBs($o, $u, $zb){
		$this->A->textbausteinOben = $o;
		$this->A->textbausteinUnten = $u;
		$this->A->zahlungsbedingungen = $zb;
		$this->saveMe();
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="getProvisionCopy">
	protected function getProvisionCopy($ProvisionID){
		$p = new Posten(-1);
		$p->newFromProvision($ProvisionID,$this->ID);
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="getPostenCopy">
	public function getPostenCopy($ArtikelID, $menge = 1, $beschreibung = null, $kundennummer = null, $preis = null){
		if($this->isLocked())
			Red::errorD ("Es können keine Posten mehr hinzugefügt werden, der Beleg wurde gesperrt!");
			
		#$_SESSION["messages"]->addMessage("creating Posten for Auftrag ".$this->ID." of Artikel $ArtikelID");
		$p = new Posten(-1);
		$id = $p->newFromArtikel($ArtikelID, $this->ID, $menge, $beschreibung, $kundennummer, $preis);
		$this->newPostenMessageBestand = $p->messageBestand;
		return $id;
	}
	// </editor-fold>

	public function getEMailData(){
		$Auftrag = new Auftrag($this->A("AuftragID"));
		$Adresse = new Adresse($Auftrag->A("AdresseIDOriginal"));
		
		return $Adresse->getEmailData();
	}
	
	public function loadMe($merge = true) {
		parent::loadMe();
		
		if($merge AND $this->A !== null AND Session::isPluginLoaded("mGRLBMService") AND $this->getID() != -1 AND $this->getID() != 0 AND ($this->A("isWhat") == "S" OR $this->A("isWhat") == "Au"))
			$this->A = GRLBMService::mergeAttributes($this->getID(), $this->getA(), $this->hasParsers);
	}
	
	protected function copyPostenFromMulti($GRLBMIDs){
		if(count($GRLBMIDs) == 0)
			return;
		
		Aspect::joinPoint("before", $this, __METHOD__, array($GRLBMIDs));
		self::$copySortOrderFind = false;
		foreach($GRLBMIDs AS $GRLBMID)
			$this->copyPostenFrom($GRLBMID, [], false);
	}
		
	private static $copySortOrderFind = true;
	public static $copySortOrder = 0;
	public $copyPostenFromPostenIDs = array();
	// <editor-fold defaultstate="collapsed" desc="copyPostenFrom">
	public function copyPostenFrom($fromId, $skipIDs = [], $restValueIDs = []){
		T::load(__DIR__, "Auftraege");
		
		if($this->isLocked())
			Red::errorD("Es können keine Posten mehr hinzugefügt werden, der Beleg wurde gesperrt!");
		
		$this->copyPostenFromPostenIDs = array();
		
		$GRLBM = new GRLBM($fromId);
		$this->copyBelegDataFrom($GRLBM);
		
		$P = new Posten(-1);
		$P->loadMeOrEmpty();
		if(self::$copySortOrderFind AND $P->A("PostenSortOrder") !== null){
			$AC = anyC::get("Posten", "GRLBMID", $this->getID());
			$AC->addOrderV3("PostenSortOrder", "DESC");
			$AC->setLimitV3("1");
			$L = $AC->n();
			if($L)
				self::$copySortOrder = $L->A("PostenSortOrder") + 1;
		}
		
		
		$ps = anyC::get("Posten", "GRLBMID", $fromId);
		if($P->A("PostenSortOrder") !== null)
			$ps->addOrderV3("PostenSortOrder");
		$ps->addOrderV3("PostenID");
		
		Aspect::joinPoint("alter", $this, __METHOD__, array($ps, $fromId, $GRLBM));
		
		$i = 0;
		while(($t = $ps->n())){
			if(is_array($skipIDs) AND in_array($t->getID(), $skipIDs))
				continue;
			
			$A = $t->getA();
			
			if(is_array($restValueIDs) AND in_array($t->getID(), $restValueIDs)){
				$considerField = "preis";
				if($this->getMyPrefix() == "L")
					$considerField = "menge";
				
				$AC = anyC::get("Posten", "PostenByPostenID", $t->getID());
				$AC->addAssocV3("GRLBMID", ">", 0);
				
				$AC->setFieldsV3(["SUM($considerField) AS bisher"]);
				$PC = $AC->n();
				
				$POrig = new Posten($t->getID(), false);
				
				$A->$considerField = $POrig->A($considerField) - $PC->A("bisher");
				if($A->$considerField <= 0)
					continue;
			}
			
			$A->GRLBMID = $this->getID();
			if(isset($A->PostenSortOrder))
				$A->PostenSortOrder = self::$copySortOrder++;#+= $addToSort;
			
			if($i == 0 AND isset($A->PostenAddLine) AND $this->getMyPrefix() != "A" AND $this->getMyPrefix() != "T" AND $this->CustomizerPostenAddLabelInsertOrigin){
				$oldGRLBM = new GRLBM($fromId);
				if($oldGRLBM->A("AuftragID") == $this->A("AuftragID")){
					$label = "";
					try {
						$C = new CustomizerPostenAddLabelGUI();
						$label = CustomizerPostenAddLabelGUI::getCopyLabel($oldGRLBM, $A->PostenAddLine);
					} catch (ClassNotFoundException $ex) {

					}
					$A->PostenAddLine = Aspect::joinPoint("alterCopyLabel", $this, __METHOD__, array($oldGRLBM), $label);
				}
			}
			
			if($this->getMyPrefix() == "O" AND $t->A("oldArtikelID") != "0"){
				$nP = new Posten(-1, false);
				$this->copyPostenFromPostenIDs[] = $nP->newFromArtikel($t->A("oldArtikelID"), $this->getID(), $A->menge);
			} else {
				$nP = new Posten(-1, false);
				$nP->recalcNetto = false;
				$nP->recalcBrutto = false;
				$nP->setA($A);
				
				$A->PostenByPostenID = $t->getID();
				
				if(Session::isPluginLoaded("mSeriennummer") AND Seriennummer::has($t->A("oldArtikelID"))){
					$m = new stdClass();
					$m->type = "warning";
					
					if(in_array($this->getMyPrefix(), Lagerbestand::updateOn($t->A("oldArtikelID"), true))){
						$m->message = "Die Menge wurde durch Kopieren auf Null (vorher ".Util::CLNumberParser($A->menge).") gesetzt!";
						$A->menge = 0;
						$A->PostenUsedSerials = "";
					}
					
					$A->message = json_encode($m, JSON_UNESCAPED_UNICODE);
				}
				
				if(Session::isPluginLoaded("mLagerbestandWare") AND LagerbestandWare::has($t->A("oldArtikelID"))){
					$m = new stdClass();
					$m->type = "warning";
					
					if(in_array($this->getMyPrefix(), Lagerbestand::updateOn($t->A("oldArtikelID"), true))){
						$m->message = "Die Menge wurde durch Kopieren auf Null (vorher ".Util::CLNumberParser($A->menge).") gesetzt!";
						$A->menge = 0;
						#$A->PostenUsedCharge = "";
						$A->PostenUsedMHD = 0;
					}
					
					$A->message = json_encode($m, JSON_UNESCAPED_UNICODE);
				}
				
				$temp = Posten::$recalcBeleg;
				Posten::$recalcBeleg = false;
				$this->copyPostenFromPostenIDs[] = $newID = $nP->newMe(true, false, true); //changed 3rd parameter to true on 20161220 because Lagerbestand was not updated on copy
				
				
				if(Session::isPluginLoaded("mPostenKalkulation")){
					$AC = anyC::get("PostenKalkulation", "PostenKalkulationPostenID", $t->getID());
					while($PK = $AC->n()){
						$PK->changeA("PostenKalkulationPostenID", $newID);
						$PK->newMe();
					}
				}
				
				Posten::$recalcBeleg = $temp;
			}
			
			$i++;
		}
		
		$this->changeA("GRLBMReferenz", "GRLBM:".$fromId);
		$this->saveMe();
		
		$G = new GRLBM($this->getID(), false);
		$G->getSumOfPosten(false, true);
		
		return Aspect::joinPoint("after", $this, __METHOD__, $fromId);
	}
	// </editor-fold>

	public function copyBelegDataFrom(GRLBM $GRLBM){
		if($GRLBM->A("AuftragID") != $this->A("AuftragID"))
			return;
		
		if($GRLBM->getMyPrefix() == "B" AND $this->getMyPrefix() != "B")
			if($this->getMyPrefix() == "L")
				$this->changeA("datum", $GRLBM->A("lieferDatum"));
			else
				$this->changeA("lieferDatum", $GRLBM->A("lieferDatum"));

		if($GRLBM->getMyPrefix() == "L" AND $this->getMyPrefix() == "R")
			$this->changeA("lieferDatum", $GRLBM->A("datum"));
		
		if($GRLBM->getMyPrefix() == "S" AND $this->getMyPrefix() == "R"){
			$this->changeA("lieferDatum", $GRLBM->A("lieferDatum"));
			$this->changeA("GRLBMpayedVia", $GRLBM->A("GRLBMpayedVia"));
			$this->changeA("zahlungsbedingungenID", $GRLBM->A("zahlungsbedingungenID"));
		}

		if($GRLBM->getMyPrefix() == "A" AND $this->getMyPrefix() == "B")
			$this->changeA("lieferDatum", $GRLBM->A("lieferDatum"));
		
		if($GRLBM->getMyPrefix() == "R" AND $this->getMyPrefix() == "G"){
			$this->changeA("GRLBMCalcModePosten", $GRLBM->A("GRLBMCalcModePosten"));
			$this->changeA("GRLBMCalcModeSum", $GRLBM->A("GRLBMCalcModeSum"));
		}
		
		if($GRLBM->getMyPrefix() == "A" OR $GRLBM->getMyPrefix() == "B" OR $this->getMyPrefix() == "T" OR $this->getMyPrefix() == "L")
			$this->changeA("rabatt", $this->hasParsers ? Util::CLNumberParserZ($GRLBM->A("rabatt")) : $GRLBM->A("rabatt"));
		
		for($i = 1;$i < 20; $i++)
			if($GRLBM->A("GRLBMCustomField$i") !== null)
				$this->changeA("GRLBMCustomField$i", $GRLBM->A("GRLBMCustomField$i"));
			
		Aspect::joinPoint("after", $this, __METHOD__, array($GRLBM));
	}
	
	// <editor-fold defaultstate="collapsed" desc="deleteAllPosten">
	public function deleteAllPosten(){
		$ac = new anyC();
		$ac->setCollectionOf("Posten");
		$ac->addAssocV3("GRLBMID", "=", $this->ID);

		while($t = $ac->getNextEntry())
			$t->deleteMe();
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="addPosten">
	public function addPosten($artikelName, $einheit, $anzahl, $preis, $mwst = null, $beschreibung = "", $isBrutto = false, $oldArtikelID = null, $EK1 = 0, $EK2 = 0, $options = array()){
		$preis = $preis * 1;
		$P = new Posten(-1, false);
		$A = $P->newAttributes($mwst === null ? $this : null);
		
		$A->GRLBMID = $this->ID;
		$A->name = $artikelName;
		$A->gebinde = $einheit;
		$A->preis = $preis;
		if($mwst !== null)
			$A->mwst = $mwst;
		$A->menge = $anzahl;
		$A->beschreibung = $beschreibung;
		$A->EK1 = $EK1;
		$A->EK2 = $EK2;
		
		$A->bruttopreis = $preis * ((100 + $mwst) / 100);
		
		if(property_exists($A, "PostenSortOrder")){ //Fix unsorted new Posten after sorting
			$A->PostenSortOrder = 999999;
		
			if(isset($options["obeySortOrder"]) AND $options["obeySortOrder"])
				$A->PostenSortOrder = self::$copySortOrder++;
		}
		
		if($oldArtikelID != null) $A->oldArtikelID = $oldArtikelID;

		if($isBrutto == false AND isset($A->isBrutto))
			$A->isBrutto = "0";
		
		if($isBrutto AND isset($A->isBrutto)){
			$A->isBrutto = "1";
			$A->bruttopreis = $preis;
			$A->preis = $preis / ((100 + $mwst) / 100);
			$P->recalcNetto = false;
		}

		if(isset($options["PostenLeistungszeitraum"]))
			$A->PostenLeistungszeitraum = $options["PostenLeistungszeitraum"];
		
		if(isset($options["PostenLohnkosten"]))
			$A->PostenLohnkosten = $options["PostenLohnkosten"];
		
		if(isset($options["PostenLohnkostenMwSt"]))
			$A->PostenLohnkostenMwSt = $options["PostenLohnkostenMwSt"];
		
		if(isset($options["rabatt"]))
			$A->rabatt = $options["rabatt"];

		$P->setA($A);
		return $P->newMe(false);
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="addPersonal">
	public function addPersonal($PersonalID, $stunden = 1){
		#$this->getPostenCopy($ArtikelID, $menge, $beschreibung, $kundennummer);
		$P = new Personal($PersonalID);
		
		$Preis = 0;
		if($P->A("LohngruppeID") != "0"){
			$L = new Lohngruppe($P->A("LohngruppeID"));
			$Preis = $L->calcNettoPrice(60);
		}
		
		$mwst = 0;
		$M = Kategorien::getDefault("mwst");
		#$AC = anyC::get("Kategorie", "type", "mwst");
		#$AC->addAssocV3("isDefault", "=", "1");
		#$M = $AC->getNextEntry();
		if($M != null)
			$mwst = Util::parseFloat("de_DE",str_replace("%","",$M));
		
		$this->addPosten($P->A("vorname")." ".$P->A("nachname"), "Stunde(n)", $stunden, $Preis, $mwst, "", 0, 0);
	}
	// </editor-fold>
	
	// <editor-fold defaultstate="collapsed" desc="addArtikel">
	public function addArtikel($ArtikelID, $menge = 1, $beschreibung = null, $kundennummer = null, $preis = null){
		return $this->getPostenCopy($ArtikelID, $menge, $beschreibung, $kundennummer, $preis);
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="setTextbaustein">
	public function setTextbaustein($type, $text, $save = true){
		if($type != "textbausteinUnten" AND $type != "textbausteinOben" AND $type != "zahlungsbedingungen") return;
		$tID = $type."ID";

		$this->loadMe();

		$this->A->$tID = 0;
		$this->A->$type = $text;
		
		if($save) $this->saveMe();
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="setLieferdatum">
	public function setLieferdatum($newDatum, $save = true){
		$this->loadMe();

		$this->A->lieferDatum = $newDatum;

		if($save) $this->saveMe();
	}
	// </editor-fold>

	
	public $useCustomizerBelegVersion = false;
	// <editor-fold defaultstate="collapsed" desc="copyPostenByTypeAndNumber">
	protected function copyPostenByTypeAndNumber($fromNumber, $fromType){
		$pSpecData = mUserdata::getPluginSpecificData("Auftraege");
		if(isset($pSpecData["pluginSpecificCantCreate$fromType"]))
			Red::errorD ("Belegart unzulässig");
		
		$version = null;
		if(strpos($fromNumber, "-") !== false AND $fromType == "A" AND $this->A("GRLBMVersion") !== null AND $this->useCustomizerBelegVersion){
			$ex = explode("-", $fromNumber);
			#$fromNumber = $ex[0];
			if(is_numeric($ex[count($ex) - 1])){
				$version = $ex[count($ex) - 1];
				unset($ex[count($ex) - 1]);
				$fromNumber = implode("-", $ex);
			}
		}
		
		try {
			$ac = anyC::get("GRLBM");
			$ac->addAssocV3("is$fromType","=","1");
			$ac->addAssocV3("nummer","=",$fromNumber);
			if($version)
				$ac->addAssocV3 ("GRLBMVersion", "=", $version);
			
			$id = $ac->getNextEntry();
		} catch(FieldDoesNotExistException $e){
			$ac = anyC::get("GRLBM");
			$ac->addAssocV3("isWhat","=","$fromType");
			$ac->addAssocV3("nummer","=",$fromNumber);
			if($version)
				$ac->addAssocV3 ("GRLBMVersion", "=", $version);
			
			$id = $ac->getNextEntry();
		}

		
		if($id == null)
			Red::errorD ("Dieser Typ mit dieser Nummer existiert nicht!");
		
		if($ac->numLoaded() > 1) 
			Red::errorD ("Diese Nummer wurde mehr als einmal gefunden!");
		
		$this->copyPostenFrom($id->getID());
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="markMeAsUnprinted">
	protected function markMeAsUnprinted(){
		if($this->A == null) $this->loadMe();
		$this->A->isPrinted = 0;
		$this->saveMe();
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="markMeAsPrinted">
	public function markMeAsPrinted($copy = false){
		$this->resetParsers();

		#if($this->A == null) $this->loadMe();
		#$this->A->isPrinted = 1;
		#$this->saveMe();
		
		if($this->A("isPrinted".($copy ? "Copy" : "")) == "1")
			return;
		
		$this->changeA("isPrinted".($copy ? "Copy" : ""), "1");
		$this->changeA("isPrinted".($copy ? "Copy" : "")."Time", time());
		$this->saveMe(true, false, false);

		if(Session::isPluginLoaded("mNextcloudUser")){
			$NU = NextcloudUser::getUser();
			if($NU AND $NU->A("NextcloudUserAutoupload"))
				$NU->uploadBeleg("Auftrag", $this->A("AuftragID"), $this, true);
		}
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="setPayed">
	public function setPayed($p, $skonto = "0,00", $datum = "0", $isTeilzahlung = "false", $TeilzahlungBetrag = "", $save = true, $checkPermission = true){
		$pSpecData = mUserdata::getPluginSpecificData("Auftraege");
		
		if($checkPermission AND !isset($pSpecData["pluginSpecificCanSetPayed"])) 
			Red::errorD ("Sie haben keine Berechtigung, eine Rechnung als bezahlt zu markieren!");

		if($p == "true" AND Session::currentUser() !== null)
			mUserdata::setUserdataS("lastPayedStatusChange", time());
		
		$this->loadMe();
		if($isTeilzahlung == "false"){
			$this->A->isPayed = $p == "true" ? 1 : 0;
			$this->A->GRLBMpayedDate = $datum;#Util::CLDateParser($datum,"store");
			if($p != "true")
				$this->A->GRLBMpayedDate = "";
			$this->A->payedWithSkonto = Util::parseFloat("de_DE", $skonto);
		} else {
			$betrag = !is_numeric($TeilzahlungBetrag) ? Util::CLNumberParser($TeilzahlungBetrag, "store") : $TeilzahlungBetrag;
			$this->A->GRLBMTeilzahlungen .= $betrag.";".Util::CLDateParser($datum,"store")."\n";
			$this->A->GRLBMTeilzahlungenSumme += $betrag;
		}
		
		if($save) 
			$this->saveMe(true, false, false);
		
		// <editor-fold defaultstate="collapsed" desc="Aspect:jP">
		$args = func_get_args();
		Aspect::joinPoint("after", $this, __METHOD__, $args);
		// </editor-fold>
	}
	// </editor-fold>

	public function status(){
		if($this->A("isPayed") == "1")
			return "bezahlt";
		
		if($this->A("isPayed") == "2")
			return "storniert";
		
		if($this->A("GRLBMIsInkasso") == "1")
			return "inkasso";
		
		if(Session::isPluginLoaded("Mahnung")){
			$AC = anyC::get("GRLBM", "AuftragID", $this->getID());
			$AC->assoc("isM", "=", "1");
			$num = $AC->getTotalNum();
			if($num > 0)
				return "mahnung$num";
		}
		
		return "unbezahlt";
	}
	
	// <editor-fold defaultstate="collapsed" desc="deleteTeilzahlung">
	public function deleteTeilzahlung($zeile){
		$pSpecData = mUserdata::getPluginSpecificData("Auftraege");
		
		if(!isset($pSpecData["pluginSpecificCanSetPayed"])) Red::errorD("Sie haben keine Berechtigung, eine Rechnung als bezahlt zu markieren!");
		
		$t = trim($this->A("GRLBMTeilzahlungen"));
		$t2 = "";
		$s = explode("\n",$t);
		for($i = 0; $i < count($s); $i++){
			if($zeile != $i){
				$t2 .= $s[$i]."\n";
			} else {
				$b = explode(";",$s[$i]);
				$this->A->GRLBMTeilzahlungenSumme -= $b[0] * 1;
			}
		}
		$this->A->GRLBMTeilzahlungen = $t2;
		$this->saveMe(true, true);
	}
	// </editor-fold>

	// <editor-fold defaultstate="collapsed" desc="saveMe">
	public function saveMe($checkuserdata = true, $output = false, $checkLocked = true){
		$oldMe = new GRLBM($this->ID);
		
		if($this->A("isPrinted") != $oldMe->A("isPrinted") 
			OR $this->A("isEMailed") != $oldMe->A("isEMailed") 
			OR $this->A("isEMailedTime") != $oldMe->A("isEMailedTime"))
			$print = true;
		else
			$print = false;
		
		$type = null;
		if($this->A("isR") == "1")
			$type = "isR";
		
		if($this->A("isG") == "1")
			$type = "isG";
		
		if($type != null){
			$Auftrag = new Auftrag($this->A("AuftragID"));
			
			$AC = anyC::get("GRLBM", $type, "1");
			$AC->addJoinV3("Auftrag", "AuftragID", "=", "AuftragID");
			$AC->addAssocV3("GRLBMID", "!=", $this->getID());
			$AC->addAssocV3("CONCAT(prefix, nummer)", "=", $this->A("prefix").$this->A("nummer"));
			if($Auftrag->A("AuftragStammdatenID") !== null AND trim($Auftrag->A("AuftragStammdatenID")) != "")
				$AC->addAssocV3("AuftragStammdatenID", "=", $Auftrag->A("AuftragStammdatenID"));
			
			$E = $AC->getNextEntry();
			if($E != null)
				Red::alertD ("Die Belegnummer ".$this->A("prefix").$this->A("nummer")." wurde bereits vergeben!", !defined("PHYNX_GLOBAL_CRON"));
		}
		
		if(Session::isPluginLoaded("Provisionen") AND Provisionen::conditions($this, $oldMe) AND ($this->getMyPrefix() == "R" OR $this->getMyPrefix() == "G" OR $this->getMyPrefix() == "T"))
			Provisionen::zuweisen($this, $this->A("isPayed") == "1");
		
		if(
			$this->A("isPayed") != $oldMe->A("isPayed") 
			OR $this->A("GRLBMHasSicherheitsleistung") != $oldMe->A("GRLBMHasSicherheitsleistung")
			OR $this->A("GRLBMpayedVia") != $oldMe->A("GRLBMpayedVia")
			OR $this->A("GRLBMpayedBemerkung") != $oldMe->A("GRLBMpayedBemerkung")
			OR $this->A("GRLBMIsInkasso") != $oldMe->A("GRLBMIsInkasso")
			OR $this->A("GRLBMTeilzahlungenSumme") != $oldMe->A("GRLBMTeilzahlungenSumme")
			OR $this->A("GRLBMIsUneinbringlich") != $oldMe->A("GRLBMIsUneinbringlich")
			OR $this->A("GRLBMRuecklastschrift") != $oldMe->A("GRLBMRuecklastschrift"))
			$checkLocked = false;
		
		if($checkLocked AND !self::$ignoreLock AND $this->isLocked() AND $oldMe->isLocked() AND !$print)
			Red::alertD ("Dieser Beleg kann nicht mehr bearbeitet werden!", !defined("PHYNX_VIA_INTERFACE"));
	
		$Auftrag = new Auftrag($this->A("AuftragID"));
		$Adresse = new Adresse($Auftrag->A("AdresseID"));
		
		if($this->A("textbausteinObenID") != null AND $this->A("textbausteinObenID") != "0")
			$this->changeA("textbausteinOben", Textbaustein::getTextOf($this->A("textbausteinObenID"), $Adresse));
		
		if($this->A("textbausteinUntenID") != null AND $this->A("textbausteinUntenID") != "0")
			$this->changeA("textbausteinUnten", Textbaustein::getTextOf($this->A("textbausteinUntenID"), $Adresse));
		
		if($this->A("zahlungsbedingungenID") != null AND $this->A("zahlungsbedingungenID") != "0")
			$this->changeA("zahlungsbedingungen", Textbaustein::getTextOf($this->A("zahlungsbedingungenID"), $Adresse));
		
		$this->changeA("GRLBMSkonto", json_encode(array("tage" => 0, "prozent" => 0)));
		if(Session::isPluginLoaded("mZahlungsart")){# AND (is_numeric($this->A("GRLBMpayedVia")) OR $this->A("GRLBMpayedVia") == "debit")){
			$Zahlungsart = Zahlungsart::getZA($this->A("GRLBMpayedVia"), $Auftrag->A("AuftragStammdatenID"));
			if($Zahlungsart){
				$this->changeA("GRLBMSkonto", json_encode(array("tage" => $Zahlungsart->A("ZahlungsartSkontoTage"), "prozent" => $Zahlungsart->A("ZahlungsartSkontoProzent"))));
				
				$d = $this->A("datum");
				if($this->hasParser("datum"))
					$d = Util::CLDateParser($this->A("datum"), "store");
				
				$this->changeA("zahlungsziel", $d + (int) $Zahlungsart->A("ZahlungsartTage") * 3600 * 24);
			}
		}
		
		Aspect::joinPoint("after", $this, __METHOD__, array($this->getA()));
		
		if(Session::isPluginLoaded("mGRLBMService") AND ($this->A("isWhat") == "S" OR $this->A("isWhat") == "Au"))
			$this->A = GRLBMService::splitAttributes($this->getID(), $this->getA(), $this->hasParsers);
		
		
		
		$data = json_decode($this->A("GRLBMChanges") == "" ? "[]" : $this->A("GRLBMChanges"));
		
		$old = new stdClass();
		$old->changeUserID = Session::currentUser() != null ? Session::currentUser()->getID() : "unbekannt";
		$old->changeReason = "";
		$old->changeTime = time();
		
		$changed = array();
		foreach($this->getA() AS $k => $v){
			if($k == "GRLBMChanges" OR $k == "GRLBMSEPAData")
				continue;
			
			if($oldMe->A($k) != $v)
				$changed[$k] = $oldMe->A($k);
		}
		$old->changedData = $changed;
		
		
		if(count($changed) > 0){
			$data[] = $old;
			$this->changeA("GRLBMChanges", json_encode($data, defined("JSON_UNESCAPED_UNICODE") ? JSON_UNESCAPED_UNICODE : 0));
		}
		
		parent::saveMe($checkuserdata, false);
		
		$vk = $this->A("versandkosten");
		if($this->hasParsers)
			$vk = Util::CLNumberParserZ ($this->A("versandkosten"), "store");
		
		if(!$this->isLocked() AND $oldMe->A("versandkosten") != $this->A("versandkosten")){
			$G = new GRLBM($this->getID());
			$G->getSumOfPosten(false, true);
		}
		
		$date = $this->A("datum");
		if($this->hasParsers)
			$date = Util::CLDateParser ($this->A("datum"), "store");
		
		if($this->getMyPrefix() != "M" AND !$this->isLocked())
			$Auftrag->updateDatum($date);
		
		if($this->A("isM"))
			$this->updateGebuehren();
		
		if(Session::isPluginLoaded("mSync") AND strpos($this->A("GRLBMReferenz"), "Sync:") === 0){
			$SID = str_replace("Sync:", "", $this->A("GRLBMReferenz"));
			$S = new SyncGet($SID);
			$S->callback($this->A("GRLBMReferenznummer"), $this->status());
		}
		
		if(Session::isPluginLoaded("mBestellung")){
			$B = anyC::getFirst("Bestellung", "BestellungRID", $this->getID());
			if($B AND $this->status() == "bezahlt"){
				$B->setPayed();
				$B->activateShopOrder();
			}
		}
		
		if($output)
			Red::messageSaved();
	}
	// </editor-fold>

	function newMe($checkUserData = true, $output = false) {
		$old = new stdClass();
		$old->changeUserID = Session::currentUser() != null ? Session::currentUser()->getID() : "unbekannt";
		$old->changeReason = "Created";
		$old->changeTime = time();
		
		$changed = array();
		foreach($this->getA() AS $k => $v){
			if($k == "GRLBMChanges" OR $k == "GRLBMSEPAData")
				continue;
			
			$changed[$k] = $v;
		}
		
		$old->changedData = $changed;
		
		$this->changeA("GRLBMChanges", json_encode(array($old), defined("JSON_UNESCAPED_UNICODE") ? JSON_UNESCAPED_UNICODE : 0));
		
		$newID = parent::newMe($checkUserData, false);
		
		if(Session::isPluginLoaded("mGRLBMService") AND ($this->A("isWhat") == "S" OR $this->A("isWhat") == "Au"))
			$this->A = GRLBMService::create($newID);
		
        if($output OR $this->echoIDOnNew){
	        if($this->echoIDOnNew) {
				echo $this->ID;
			} else
				Red::messageCreated(array("ID" => $this->ID));
		}
		
        return $this->ID;
	}
	
	private function updateGebuehren(){
		$AC = anyC::get("GRLBM", "AuftragID", $this->A("AuftragID"));
		$AC->addAssocV3("isM", "=", "1");
		$AC->setFieldsV3(array("SUM(gebuehren) AS gesamt"));
		$T = $AC->n();
		$value = 0;
		if($T)
			$value = $T->A("gesamt");

		$refG = new GRLBM($this->A("AuftragID"), false);
		$refG->changeA("gebuehren", $value);
		$refG->saveMe(true, false, false);
	}
	
	public function isLocked(){
		// <editor-fold defaultstate="collapsed" desc="Aspect:jP">
		try {
			$MArgs = func_get_args();
			return Aspect::joinPoint("around", $this, __METHOD__, $MArgs);
		} catch (AOPNoAdviceException $e) {}
		Aspect::joinPoint("before", $this, __METHOD__, $MArgs);
		// </editor-fold>
		$pSpecData = mUserdata::getPluginSpecificData("Auftraege");
		if(isset($pSpecData["pluginSpecificRLocksAuftrag"]) AND $this->getMyPrefix() != "R"){
			$AC = anyC::get("GRLBM", "AuftragID", $this->A("AuftragID")."");
			$AC->addAssocV3("isR", "=", "1");
			$AC->addAssocV3("datum", ">", $this->hasParser("datum") ? Util::CLDateParser($this->A("datum"), "store") : $this->A("datum"));
			$AC->setLimitV3(1);
			$R = $AC->n();
			if($R)
				return true;
		}
		
		if($this->A("isPayed") == "1")
			return true;
		
		$isProcessed = ($this->A("isPrinted") == "1" OR $this->A("isPrintedCopy") == "1" OR $this->A("isEMailed") == "1");
		
		if(in_array($this->getMyPrefix(), self::$lockable) AND $isProcessed)
			return true;
		
		return false;
		
		#return $this->A("isPayed") == "1";
	}
	
	public function unlock(){
		Aspect::joinPoint("before", $this, __METHOD__, array());

		$this->changeA("isPrinted", "0");
		$this->changeA("isPrintedCopy", "0");
		$this->changeA("isEMailed", "0");
		
		$this->setPayed("false");
	}
	
	// <editor-fold defaultstate="collapsed" desc="getMyPrefix">
	public function getMyPrefix($forceB = false){
		if($this->A == null)
			$this->loadMe();

		if($this->A === null)
			return "";
		
		if($this->A->isR == "1") return "R";
		if(isset($this->A->isL) AND $this->A->isL == "1") return "L";
		if(isset($this->A->isB) AND $this->A->isB == "1") return "B";
		if(isset($this->A->printAB) AND $this->A->printAB == "1" AND (Auftrag::getBelegArten("B") OR $forceB)) return "B";
		if(isset($this->A->isA) AND $this->A->isA == "1") return "A";
		if(isset($this->A->isG) AND $this->A->isG == "1") return "G";
		if(isset($this->A->isM) AND $this->A->isM == "1") return "M";
		if($this->A->isWhat != "") return $this->A->isWhat;
		
		return "-1";
	}
	// </editor-fold>

	public static function getPaymentVia($t = null, $limitTo = null, $onlyDefaults = false, $addKonto = false){
		$ts = array("cash" => "Bar", "debit" => T::_("Lastschrift"), "transfer" => T::_("Überweisung"), "paypal" => T::_("PayPal"), "cashing" => T::_("Inkasso"), "creditcard" => T::_("Kreditkarte"), "realtime" => T::_("Echtzeit-Überweisung"));
		
		if(Session::isPluginLoaded("mKundenkonto"))
			$ts["account"] = T::_("Kundenkonto");
		
		if(Session::isPluginLoaded("mZahlungsart") AND !$onlyDefaults){
			$AC = anyC::get("Zahlungsart");
			$AC->addAssocV3("ZahlungsartStammdatenID", "=", Stammdaten::getActiveStammdaten()->getID());
			#$AC->addAssocV3("ZahlungsartUseFor", "=", "");
			
			while($Z = $AC->getNextEntry()){
				if($Z->A("ZahlungsartUseFor") == "")
					$ts[$Z->getID()] = $Z->A("ZahlungsartName").(($addKonto AND $Z->A("ZahlungsartKonto") != 0) ? " (".$Z->A("ZahlungsartKonto").")" : "")." (Ziel: ".$Z->A("ZahlungsartTage")." Tag".($Z->A("ZahlungsartTage") != 1 ? "e" : "");
				else
					$ts[$Z->A("ZahlungsartUseFor")] = T::_($Z->A("ZahlungsartName")).(($addKonto AND $Z->A("ZahlungsartKonto") != 0) ? " (".$Z->A("ZahlungsartKonto").")" : "")." (Ziel: ".$Z->A("ZahlungsartTage")." Tag".($Z->A("ZahlungsartTage") != 1 ? "e" : "");
			}
		}
		
		if($limitTo !== null){
			if(!is_array($limitTo))
				$limitTo = array($limitTo);
			
			$ts2 = array();
			
			foreach($limitTo AS $v)
				$ts2[$v] = $ts[$v];
			
			$ts = $ts2;
		}
		
		if($t != null)
			return $ts[$t];
		asort($ts);
		return $ts;
	}
	
	public function getEtiketten(){
		$Auftrag = new Auftrag($this->A("AuftragID"));
		$Adresse = new Adresse($Auftrag->A("AdresseID"));

		$Stammdaten = Stammdaten::getActiveStammdaten();

		return array(array(
			$Stammdaten->A("firmaLang").", ".$Stammdaten->A("strasse")." ".$Stammdaten->A("nr").", ".$Stammdaten->A("plz")." ".$Stammdaten->A("ort").(ISO3166::getCountryToCode($Stammdaten->A("land")) != $Adresse->A("land") ? ", ".ISO3166::getCountryToCode($Stammdaten->A("land")) : ""), 
			$Adresse->getFormattedAddress(),
			trim($Stammdaten->A("firmaLang")."\n".$Stammdaten->A("strasse")." ".$Stammdaten->A("nr")."\n".$Stammdaten->A("plz")." ".$Stammdaten->A("ort").(ISO3166::getCountryToCode($Stammdaten->A("land")) != $Adresse->A("land") ? "\n".ISO3166::getCountryToCode($Stammdaten->A("land")) : ""))));
	}
	
	public function updateTodo(){
		if(!Session::isPluginLoaded("mTodo") OR !Session::isPluginLoaded("mKalender"))
			return;
	}
	
	public function getCalendarTitle(){
		$Auftrag = new Auftrag($this->A("AuftragID"));
		$Adresse = new Adresse($Auftrag->A("AdresseID"));
		
		return Stammdaten::getLongType($this->getMyPrefix())." ".$Adresse->getShortAddress()." (".$this->A("nummer").")";
	}
	
	public function getBankingData(){
		$Auftrag = new Auftrag($this->A("AuftragID"));
		$Adresse = new Adresse($Auftrag->A("AdresseID"));
		$Kappendix = Kappendix::getKappendixToKundennummer($Auftrag->A("kundennummer"));
		
		$rep = array("ä", "ö", "ü", "Ä", "Ö", "Ü");
		$repWith = array("ae", "oe", "ue", "Ae", "Oe", "Ue");
		
		$sepa = new stdClass();
		if($this->A("GRLBMSEPAData") != "" AND $this->A("GRLBMSEPAData") != "[]")
			$sepa = json_decode($this->A("GRLBMSEPAData"));

		return array(
			"name" => str_replace($rep, $repWith, $Kappendix->A("KappendixSameKontoinhaber") ? trim($Adresse->getShortAddress()) : $Kappendix->A("KappendixKontoinhaber")),
			"BLZ" => $Kappendix->A("KappendixBLZ"), 
			"konto" => $Kappendix->A("KappendixKontonummer"),
			"BIC" => isset($sepa->BIC) ? $sepa->BIC : $Kappendix->A("KappendixSWIFTBIC"),
			"IBAN" => isset($sepa->IBAN) ? $sepa->IBAN : $Kappendix->A("KappendixIBAN"),
			"mandatDatum" => isset($sepa->MandateDate) ? $sepa->MandateDate : $Kappendix->A("KappendixIBANMandatDatum"),
			"referenz" => isset($sepa->MandateID) ? $sepa->MandateID : $this->A("prefix").$this->A("nummer"),
			"betrag" => Util::kRound($this->A("bruttobetrag")),
			"zweck" => $this->A("prefix").$this->A("nummer")." vom ".$this->A("datum"),
			"kontoID" => 0);
	}
	
	public function completed(){
		#$this->changeA("EingangsbelegBezahltAm", time());
		#$this->saveMe();
	}
}
?>