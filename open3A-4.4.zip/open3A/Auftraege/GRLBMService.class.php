<?php
/**
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses></http:>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;
class GRLBMService extends PersistentObject implements iKalender {
	protected static $serviceLines = 13;
	protected static $serviceLineHeight = 7;
	
	public static $labelTitel = "Arbeitsbeschreibung";
	public static $labelMaterial = "Material";
	public static $labelStundensatz = "Stundensatz";
	public static $labelPause = "Pause";
	public static $labelTelefon = "Telefon";
	public static $labelGarantie = "Garantie";
	
	public static $showDescriptionInPosition = true;
	
	public static function delete($GRLBMID){
		$service = anyC::getFirst("GRLBMService", "GRLBMServiceGRLBMID", $GRLBMID);
		if(!$service)
			return;
		
		$service->deleteMe();
	}
	
	public static function create($GRLBMID){
		$F = new Factory("GRLBMService");
		$F->sA("GRLBMServiceGRLBMID", $GRLBMID);
		if(!$F->exists())
			$F->store();
	}
	
	public static function splitAttributes($GRLBMID, $A, $useParsers = false){
		$service = anyC::getFirst("GRLBMService", "GRLBMServiceGRLBMID", $GRLBMID);
		if(!$service){
			$F = new Factory("GRLBMService");
			$F->sA("GRLBMServiceGRLBMID", $GRLBMID);
			$id = $F->store();
			
			$service = new GRLBMService($id);
		}
		
		$SA = $service->getA();
		foreach($SA AS $k => $v){
			if(!property_exists($SA, $k))
				continue;
			
			$service->changeA($k, $A->$k);
			
			unset($A->$k);
		}
		if($useParsers)
			self::parsers ($service);
		
		$service->saveMe();
		
		return $A;
	}
	
	public static function mergeAttributes($GRLBMID, $A, $useParsers = false){
		if($GRLBMID <= 0)
			return $A;
		
		$AC = anyC::get("GRLBMService", "GRLBMServiceGRLBMID", $GRLBMID);
		if($useParsers)
			self::parsers ($AC);
		
		$service = $AC->n();
		
		if(!$service){
			$F = new Factory("GRLBMService");
			
			/*$GRLBM = new GRLBM($GRLBMID);
			$serviceTest = new GRLBMService(-1);
			$Attr = $serviceTest->newAttributes();
			foreach($Attr AS $k => $v){
				if($GRLBM->A($k) === null)
					continue;
				
				$F->sA($k, $GRLBM->A($k));
			}*/
			$GRLBM = new GRLBM($GRLBMID);
			$GRLBM->loadMe(false);
			foreach($GRLBM->getA() AS $k => $v){
				if(strpos($k, "GRLBMService") === false)
					continue;
				
				if($k == "GRLBMServiceSigAN" OR $k == "GRLBMServiceSigAG")
					continue;
				
				if($k == "GRLBMServiceSigANDate" OR $k == "GRLBMServiceSigAGDate")
					continue;
				
				$F->sA($k, $v);
			}
			
			$F->sA("GRLBMServiceGRLBMID", $GRLBMID);
			$id = $F->store();
			
			$service = new GRLBMService($id);
		}
		
		foreach($service->getA() AS $k => $v)
			$A->$k = $v;
		
		
		return $A;
	}

	public static function parsers($class){
		$class->setParser("GRLBMServiceTerminTag","Util::CLDateParserE");
		$class->setParser("GRLBMServiceTerminUhr","Util::CLTimeParserE");

		$class->setParser("GRLBMServiceVon","Util::CLTimeParserE");
		$class->setParser("GRLBMServiceVon2","Util::CLTimeParserE");
		$class->setParser("GRLBMServiceVon3","Util::CLTimeParserE");
		$class->setParser("GRLBMServiceVon4","Util::CLTimeParserE");

		$class->setParser("GRLBMServiceBis","Util::CLTimeParserE");
		$class->setParser("GRLBMServiceBis2","Util::CLTimeParserE");
		$class->setParser("GRLBMServiceBis3","Util::CLTimeParserE");
		$class->setParser("GRLBMServiceBis4","Util::CLTimeParserE");

		$class->setParser("GRLBMServiceStunden","Util::CLTimeParserE");
		$class->setParser("GRLBMServiceStunden2","Util::CLTimeParserE");
		$class->setParser("GRLBMServiceStunden3","Util::CLTimeParserE");
		$class->setParser("GRLBMServiceStunden4","Util::CLTimeParserE");

		$class->setParser("GRLBMServicePause","Util::CLTimeParserE");
		$class->setParser("GRLBMServicePause2","Util::CLTimeParserE");
		$class->setParser("GRLBMServicePause3","Util::CLTimeParserE");
		$class->setParser("GRLBMServicePause4","Util::CLTimeParserE");

		$class->setParser("GRLBMServiceStundensatz", "Util::CLNumberParserZ");
		$class->setParser("GRLBMServiceStundensatz2", "Util::CLNumberParserZ");
		$class->setParser("GRLBMServiceStundensatz3", "Util::CLNumberParserZ");
		$class->setParser("GRLBMServiceStundensatz4", "Util::CLNumberParserZ");
	}
	
	public static function adviceAddVirtualPosten($class, $args){
		$G = $class->VarsGRLBM;
		if($G->getMyPrefix() != "S" AND $G->getMyPrefix() != "Au")
			return;
		
		$P = $args[0];
		
		$Auftrag = new Auftrag($G->A("AuftragID"));
		$Adresse = new Adresse($Auftrag->A("AdresseID"));
		$U = Users::getUsersArray();
		$mwst = Posten::calcMwst($Adresse);
		
		for($i = 1; $i < 5; $i++){
			$n = $i;
			if($n == 1)
				$n = "";

			if($G->A("GRLBMServiceMitarbeiter$n") == "0" OR $G->A("GRLBMServiceMitarbeiter$n") == "")
				continue;

			$stunden = $G->A("GRLBMServiceStunden$n");
			$stundensatz = $G->A("GRLBMServiceStundensatz$n");

			if($G->hasParser("GRLBMServiceStunden$n") OR strpos($G->A("GRLBMServiceStunden$n"), ":") !== false) //needed for Beleg overview in Auftrag
				$stunden = Util::CLTimeParser($G->A("GRLBMServiceStunden$n"), "store");

			if($G->hasParser("GRLBMServiceStundensatz$n"))
				$stundensatz = Util::CLNumberParser($G->A("GRLBMServiceStundensatz$n"), "store");

				#echo $stundensatz.": ".($G->hasParser("GRLBMServiceStundensatz$n") ? "true" : "false");
			if($stunden <= 0)
				continue;

			#$add += (float) $stunden / 3600 * $stundensatz;

			$P->addVirtualPostenBottom(
				$stunden / 3600, 
				"Stunde(n)", 
				"Arbeitszeit ".$U[$G->A("GRLBMServiceMitarbeiter$n")],
				"",
				$stundensatz,
				$mwst,
				false,
				0,
				"");
		}
	}
	
	public static function advicePrintGRLBM($class, $args){
		$GRLBM = $args[0];
		$fpdf = $class;
		
		if($GRLBM->getMyPrefix() == "S" OR $GRLBM->getMyPrefix() == "Au"){
			$fpdf->SetFont($fpdf->fontRechnungsInfo[0], "", $fpdf->fontRechnungsInfo[2]);
			
			$next = $fpdf->GRLBMNextLine[1];
			if(self::$labelTelefon AND $fpdf->pageNo() == 1){
				$fpdf->SetXY($fpdf->GRLBMNextLine[0],$fpdf->GRLBMNextLine[1]);
				$fpdf->Cell(30 , 6 , self::$labelTelefon, "", 0, "L");
				$fpdf->Cell8($fpdf->widthRechnungsInfo - 30 , 6 , $fpdf->VarsEmpfaengerAdresse->A("tel"),0,0,"R");
			}
			
			$fpdf->SetFont($fpdf->fontRechnungsInfo[0], "B", $fpdf->fontRechnungsInfo[2]);
			$next += 10;
			
			$fpdf->SetFont($fpdf->fontRechnungsInfo[0], $fpdf->fontRechnungsInfo[1], $fpdf->fontRechnungsInfo[2]);

			if($fpdf->PageNo() == 1)
				$fpdf->setXY($fpdf->positionTextbausteinOben[0], $fpdf->positionTextbausteinOben[1]);
		}
	}
	
	public static function getCalendarData($firstDay, $lastDay){
		#$isToDo = array();
		$K = new Kalender();
		if(!Session::isPluginLoaded("mGRLBMService"))
			return $K;
		
		$AC = anyC::get("GRLBMService");
		$AC->addAssocV3("t1.GRLBMServiceTerminTag", ">=", $firstDay);
		$AC->addAssocV3("t1.GRLBMServiceTerminTag", "<=", $lastDay);
		#$AC->addAssocV3("isWhat", "=", "S");
		$AC->addJoinV3("GRLBM", "GRLBMServiceGRLBMID", "=", "GRLBMID");
		$AC->addJoinV3("Auftrag", "t2.AuftragID", "=", "AuftragID");
		$AC->addJoinV3("Adresse", "t3.AdresseID", "=", "AdresseID");

		while($G = $AC->getNextEntry())
			$K->addEvent(GRLBMService::getCalendarDetails("CustomizerBelegServiceGUI", $G->getID(), $G));
		

		return $K;
	}
	
	public static function getCalendarDetails($className, $classID, $G = null){
		$title = "";
		$K = new Kalender();
		
		if($G == null){
			$G = new GRLBM($classID);
			$Auftrag = new Auftrag($G->A("AuftragID"));
			$Adresse = new Adresse($Auftrag->A("AdresseID"));
			$title = $Adresse->A("firma") != "" ? $Adresse->A("firma") : $Adresse->A("vorname")." ".$Adresse->A("nachname");
		}

		if($title == "" AND $G->A("firma") !== null)
			$title = $G->A("firma") != "" ? $G->A("firma") : $G->A("vorname")." ".$G->A("nachname");

		$KE = new KalenderEvent($className, $classID, $K->formatDay($G->A("GRLBMServiceTerminTag")), $K->formatTime($G->A("GRLBMServiceTerminUhr")), $title);
		$KE->icon("./images/i2/settings.png");
		$KE->summary($G->A("textbausteinOben"));

		$M = $G->A("GRLBMServiceMitarbeiter");
		if(($M * 1)."" == $M.""){
			$U = new User($M);
			$M = $U->A("name");
		}

		for($i = 2; $i < 5; $i++){
			$S = $G->A("GRLBMServiceMitarbeiter$i");
			if($S == "" OR ($S * 1)."" != $S."")
				continue;

			$U = new User($S);
			$M .= ($M != "" ? ", " : "").$U->A("name");

		}
		
		$KE->value("Mitarbeiter", $M);

		$KE->canNotify(true, $G->A("GRLBMServiceNotified") == "1");
		
		return $KE;
	}
	
	public static function calcTotalHours($G, $calcPrice = true){
		if($G->getMyPrefix() != "S" AND $G->getMyPrefix() != "Au")
			return 0;
		
		$add = 0;
		for($i = 1; $i < 5; $i++){
			$n = $i;
			if($n == 1)
				$n = "";

			if($G->A("GRLBMServiceMitarbeiter$n") == "0" OR $G->A("GRLBMServiceMitarbeiter$n") == "")
				continue;

			$stunden = $G->A("GRLBMServiceStunden$n");
			$stundensatz = $G->A("GRLBMServiceStundensatz$n");

			if($G->hasParser("GRLBMServiceStunden$n") OR strpos($G->A("GRLBMServiceStunden$n"), ":") !== false) //needed for Beleg overview in Auftrag
				$stunden = Util::CLTimeParser($G->A("GRLBMServiceStunden$n"), "store");

			if($G->hasParser("GRLBMServiceStundensatz$n"))
				$stundensatz = Util::CLNumberParser($G->A("GRLBMServiceStundensatz$n"), "store");

				#echo $stundensatz.": ".($G->hasParser("GRLBMServiceStundensatz$n") ? "true" : "false");
			if($stunden <= 0)
				continue;

			
			if($calcPrice)
				$add += (float) $stunden / 3600 * $stundensatz;
			else
				$add += (float) $stunden;
		}
		
		return $add;
	}
	
	public static function adviceBox($class, $args){
		$G = $args[0];
		$add = self::calcTotalHours($G);
		
		return Util::CLFormatCurrency($G->A("bruttobetrag") * 1 + $add);
	}
	
	public static function adviceServicePosten($class, $args){
		if($args[1]->getMyPrefix() != "S" AND $args[1]->getMyPrefix() != "Au") 
			return "";
		
		$tinyMCEID = "tinyMCE".rand(100, 90000000);
		$I = new HTMLInput("textbausteinUnten", "textarea", $args[1]->A("textbausteinUnten"));
		$I->style("width:calc(100% - 10px);height:300px;margin-left:10px;");
		
		$I->id($tinyMCEID);
		
		$buttons = "save | undo redo | pastetext | styleselect fontsizeselect fontselect | bold italic underline forecolor | hr inserttb";
		
		$list = "";
		$AC = anyC::get("Textbaustein", "KategorieID", "3");
		$AC->addAssocV3("text", "!=", "");
		$AC->addAssocV3("text", "!=", "<p></p>");
		$AC->addOrderV3("label");
		
		while($TB = $AC->n()){
			$list .= '
								{
									text:"'.$TB->A("label").'", 
									type: "menuitem",
									onAction: function(){
										'.OnEvent::rme(new GRLBMServiceGUI(-1), "getTB", [$TB->getID()], "function(t){ ed.execCommand('mceInsertContent', false, t.responseText); console.log(t); }").'
									}
								},';
		}
		
		
		$onSetup = 'ed.ui.registry.addMenuButton("inserttb", {
						text: "Textbausteine",
						onAction: function(){},
							fetch: (callback) => {
								const items = ['.$list.'
								]    
								callback(items);
							}

				   });';
		return "<div><div class=\"prettySubtitle\" style=\"padding-top:60px;\">Arbeitsbeschreibung</div>
		<div style=\"width:calc(100% - 10px);margin-left:0px;\">$I
		</div>
		</div>".OnEvent::script("setTimeout(function(){ ".tinyMCEGUI::editorDokument($tinyMCEID, "function(content){ ".OnEvent::rme($args[1], "setTextbaustein", array("'textbausteinUnten'", "content.getContent()"))." return true; }", $buttons, "../../styles/tinymce/email.css", null, "", "", $onSetup)."}, 10);");

	}
	
	public function getTB($TBID){
		$TB = new Textbaustein($TBID);
		echo $TB->A("text");
	}
	
	public static function advicePrintTextbaustein($class, $args){
		Aspect::joinPoint("before", "CustomizerBelegServiceGUI", __METHOD__, $args);
		
		$Nr = $args[0];
		$T = $args[1];
		
		
		if($class->brief->type != "S" AND $class->brief->type != "Au")
			return null;
		
		if($Nr == 2) //allow Zahlungsbedingungen
			return;
		
		
		if($Nr != 1){
			$T->changeA("text", "");
			return;
		}

		$class->SetFont($class::DEFAULT_FONT, "B", 15);
		$class->ln(1);
		$class->Cell8(0, 5, self::$labelTitel);
		$class->ln(10);
		
		if($class->VarsGRLBM->A("GRLBMServiceMitarbeiter") === null)
			GRLBMService::mergeAttributes ($class->VarsGRLBM->getID(), $class->VarsGRLBM->getA());
		
		$class->SetFont($class->fontTextbausteine[0], $class->fontTextbausteine[1], $class->fontTextbausteine[2]);
		if(trim($class->VarsGRLBM->A("GRLBMServiceMitarbeiter")) != ""){
			$class->SetFont($class::DEFAULT_FONT, "B");
			$class->Cell8(35, 5, "Mitarbeiter:");
			$class->SetFont($class::DEFAULT_FONT, "");
			$M = $class->VarsGRLBM->A("GRLBMServiceMitarbeiter");
			if(substr($M, 0, 1) == "P"){
				$U = new Personal(substr($M, 1));
				$M = $U->A("nachname")." ".$U->A("vorname");
			} else {
				$U = new User($M);
				$M = $U->A("name");
			}
			
			for($i = 2; $i < 5; $i++){
				$S = $class->VarsGRLBM->A("GRLBMServiceMitarbeiter$i");
				if($S == "")
					continue;
				
				if(substr($S, 0, 1) == "P"){
					$U = new Personal(substr($S, 1));
					$M .= ($M != "" ? ", " : "").$U->A("nachname")." ".$U->A("vorname");
				} else {
					$U = new User($S);
					$M .= ($M != "" ? ", " : "").$U->A("name");
				}
			}
			
			$class->Cell8(0 , 5 , $M);
			
			$class->ln();
			#$next += 4;
		}

		if(trim(Util::CLDateParserE($class->VarsGRLBM->A("GRLBMServiceTerminTag"))) != ""){
			$class->SetFont($class::DEFAULT_FONT, "B");
			$class->Cell8(35, 5, "Termin:");
			$class->SetFont($class::DEFAULT_FONT, "");
			$class->Cell(0 , 5 , trim(Util::CLDateParserE($class->VarsGRLBM->A("GRLBMServiceTerminTag"))." ".Util::CLTimeParserE($class->VarsGRLBM->A("GRLBMServiceTerminUhr"))));
			
			$class->ln();
		}
		
		if(Session::isPluginLoaded("mTodo")){
			$AC = anyC::get("Todo", "TodoClass", "GRLBM");
			$AC->addAssocV3("TodoClassID", "=", $class->VarsGRLBM->getID());
			$AC->lCV3();
			if($AC->numLoaded()){
				$users = Users::getUsersArray(null, true);
				$termine = "";
				$i = 0;
				while($T = $AC->n()){
					$termine .= ($termine != "" ? "; " : "").($i++ % 2 == 0 ? "\n" : "").$users[$T->A("TodoUserID")].": ".Util::CLDateParser($T->A("TodoFromDay")).", ".Util::CLTimeParser($T->A("TodoFromTime"))." Uhr";
				}
				$class->SetFont($class::DEFAULT_FONT, "B");
				$class->Cell8(35, 5, "Termin(e):");
				$class->SetFont($class::DEFAULT_FONT, "");
				$class->MultiCell8(0 , 5 , trim($termine));

				$class->ln();
			}
		}
		
		if($class->VarsGRLBM->A("GRLBMServiceAuftraggeber") != "") {
			$class->SetFont($class::DEFAULT_FONT, "B");
			$class->Cell8(35, 5, "Auftraggeber:");
			$class->SetFont($class::DEFAULT_FONT, "");
			$class->Cell8(0 , 5 , $class->VarsGRLBM->A("GRLBMServiceAuftraggeber"));
			#$class->SetXY($fpdf->GRLBMNextLine[0], $next);
			#$class->Cell(30 , 6 , "Auftraggeber", "", 0, "L");
			#$class->Cell8($fpdf->widthRechnungsInfo - 30 , 6 , $class->VarsGRLBM->A("GRLBMServiceAuftraggeber"),0,0,"R");
			$class->ln();
		}
		#if($ln)
		#	$class->ln();
		
		
		if($class->VarsGRLBM->A("GRLBMServiceArbeitsort") != "" OR $class->VarsGRLBM->A("GRLBMServiceAnsprechpartner") != ""){
			
			if(strpos($class->VarsGRLBM->A("GRLBMServiceArbeitsort"), "AdresseNiederlassungID:") === 0){
				try {
					$N = new AdresseNiederlassung(str_replace("AdresseNiederlassungID:", "", $class->VarsGRLBM->A("GRLBMServiceArbeitsort")));
					AdresseNiederlassung::fill($N);

					$new = $N->A("AdresseNiederlassungStrasse")." ".$N->A("AdresseNiederlassungNr").", ".$N->A("AdresseNiederlassungPLZ")." ".$N->A("AdresseNiederlassungOrt");

					$class->VarsGRLBM->changeA("GRLBMServiceArbeitsort", $new);
				} catch(Exception $e){}
			}
		
			if($class->VarsGRLBM->A("GRLBMServiceArbeitsort") != ""){
				$class->SetFont($class::DEFAULT_FONT, "B");
				$class->Cell8(35, 5, "Arbeitsort:");
				$class->SetFont($class::DEFAULT_FONT, "");
				$class->Cell8(0, 5, $class->VarsGRLBM->A("GRLBMServiceArbeitsort"));
				$class->ln();
			}
			
			if($class->VarsGRLBM->A("GRLBMServiceAnsprechpartner") != ""){
				$class->SetFont($class::DEFAULT_FONT, "B");
				$class->Cell8(35, 5, "Ansprechpartner:");
				$class->SetFont($class::DEFAULT_FONT, "");
				$class->Cell8(0, 5, $class->VarsGRLBM->A("GRLBMServiceAnsprechpartner"));
			}
			
			$class->ln(7);
		}
		
		Aspect::joinPoint("between", "CustomizerBelegServiceGUI", __METHOD__, array($class));
		
		$class->Line($class->marginLeft, $class->GetY(), $class->w - $class->marginRight, $class->GetY());
		
		#$class->SetFont($class::DEFAULT_FONT, "B", 13);
		#self::printServiceHeader($class);
		#$class->ln();

		if($class->VarsGRLBM->A("textbausteinUnten") == ""){
			$startY = $class->GetY();
			for($i = 0; $i < self::$serviceLines; $i++){
				$class->Line($class->marginLeft, $startY, $class->w - $class->marginRight, $startY);
				$startY += self::$serviceLineHeight;
			}
			$class->SetY($startY - 3);
		} else {
			$class->ln(3);
			$class->SetFont($class::DEFAULT_FONT, "", 10);
			#$class->MultiCell8(0, 5, $class->VarsGRLBM->A("textbausteinUnten"), 0, "L");
			$class->writeHTML($class->VarsGRLBM->A("textbausteinUnten"));
			$class->ln(6);
			$class->Line($class->marginLeft, $class->GetY() - 3, $class->w - $class->marginRight, $class->GetY() - 3);
		}
		
		
		$class->SetFont($class::DEFAULT_FONT, "", 11);
		self::printServiceBelow($class, $class->VarsGRLBM);
		
		
		$class->ln();

		$P = anyC::getFirst("Posten", "GRLBMID", $class->VarsGRLBM->getID());
		if($P === null AND self::calcTotalHours($class->VarsGRLBM) == 0){
			$class->showPositionen = false;
			$class->sumHideOn[] = "S";
			$class->sumHideOn[] = "Au";
			return;
		}
		
		if($class->GetY() > 235){
			$class->AddPage();
			#$class->SetY($class->GetY() - 70);
		}
		
		$class->SetFont($class::DEFAULT_FONT, "B", 15);
		$class->Cell8(0, 7, self::$labelMaterial);
		$class->ln(10);
		$class->SetFont($class::DEFAULT_FONT, "", 11);
	}
	
	private static function printServiceBelow($class, GRLBM $GRLBM){
		$sum = 0;
		for($i = 1; $i <= 4; $i++){
			$p = $i;
			if($i == 1)
				$p = "";
			
			$class->setFontSize(10);
			
			$GRLBM = new GRLBM($GRLBM->getID(), false);
			
			if($GRLBM->A("GRLBMServiceMitarbeiter$p") == 0 OR $GRLBM->A("GRLBMServiceMitarbeiter$p") == "")
				continue;
			
			$von = $GRLBM->A("GRLBMServiceVon$p");
			$bis = $GRLBM->A("GRLBMServiceBis$p");
			
			$class->Cell8(9, 7, "Von", 0, 0, "L");
			$class->Cell8(12, 7, $GRLBM->hasParser("GRLBMServiceVon$p") ? $von : ($von > 0 ? Util::CLTimeParser($von) : ""), 1, 0, "R"); //removed parser 20220401 customer had both tables
			$class->Cell8(8, 7, "bis", 0, 0, "C");
			$class->Cell8(12, 7, $GRLBM->hasParser("GRLBMServiceBis$p") ? $bis : ($bis > 0 ? Util::CLTimeParser($bis) : ""), 1, 0, "R"); //removed parser 20220401 customer had both tables
			$class->Cell8(10, 7, "Uhr", 0, 0, "L");
		
			$zeit = "";
			if($GRLBM->A("GRLBMServiceBis$p") != "" AND $GRLBM->A("GRLBMServiceVon$p") != "")
				$zeit = Util::CLTimeParser($GRLBM->A("GRLBMServiceBis$p"), "store") - Util::CLTimeParser($GRLBM->A("GRLBMServiceVon$p"), "store");

			if($GRLBM->A("GRLBMServiceStunden$p") != ""){
				$zeit = $GRLBM->A("GRLBMServiceStunden$p");
				if($GRLBM->hasParser("GRLBMServiceStunden$p"))
					$zeit = Util::CLTimeParser ($zeit, "store");
			}
			
			$sum += $zeit;
			
			if(self::$labelPause){
				$class->Cell8(15, 7, self::$labelPause.":", 0, 0, "R");
				$class->Cell8(13, 7, $GRLBM->hasParser("GRLBMServicePause$p") ? $GRLBM->A("GRLBMServicePause$p") : Util::CLTimeParser($GRLBM->A("GRLBMServicePause$p")), 1, 0, "R");
			}
			
			if(self::$labelStundensatz){
				$class->Cell8(26, 7, self::$labelStundensatz.":", 0, 0, "R");
				$class->Cell8(18, 7, $class->cur($class->formatCurrency($class->language, $GRLBM->hasParser("GRLBMServiceStundensatz$p") ? Util::CLNumberParserZ($GRLBM->A("GRLBMServiceStundensatz$p"), "store") : $GRLBM->A("GRLBMServiceStundensatz$p"), true)), 1, 0, "R");
			} else
				$class->Cell8(26 + 18, 7, "", 0, 0, "R");

			$class->Cell8(33, 7, "Arbeitszeit (Std.):", 0, 0, "R");
			$class->Cell8(13, 7, Util::CLTimeParser ($zeit), 1, 0, "R"); //removed parser 20220401 customer had both tables

			$class->ln(10);
		}
		$class->ln(1);
		$class->Line($class->marginLeft, $class->GetY() - 1.5, $class->w - $class->marginRight, $class->GetY() - 1.5);
		$class->Line($class->marginLeft, $class->GetY() - 1, $class->w - $class->marginRight, $class->GetY() - 1);
		$class->ln(1);
		
		$class->Cell8(19, 7, self::$labelGarantie.": ", 0, 0, "R");
		$class->Cell8(7, 7, $GRLBM->A("GRLBMServiceIsGarantie") ? "X" : "", 1, "", "C");
		$class->Cell8(10, 7, "ja");

		$class->Cell8(28, 7, "Abgeschlossen: ", 0, 0, "R");
		$class->Cell8(7, 7, $GRLBM->A("GRLBMServiceIsAbgeschlossen") ? "X" : "", 1, "", "C");
		$class->Cell8(10, 7, "ja");

		$class->Cell8(25, 7, "Berechnung: ", 0, 0, "R");
		$class->Cell8(7, 7, $GRLBM->A("GRLBMServiceIsBerechnung") ? "X" : "", 1, "", "C");
		$class->Cell8(10, 7, "ja");
		
		if($sum > 0){
			$class->Cell8(33, 7, "Summe (Std.):", 0, 0, "R");
			$class->Cell8(13, 7, Util::CLTimeParserE($sum), 1, 0, "R"); //removed parser 20220401 customer had both tables
		}
		$class->ln(10);
		
		$class->Line($class->marginLeft, $class->GetY(), $class->w - $class->marginRight, $class->GetY());
	}
	
	public static function adviceNewGRLBM($class, $args){

		#$G->changeA("GRLBMServiceVon", "-1");
		#$G->changeA("GRLBMServiceBis", "-1");
		#$G->changeA("GRLBMServiceStunden", "-1");
		#$G->changeA("GRLBMServiceStundensatz", Util::CLNumberParserZ(mUserdata::getUDValueS("DefaultValueGRLBMGRLBMServiceStundensatz", Util::CLNumberParserZ(0)), "store"));
		
		if(Session::physion() !== null AND Session::physion()[0] == "EnvironmentExternalService"){
			$S = anyC::getFirst("GRLBMService", "GRLBMServiceGRLBMID", $args[0]);
			if($S){
				$S->changeA("GRLBMServiceMitarbeiter", Session::currentUser()->getID());
				$S->saveMe();
			}
		}
	}
	
	public static function adviceCopy($class, $fromId){
		$fromGRLBM = new GRLBM($fromId, false);
		if($fromGRLBM->getMyprefix() != "S" AND $fromGRLBM->getMyprefix() != "Au")
			return;
		
		$GRLBM = new GRLBM($class->getID(), false);
		$Auftrag = new Auftrag($GRLBM->A("AuftragID"));
		$Adresse = new Adresse($Auftrag->A("AdresseID"));
		
		$U = Users::getUsersArray();
		
		$mwst = Posten::calcMwst($Adresse);
		$addDesc = self::$showDescriptionInPosition;
		for($i = 1; $i <= 4; $i++){
			$p = $i;
			if($i == 1)
				$p = "";
			
			if($fromGRLBM->A("GRLBMServiceMitarbeiter$p") == 0 OR $fromGRLBM->A("GRLBMServiceMitarbeiter$p") == "")
				continue;
			
			$menge = $fromGRLBM->A("GRLBMServiceStunden$p") / 3600;
			
			$PID = $GRLBM->addPosten("Arbeitszeit".(isset($U[$fromGRLBM->A("GRLBMServiceMitarbeiter$p")]) ? " ".$U[$fromGRLBM->A("GRLBMServiceMitarbeiter$p")] : ""), "Stunden", $menge, $fromGRLBM->A("GRLBMServiceStundensatz$p"), $mwst, $addDesc ?  strip_tags($fromGRLBM->A("textbausteinUnten")) : "", false, null, 0, 0, ["obeySortOrder" => true]);
			$Posten = new Posten($PID, false);
			
			if($i == 1 AND $class->CustomizerPostenAddLabelInsertOrigin){
				$AC = anyC::get("Posten", "GRLBMID", $fromId);
				$AC->setLimitV3(1);
				$num = $AC->getTotalNum();
				if($num == 0 AND $fromGRLBM->A("AuftragID") == $GRLBM->A("AuftragID")){
					
					if($Posten->A("PostenAddLine") !== null){
						$copyLabel = "";
						try {
							$C = new CustomizerPostenAddLabelGUI();
							$copyLabel = CustomizerPostenAddLabelGUI::getCopyLabel($fromGRLBM, $Posten->A("PostenAddLine"));
						} catch (Exception $e){}
						
						$Posten->changeA("PostenAddLine", Aspect::joinPoint("alterCopyLabel", "GRLBM", __METHOD__, array($fromGRLBM), $copyLabel));
						
					}
				}
			}
			$Posten->changeA("artikelnummer", "AZ-".str_pad($fromGRLBM->A("GRLBMServiceMitarbeiter$p"), 4, "0", STR_PAD_LEFT));
			$Posten->saveMe();
			
			$addDesc = false;
		}
	
		$GRLBM->changeA("GRLBMpayedVia", $fromGRLBM->A("GRLBMpayedVia"));
		$GRLBM->changeA("zahlungsbedingungenID", $fromGRLBM->A("zahlungsbedingungenID"));
		$GRLBM->getSumOfPosten(false, true);
		#$GRLBM->saveMe();
	}
	
}
?>