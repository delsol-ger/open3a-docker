<?php
/*
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;
class exportLieferantenGUI extends exportDefault implements iExport, iGUIHTML2 {

	private $Kategorien = array();

	public function getLabel(){
		if(!Session::isPluginLoaded("mLieferant"))
			return null;
		
		return "Lieferanten";
	}
	
	public function getApps(){
		return array("open3A", "openWaWi");
	}

	public function getHTML($id){
		$p = parent::getHTML($id);
		
		return $p;
	}

	public function getExportCollection($start = null, $count = null, $Adressbuch = 0, $ProjektID = 0){
		$ac = new anyC();
		$ac->setCollectionOf("Kategorie");
		$ac->addAssocV3("type", "=", "1");

		while($a = $ac->getNextEntry())
			$this->Kategorien[$a->getID()] = $a->A("name");


		$ac = anyC::get("Lieferant");
		#$ac->addJoinV3("Kappendix", "AdresseID", "=", "AdresseID");
		#$ac->addAssocV3("AuftragID", "=", "-1");
		#if(Session::isPluginLoaded("mAdressBuch") AND $Adressbuch)
		#	$ac->addAssocV3("type", "=", $Adressbuch);
		
		#if(Session::isPluginLoaded("mProjekt") AND $ProjektID)
		#	$ac->addAssocV3("AdresseProjektID", "=", $ProjektID);
			
		
		$ac->setFieldsV3(array(
			#"anrede",
			#"nachname",
			#"vorname",
			#"anrede AS Anrede",
			"LieferantFirma AS Firma",
			#"vorname AS Vorname",
			#"nachname AS Nachname",
			"LieferantStrasse AS Strasse",
			"LieferantHausnummer AS Hausnummer",
			"LieferantPLZ AS PLZ",
			"LieferantOrt AS Ort",
			"LieferantLand AS Land",
			"LieferantTel AS Telefon",
			"LieferantFax AS Fax",
			"LieferantEMail AS EMail",
			"LieferantHomepage AS Homepage",
			#"mobil AS Mobil",
			"LieferantKategorieID AS Kategorie",
			"LieferantBemerkung AS Bemerkung",
			"LieferantKundennummer AS Kundennummer",
			#"t2.UStIdNr AS UStIdNr",
			#"anrede AS Anrede2",
			#"titelPrefix AS TitelPrefix",
			#"titelSuffix AS TitelSuffix",
			#"abteilung AS Abteilung",
			#"position AS Position"
			));

		return $ac;
	}

	protected function entryParser(PersistentObject $entry){

		if(isset($this->Kategorien[$entry->A("LieferantKategorieID")]))
			$entry->changeA("Kategorie", $this->Kategorien[$entry->A("LieferantKategorieID")]);
		else $entry->changeA("Kategorie", "");

		$A = $entry->getA();
		unset($A->LieferantID);
	}
}
?>
