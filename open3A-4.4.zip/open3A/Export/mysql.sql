CREATE TABLE `Exp` (
  `ExpID` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `plugin` varchar(20) NOT NULL DEFAULT '',
  `felder` varchar(255) NOT NULL DEFAULT '',
  `selectors` text NOT NULL,
  `filename` varchar(50) NOT NULL DEFAULT '',
  `type` varchar(10) NOT NULL DEFAULT '',
  `sep` varchar(10) NOT NULL DEFAULT '',
  `newline` varchar(10) NOT NULL DEFAULT '',
  `kodierung` varchar(15) NOT NULL,
  `sort` text NOT NULL,
  `showID` tinyint(1) NOT NULL,
  `textSep` varchar(10) NOT NULL,
  PRIMARY KEY (`ExpID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='open3A_1.5;';
-- END
INSERT INTO `Exp` VALUES
(1,'Adressen für Serienbrief','Adressen','firma, vorname, nachname, strasse, nr, plz, ort','','serienbrief.txt','txt',',','Unix','UTF-8','',0,'2');
-- END
