<?php
/*
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;
class exportBelegeVersandkostenGUI extends exportBelegeGUI implements iExport {
	function __construct() {
		#$this->usedDate = "GRLBMpayedDate";
		$this->belege = array("R");
		$this->fileLabel = "Rechnungen_Versandkosten";
	}

	public function getLabel(){
		try {
			$T = new CustomizerBelegVersand();
			return "Versandkosten nach Belegdatum";
		} catch (Exception $ex) {
			return null;
		}
		
	}

	public function formatData($i, $C, $Kundennummer, $Anrede, $mwst, $sums, $sum, $parsedData){
		return array(
			$Kundennummer,
			$Anrede,
			$C->A("firma"),
			$C->A("vorname"),
			$C->A("nachname"),
			$C->A("prefix").$C->A("nummer"),
			Util::CLDateParser($C->A("datum")),
			Util::CLDateParser($C->A("lieferDatum")),
			"",
			"",
			GRLBM::getPaymentVia($C->A("GRLBMpayedVia")),
			"",
			Util::CLDateParserE($C->A("GRLBMpayedDate")),
			"",
			$C->A("versandkosten"),
			$C->A("versandkostenMwSt"),
			""
		);
	}
}
?>