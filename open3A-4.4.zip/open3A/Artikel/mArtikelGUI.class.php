<?php
/*
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;
class mArtikelGUI extends mArtikel implements iGUIHTMLMP2, iAutoCompleteHTML, icontextMenu, iCategoryFilter, iOrderByField, iSearchFilter {

	public $isJoined = "";
	public $searchFields = array("t1.name", "artikelnummer", "beschreibung", "bemerkung", "artikelnummerHersteller", "EAN");
	public static $ids = array();
	public static $artikelMitStueckliste = array();
	public static $artikelMitLieferant = array();
	public $showHasNoSupplier = true;
	 
	function __construct(){
		parent::__construct();
		$bps = $this->getMyBPSData();
		#print_r($bps);
		#echo "<pre>";
		#print_r($_SESSION["BPS"]);
		#echo "</pre>";
		
		#$this->setParser("bruttopreis","Util::CLNumberParserZ"); #commented out for calculation in preisParser()
			
		if(Session::isPluginLoaded("Kundenpreise") 
			AND !mUserdata::getPluginSpecificData("mArtikel", "pluginSpecificHidePrices") 
			AND $bps != -1 
			AND $_SESSION["BPS"]->isPropertySet(get_class($this),"kundennummer")){
				
			$this->setParser("kundenPreis","Util::CLNumberParserZ");
				
			$this->addJoinV3("Kundenpreis", "ArtikelID", "=", "ArtikelID");
			$this->addJoinV3("Kundenpreis", "kundennummer", "=", $bps["kundennummer"]);
			$this->addJoinV3("Kundenpreis", "KundenpreisVarianteArtikelID", "=", "0");
			
			$this->isJoined .= "K";
		}
		
		if(Session::isPluginLoaded("mLieferant") AND BPS::getProperty("mArtikelGUI", "lieferantFilter", "0") != "0"){
			$LID = BPS::getProperty("mArtikelGUI", "lieferantFilter", "0");
			$this->addJoinV3("LieferantPreis", "ArtikelID", "=", "LieferantPreisArtikelID");
			$this->isJoined .= "L";

			if($LID != "-1") {
				$this->addJoinV3("LieferantPreis", "LieferantPreisLieferantID", "=", $LID);
				$this->addAssocV3("LieferantPreisVarianteArtikelID", "=", "0");
				$this->addAssocV3("LieferantPreisID", "IS NOT", "NULL");
				$this->addGroupV3("t1.ArtikelID");
			} else 
				$this->addAssocV3("LieferantPreisID", "IS", "NULL");
		}
		
		if(Session::isPluginLoaded("mLager") AND BPS::getProperty("mArtikelGUI", "lagerFilter", "0") > 0){
			$LID = BPS::getProperty("mArtikelGUI", "lagerFilter", "0");
			$this->addJoinV3("Lagerbestand", "ArtikelID", "=", "LagerbestandOwnerClassID");
			$this->addJoinV3("Lagerbestand", "LagerbestandOwnerClass", "=", "LArtikel");
			$this->isJoined .= "A";

			$this->addAssocV3("LagerbestandLagerID", "=", $LID);
		}
		
		$this->customize();
		
	}
	
	function getAvailableCategories(){
		$kat = new Kategorien();
		$kat->addAssocV3("type","=","2");
		$kat->addOrderV3("name");
		
		return $kat->getArrayWithKeysAndValues();
	}
	
	function getCategoryFieldName(){
		return "t1.KategorieID";
	}
	
	private static $KIDs = [];
	function getHTML($id, $page){
		T::load(__DIR__, "mArtikel");
		$bps = $this->getMyBPSData();
		
		$this->addJoinV3("Kategorie", "KategorieID", "=", "KategorieID");
		$this->addOrderV3("t".(strlen($this->isJoined)+2).".name", "ASC");
		$this->addOrderV3("t1.KategorieID");
		$this->addOrderV3("t1.name");
		$fields = array("t1.*");
		if(strpos($this->isJoined, "K") !== false)
			$fields[] = "kundenPreis";
		$this->setFieldsV3($fields);
		
		$gui = new HTMLGUIX($this);
		$gui->version("mArtikel");
		$gui->tip();
		$gui->screenHeight();
		
		if(!mUserdata::getUDValueS("OrderByFieldInHTMLGUI".$this->getClearClass()))
			$gui->displayGroup($this->getCategoryFieldName(), "mArtikelGUI::DGParser");

		$shownFields = array("name", "preis");

		$gui->options(true, true, true, true);
		
		$gui->displayGroup("KategorieID", "mArtikelGUI::parserDG");
		
		if(strpos($this->isJoined, "K") !== false) {
			$gui->parser("kundenPreis","mArtikelGUI::kPParser");
			
			$shownFields = array_merge(array("kundenPreis"), $shownFields);
		}

		$gui->parser("preis", "preisParser");
		
		$gui->attributes($shownFields);

		$gui->parser("name","mArtikelGUI::nameParser");
		$gui->colStyle("preis", "text-align:right;");
		$gui->customize($this->customizer);
		$this->filterCategories();
		$this->loadMultiPageMode($id, $page, 0);
		
		if(strpos($this->isJoined, "K") !== false) {
			while($A = $this->n())
				if($A->A("KategorieID") > 0 AND isset($bps["kundennummer"]))
					self::$KIDs[$A->A("KategorieID")] = Kundenpreis::getKategorie($A->A("KategorieID"), $bps["kundennummer"]);
			
			$this->resetPointer();
		}
		#echo "<pre>";
		#print_r(DBStorage::$lastQuery[count(DBStorage::$lastQuery) - 1]);
		#echo "</pre>";
		$this->findOptions($this);
		
		$gui->object($this);//to be able to set sort order via customizer
		
		#if(Session::isPluginLoaded("mEtikette"))
		#	$gui->addSideButton(Etikette::getButton("mArtikel", "-1"));

		if(Session::isPluginLoaded("mEtikette") AND Session::isPluginLoaded("Kategorien")){
			$B = $gui->addSideButton("Etiketten\ndrucken", "./ubiquitous/Etiketten/Etiketten.png");
			$B->popup("", "Etiketten drucken", "mArtikel", "-1", "etikettenPopup");
		}
		
		if(Session::isPluginLoaded("mPreiserhoehung")  AND Session::isPluginLoaded("Kategorien"))
			$gui->addSideButton(Preiserhoehung::getButtonMulti("Artikel"));
		
		if(Session::isPluginLoaded("mPreiserhoehung"))
			$gui->addSideButton(Preiserhoehung::getButtonExecute());
		
		$B = $gui->addSideButton("Duplikate\nfinden", "./open3A/Adressen/duplikate.png");
		$B->popup("", "Duplikate finden", "mArtikel", "-1", "duplikatePopup", ["'artikelnummer'"], "", "{width:600}");
		
		$TLF = "";
		if(Session::isPluginLoaded("mLieferant") AND $id == -1){
			$TLF = new HTMLTable(1);
			$TLF->addTableClass("browserContainerSubHeight");
			$AC = anyC::get("Lieferant");
			$AC->addOrderV3("LieferantFirma");
			
			$I = new HTMLInput("lieferantenFilter", "select", BPS::getProperty("mArtikelGUI", "lieferantFilter", "0"));
			$I->setOptions($AC, "LieferantFirma", T::_("alle Lieferanten"), $this->showHasNoSupplier ? array("-1" => T::_("ohne Lieferant")) : null);
			$I->onchange(OnEvent::rme($this, "setLieferantFilter", array("this.value"), OnEvent::reload("Right")));
			$TLF->addRow(array($I));
		}
		
		$gui->prepend($TLF);
		return $gui->getBrowserHTML($id);

	}
	
	public function duplikatePopup($criteria = "artikelnummer"){
		$AC = anyC::get("Artikel");
		$AC->addAssocV3($criteria, "!=", "");
		$AC->addGroupV3($criteria);
		$AC->addHavingV3("COUNT($criteria)", ">", "1");
		$AC->setFieldsV3(["$criteria", "GROUP_CONCAT(t1.ArtikelID SEPARATOR ',') AS ids", "COUNT($criteria) AS anzahl"]);
		
		$VIDs = [];
		if(Session::isPluginLoaded("mVertrag")){
			$ACV = anyC::get("VertragPosten");
			$ACV->addGroupV3("VertragPostenArtikelID");
			while($V = $ACV->n())
				$VIDs[$V->A("VertragPostenArtikelID")] = true;
		}
		
		$I = new HTMLInput("criteria", "select", $criteria, ["artikelnummer" => "Artikelnummer", "name" => "Artikelname"]);
		$I->onchange(OnEvent::reloadPopup("mArtikel", "", "'+this.value+'"));
		$I->style("width:130px;");
		
		echo "<p>Durchsucht die Artikel-Datenbank nach Artikeln mit dem/der gleichen $I.</p>";
		
		echo "<div style=\"max-height:500px;overflow:auto;\"><form id=\"duplikateForm\">";
		$B = new Button("Artikel öffnen", "arrow_left", "iconic");
		
		while($A = $AC->n()){
			$ACS = anyC::get("Artikel");
			$ACS->addAssocV3("t1.ArtikelID", "IN", "(".$A->A("ids").")");
			$ACS->addOrderV3("t1.ArtikelID");
			
			$actions = [
				"nothing" => "Nichts tun", 
				"delete" => "Löschen"
				];
			
			$T = new HTMLTable(4, $A->A($criteria).": ".$A->A("anzahl")." Artikel");
			$T->addColStyle(2, "text-align:right;font-weight:bold;");
			$T->addColStyle(4, "text-align:right;");
			$T->setColWidth(1, "20px");
			$T->setColWidth(2, "60px");
			$T->setColWidth(4, "150px");
			#$T->useForSelection(false);
			#while($AS = $ACS->n())
			#	$actions["merge_".$AS->getID()] = "Verschmelze mit ".$AS->getID();
			
			#$ACS->resetPointer();
			
			while($AS = $ACS->n()){
				$aktions = array_slice($actions, 0);
				unset($aktions["merge_".$AS->getID()]);
				
				$ACC = anyC::get("Posten", "oldArtikelID", $AS->getID());
				$ACC->addJoinV3("GRLBM", "GRLBMID", "=", "GRLBMID");
				$ACC->addGroupV3("oldArtikelID");
				$ACC->setFieldsV3(["COUNT(*) AS anzahl", "MAX(datum) AS maxDatum"]);
				$ACV = $ACC->n();
				$belege = 0;
				if($ACV)
					$belege = $ACV->A("anzahl");
				
				$BV = "";
				$BS = "";
				$aktion = new HTMLInput("action_".$AS->getID(), "select", "nothing", $aktions);
				$aktion->style("width:100%;");
				if(isset($VIDs[$AS->getID()])){
					$aktion->isDisabled(true);
					$BV = new Button("Vertrag anzeigen", "./open3A/Vertrag/vertrag.png", "icon");
					$BV->style("float:right;margin-left:10px;");
					$BV->popup("", "Verträge", "Artikel", -1, "vertraegePopup", array($AS->getID()));
				}
				
				$T->addRow([
					$B,
					$AS->getID(),
					$BS.$BV.$AS->A("name")."<br><small style=\"color:grey;\">".$belege." ".($belege == 1 ? "Beleg" : "Belege")." ".($belege > 0 ? "Zuletzt ".Util::CLDateParser($ACV->A("maxDatum")) : "")."</small>",
					$aktion
				]);
				
				$T->addCellStyle(1, "cursor:pointer;");
				$T->addCellStyle(2, "cursor:pointer;");
				$T->addCellEvent(1, "click", OnEvent::frame("Left", "Artikel", $AS->getID()));
				$T->addCellEvent(2, "click", OnEvent::frame("Left", "Artikel", $AS->getID()));
			}
			
			echo $T;
		}
		
		$B = new Button("Änderungen\nübernehmen", "bestaetigung");
		$B->style("margin:5px;float:right;");
		$B->onclick(OnEvent::rme($this, "duplikateDo", ["joinFormFields('duplikateForm')"], OnEvent::reloadPopup("mArtikel").OnEvent::reload("Right")));
		$B->loading();
		
		echo "</form></div>$B";
	}
	public function duplikateDo($data){
		parse_str($data, $result);
		
		foreach($result AS $field => $action){
			if($action == "nothing")
				continue;
			
			$ArtikelID = str_replace("action_", "", $field);
			if($action == "delete"){
				$A = new Artikel($ArtikelID);
				$A->deleteMe();
				continue;
			}
		}
	}
	
	public function etikettenPopup(){
		$F = new HTMLForm("etiketten", array("etikette", "auswahl"));
		$F->getTable()->setColWidth(1, 120);
		$F->useRecentlyChanged();
		
		$AC = anyC::get("Kategorie");
		$AC->addAssocV3("type","=","2");
		while($K = $AC->n()){
			$K->changeA("name", "Kategorie '".$K->A("name")."'");
		}
		$AC->resetPointer();
		$K = $AC->toArray("name", "Aktuelle Auswahl");
			
		$F->setType("auswahl", "select", 0, $K);
		
		$AC = anyC::get("Etikette");
		$E = $AC->toArray("EtiketteName");
		
		$F->setType("etikette", "select", 0, $E);
		
		#$F->setSaveRMEPCR("Etiketten anzeigen", "", "mArtikel", "-1", "etikettenSave", OnEvent::closePopup("mArtikel"));
		$F->setSaveWindowRMEPCR("Etiketten anzeigen", "", "mArtikel", -1, "etikettenSave");
		
		echo $F;
	}
	
	public function etikettenSave($EID, $KID){
		BPS::setProperty("EtiketteGUI", "className", "mArtikel");
		BPS::setProperty("EtiketteGUI", "classID", "-1");
		BPS::setProperty("mAtikelGUI", "etikettenKID", $KID);
		
		$E = new EtiketteGUI($EID);
		if($E->A("EtiketteVorschau")){
			$mA = new mArtikel();
			echo $E->getPreview(count($mA->getEtiketten()));
			return;
		}
		
		$E = new EtikettenPDFGUI($EID);
		echo $E->getPDF("");
	}

	public function checkBestand(){
		$checks = func_get_args();
		
		
		foreach($checks AS $hcheck){
			$exh = explode("#", $hcheck);
			
			foreach($exh AS $check){
				$ex = explode(":", $check);
				$ex2 = explode("_", $ex[0]);
				$ex3 = explode(",", $ex[1]);

				if($ex3[0] == "melde")
					$message = "<span style=\"color:orange\">Meldebestand von $ex3[2] Stück erreicht!</span> Im Lager: $ex3[1]";

				if($ex3[0] == "mindest")
					$message = "<span style=\"color:red\">Mindestbestand von $ex3[2] Stück erreicht!</span> Im Lager: $ex3[1]";

				if($ex2[0] == "LArtikel"){
					$Artikel = new Artikel($ex2[1]);
					echo "<p class=\"prettySubtitle\">".$Artikel->A("name")."</p><p>$message</p>";
				}

				if($ex2[0] == "VarianteArtikel"){
					$Variante = new VarianteArtikel($ex2[1]);
					#$Artikel = new Artikel($ex2[1]);
					echo "<p class=\"prettySubtitle\">".$Variante->A("VarianteArtikelName")."</p><p>$message</p>";
				}
			}
		}

	}
	
	public function findOptions($AC){
		while($A = $AC->n())
			self::$ids[] = $A->getID();

		$AC->resetPointer();
		
		if(count(self::$ids) > 0 AND Session::isPluginLoaded("mStueckliste")){
			$AC = anyC::get("Stueckliste");
			$AC->addAssocV3("StuecklisteArtikelID", "IN", "(".implode(",", self::$ids).")");
			$AC->setGroupV3("StuecklisteArtikelID");
			$AC->setFieldsV3(array("StuecklisteArtikelID"));
			while($S = $AC->n())
				self::$artikelMitStueckliste[$S->A("StuecklisteArtikelID")] = true;

			#print_r(self::$artikelMitStueckliste);
		}
		
		if(count(self::$ids) > 0 AND Session::isPluginLoaded("mLieferant")){
			$AC = anyC::get("LieferantPreis");
			$AC->addAssocV3("LieferantPreisArtikelID", "IN", "(".implode(",", self::$ids).")");
			$AC->setGroupV3("LieferantPreisArtikelID");
			$AC->setFieldsV3(array("LieferantPreisArtikelID"));
			while($S = $AC->n())
				self::$artikelMitLieferant[$S->A("LieferantPreisArtikelID")] = true;
		}
		
		
	}
	
	public static function parserDG($w){
		if($w == "0") return "-";
		
		$K = new Kategorie($w);
		return $K->A("name");
	}

	public static function kPParser($w, $E){
		$m = "";
		
		if(isset(self::$KIDs[$E->A("KategorieID")]))
			$m .= "<span style=\"text-align:right;float:right;\">".Util::CLNumberParser (self::$KIDs[$E->A("KategorieID")]->A("kundenPreis"))."%<br><small style=\"color:grey;\">".T::_("Kategorierabatt")."</small></span>";
		
		if($w != "0,00" AND $w != "") 
			$m .= "<span style=\"text-align:right;float:right;\">".$w."<br><small style=\"color:grey;\">".T::_("Kundenpreis")."</small></span>";
		
		return $m;
	}
	
	public static function nameParser($w, $E){
		return self::buttonInfoOptions($E)."<span style=\"color:grey;float:right;\">".$E->A("artikelnummer")."</span>".stripslashes($w)."<br /><small style=\"color:grey;float:right;\">".$E->A("gebinde")."</small>".($E->A("bemerkung") != "" ? "<small style=\"color:grey;\">".$E->A("bemerkung")."</small>" : "");
	}
	
	public static function buttonInfoOptions($E){
		T::load(__DIR__, "mArtikel");
		
		$BUTT = array();
		#$BV = "";
		#if(Session::isPluginLoaded("mVariante"))
		#	$BV = "<div style=\"float:right;margin-left:5px;margin-bottom:5px;width:18px;height:18px;\"></div>";
		$c = 0;
		if(Session::isPluginLoaded("mVariante"))
			$c++;
		
		if(Session::isPluginLoaded("mVariante") AND Variante::has($E->getID())){
			$BV = new Button("Dieser Artikel hat Varianten", "./open3A/Varianten/hasVariant.png", "icon");
			$BV->style("float:right;margin-left:5px;margin-bottom:5px;");
			$BUTT[] = $BV;
		}
		
		#$BS = "";
		#if(Session::isPluginLoaded("mStueckliste"))
		#	$BS = "<div style=\"float:right;margin-left:5px;margin-bottom:5px;width:18px;height:18px;\"></div>";
		if(Session::isPluginLoaded("mStueckliste"))
			$c++;
		
		if(Session::isPluginLoaded("mStueckliste") AND isset(self::$artikelMitStueckliste[$E->getID()])){
			$BS = new Button("Dieser Artikel hat eine Stückliste", "./openWaWi/Stueckliste/Stueckliste18.png", "icon");
			$BS->style("float:right;margin-left:5px;margin-bottom:5px;");
			$BUTT[] = $BS;
		}
		
		#$BL = "";
		#if(Session::isPluginLoaded("mLieferant"))
		#	$BL = "<div style=\"float:right;margin-left:5px;margin-bottom:5px;width:18px;height:18px;\"></div>";
		if(Session::isPluginLoaded("mLieferant"))
			$c++;
		
		if(Session::isPluginLoaded("mLieferant") AND isset(self::$artikelMitLieferant[$E->getID()])){
			$BL = new Button("Dieser Artikel hat Lieferanten", "./openWaWi/Lieferanten/Lieferant18.png", "icon");
			$BL->style("float:right;margin-left:5px;margin-bottom:5px;");
			$BUTT[] = $BL;
		}
		
		#$BN = "";
		#if(Session::isPluginLoaded("mSeriennummer"))
		#	$BN = "<div style=\"float:right;margin-left:5px;margin-bottom:5px;width:18px;height:18px;\"></div>";
		if(Session::isPluginLoaded("mSeriennummer"))
			$c++;
		
		if(Session::isPluginLoaded("mSeriennummer") AND $E->A("hatSeriennummer")){
			$BN = new Button("Dieser Artikel hat Seriennummern", "./openWaWi/Seriennummer/Seriennummer18.png", "icon");
			$BN->style("float:right;margin-left:5px;margin-bottom:5px;");
			$BUTT[] = $BN;
		}
		
		
		$addButtons = Aspect::joinPoint("buttons", $E, __METHOD__, [], []);
		if(is_array($addButtons))
			foreach($addButtons AS $b)
				$BUTT[] = $b;
		else
			$BUTT[] = $addButtons;
		
		while(count($BUTT) < $c)
			$BUTT[] = "<div style=\"float:right;margin-left:5px;margin-bottom:5px;width:18px;height:18px;\"></div>";
		
		if(isset($BUTT[3]))
			unset($BUTT[3]);
		
		return implode("", $BUTT);
	}
	
	public static function preisParser($w, $E){
		#$E->parsers = false;
		#echo $E->hasParsers;
		return Util::CLNumberParserZ($E->getGesamtVK()).($E->A("isBrutto") == "1" ? "<br /><small style=\"color:grey;\">Brutto</small>" : "");
	}
	
	public static function mwst($w){
		return $w."%";
	}

	public function getACData($attributeName, $query, $options = true){
		$asJSON = true;
		$byID = false;
		$showBemerkung = false;
		$KategorieID = 0;
		$Varianten = false;
		$hideIDs = [];
		
		if(is_string($options) AND $options[0] == "{" AND mb_substr($options, -1) == "}"){
			$options = json_decode($options);
			if(isset($options->byID))
				$byID = $options->byID;
			
			if(isset($options->showBemerkung))
				$showBemerkung = $options->showBemerkung;
			
			if(isset($options->KategorieID))
				$KategorieID = $options->KategorieID;
			
			if(isset($options->variants))
				$Varianten = $options->variants;
			
			if(isset($options->hideIDs))
				$hideIDs = $options->hideIDs;
		} else
			$asJSON = $options;
		
		if(Session::isPluginLoaded("mSeriennummer") AND substr($query, 0, 1) == "+"){
			$SN = mb_substr($query, 1);
			$AC = anyC::get("Seriennummer", "SeriennummerNummer", $SN);
			$AC->addAssocV3("SeriennummerTargetClass", "=", "Artikel");
			$A = $AC->n();
			if($A)
				$query = "ART".($A->A("SeriennummerTargetClassID") + 10000);
		}
		
		if(substr($query, 0, 3) == "ART" AND is_numeric(substr($query, 3))){
			$id = substr($query, 3) - 10000;
			$this->addAssocV3("t1.ArtikelID", "=", $id);
		} else {
			$search = array("name","artikelnummer", "EAN", "artikelnummerHersteller");

			if(Session::isPluginLoaded("mLieferant")){
				$LP = anyC::getFirst("LieferantPreis", "LieferantPreisArtikelnummer", $query);
				if($LP)
					$this->addSearchCustom("t1.ArtikelID", "=", $LP->A("LieferantPreisArtikelID"), "OR");
			}
		
			$this->setSearchStringV3($query);
			$this->setSearchFieldsV3($search);
		}
		if($KategorieID)
			$this->addAssocV3 ("KategorieID", "=", $KategorieID, "AND", "123");
		
		if(count($hideIDs))
			$this->addAssocV3("t1.ArtikelID", "NOT IN", "(".implode(",", $hideIDs).")");
		
		$this->setFieldsV3(array(
			"name AS label", 
			$byID ? "t1.ArtikelID AS value" : "IF(artikelnummer = '', CONCAT('ART', t1.ArtikelID + 10000), artikelnummer) AS value", 
			"CONCAT(IF(artikelnummer = '', CONCAT('ART', t1.ArtikelID + 10000), artikelnummer), '<br>', beschreibung".($showBemerkung ? ", '<br>', bemerkung" : "").") AS description",
			"0 AS VarianteArtikelID"));

		if($attributeName == "artikelnummer")
			$this->setFieldsV3(array("artikelnummer AS label", "name AS value", "name AS description"));
		
		Aspect::joinPoint("alter", $this, __METHOD__, array($this, $options));
		
		$this->setLimitV3("10");
		if(!$asJSON)
			return $this;
		
		$this->lCV3();
		if(/*$this->numLoaded() == 0 AND */$Varianten AND Session::isPluginLoaded("mVariante")){
			$AC = anyC::get("VarianteArtikel");
			$AC->setSearchStringV3($query);
			$AC->setSearchFieldsV3(array("VarianteArtikelName", "VarianteArtikelNummer"));
			$AC->addJoinV3("Artikel", "VarianteArtikelArtikelID", "=", "ArtikelID");
			
			if($KategorieID)
				$AC->addAssocV3 ("KategorieID", "=", $KategorieID, "AND", "123");
			
			$AC->setFieldsV3(array(
				"VarianteArtikelName AS label", 
				$byID ? "CONCAT(t2.ArtikelID, '#', VarianteArtikelID) AS value" : "IF(VarianteArtikelNummer = '', CONCAT('ART', t2.ArtikelID + 10000, '#', VarianteArtikelID), VarianteArtikelNummer) AS value", 
				"CONCAT(IF(VarianteArtikelNummer = '', CONCAT('ART', t2.ArtikelID + 10000, '#', VarianteArtikelID), VarianteArtikelNummer), '<br>', beschreibung".($showBemerkung ? ", '<br>', bemerkung" : "").") AS description",
				"t2.ArtikelID AS ArtikelID"));
			$AC->lCV3();
			if($AC->numLoaded() > 0){
				echo $AC->asJSON();
				return;
			}
		}
		
		#$this->setParser("value", "mArtikelGUI::parserACArtikelnummer");
		echo $this->asJSON();
	}
	
	private static $artikelCount = 0;
	public function getACHTML($attributeName, $query){
		$gui = new HTMLGUI2();
		
		$query = Aspect::joinPoint("alter", $this, __METHOD__, array($query), $query);
		
		$this->setSearchStringV3($query);
		
		$bps = $this->getMyBPSData();
		$mode = "quickSearchLoadFrame";
		
		if(isset($bps["selectionMode"]) AND $bps["selectionMode"] != "") 
			$mode = "quickSearchSelectionMode";
			
		$fields = $this->searchFields;
		$settings = mUserdata::getUDValueS("searchmArtikel", "");
		if($settings != "")
			$fields = explode(",", $settings);
		
		if(Session::isPluginLoaded("mLieferant")){
			$LP = anyC::getFirst("LieferantPreis", "LieferantPreisArtikelnummer", $query);
			if($LP)
				$this->addSearchCustom("t1.ArtikelID", "=", $LP->A("LieferantPreisArtikelID"), "OR");
		}

		if(Session::isPluginLoaded("mVariante")){
			$this->addJoinV3("VarianteArtikel", "ArtikelID", "=", "VarianteArtikelArtikelID");
			$this->addSearchCustom("VarianteArtikelNummer", "=", $query, "OR");
			$this->addGroupV3("ArtikelID");
		}
		
		$this->setSearchFieldsV3($fields);#array(/*"t".(2 + strlen($this->isJoined)).".name",*/"t1.name"/*,"bemerkung","beschreibung"*/,"artikelnummer","beschreibung"));
		$this->setFieldsV3(array("t1.name", "gebinde", "bemerkung", "beschreibung", "artikelnummer"));

		$this->setLimitV3("10");
		$this->addOrderV3("t1.name","ASC");
		$this->lCV3();
		
		$this->findOptions($this);
		
		$AC = anyC::get("Artikel");
		self::$artikelCount = $AC->getAffectedRows();
		
		$gui->setObject($this);
		$gui->setShowAttributes(array("name"));
		$gui->setParser("name","mArtikelGUI::parserACName", array("\$beschreibung", "\$gebinde","\$artikelnummer", "\$aid"));
		
		$_SESSION["BPS"]->registerClass("HTMLGUI2");
		$_SESSION["BPS"]->setACProperty("targetFrame","contentLeft");
		$_SESSION["BPS"]->setACProperty("targetPlugin",$this->getCollectionOf());
		
		$gui->customize($this->customizer);
		
		$gui->autoCheckSelectionMode(get_class($this));
		echo $gui->getACHTMLBrowser($mode);
	}

	public function getContextMenuHTML($identifier){
		
		switch($identifier){
			case "searchHelp":
				$F = new HTMLFormCheckList("searchedmArtikel", $this->searchFields);
				
				foreach($this->searchFields AS $v)
					$F->setLabel($v, ucfirst(preg_replace("/[a-z0-9]+\./", "", $v)));
				
				$F->setSaveCheckListUD("mArtikel", "search", true, OnEvent::closeContext());
				
				echo "<p style=\"padding:5px;\">Es werden folgende Felder durchsucht:</p>$F<p>Sie können Ihre Suchanfrage mit UND verknüpfen.<br/>Also z.B. \"Artikelnummer UND Artikelname\"</p>";
			break;
		}
		
	}
	
	public static function parserACName($w, $l, $p){
		$p = HTMLGUI::getArrayFromParametersString($p);
		$p[0] = str_replace("\n", " ", $p[0]);
		$Artikel = new Artikel($p[3]);
		
		if(self::$artikelCount < 50000)
			$preis = Util::CLNumberParserZ($Artikel->getGesamtNettoVK())." / ";
		else
			$preis = "";
		
		return self::buttonInfoOptions($Artikel)."<div style=\"float:right;color:grey;text-align:right;\">$p[2]<br><small>$preis$p[1]</small></div>".$w."<br><small style=\"color:grey;\">".(strlen($p[0]) > 45 ? substr($p[0], 0, 45)."..." : $p[0])."</small>";
	}
	
	public function setLieferantFilter($LieferantID){
		BPS::setProperty("mArtikelGUI", "lieferantFilter", $LieferantID);
	}
	
	public function setLagerFilter($LagerID){
		BPS::setProperty("mArtikelGUI", "lagerFilter", $LagerID);
	}
	
	public static function numberParser($w,$l){
		if($l == "load") return number_format($w, 2, ",", "");
		if($l == "store") return str_replace(",",".",$w);
	}


	public static function doSomethingElse(){
		if(!isset($_SESSION[$_SESSION["applications"]->getActiveApplication()]["kategorien"]))
			$_SESSION[$_SESSION["applications"]->getActiveApplication()]["kategorien"] = array();

		$_SESSION[$_SESSION["applications"]->getActiveApplication()]["kategorien"]["Artikel"] = "2";
		$_SESSION[$_SESSION["applications"]->getActiveApplication()]["kategorien"]["Mehrwertsteuer"] = "mwst";
	}

	public function getOrderByFields() {
		return array("name" => "Artikelname", "artikelnummer" => "Artikelnummer");
	}

	public function getSearchedFields() {
		$fields = $this->searchFields;
		$settings = mUserdata::getUDValueS("searchmArtikel", "");
		if($settings != "")
			$fields = explode(",", $settings);
		
		return $fields;
	}
}
?>
