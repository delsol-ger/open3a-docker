<?php
/*
 *  This file is part of phynx.

 *  phynx is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  phynx is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  2007 - 2023, open3A GmbH - Support@open3A.de
 */
class DesktopGUI extends UnpersistentClass implements iGUIHTML2 {
	private $zuckerfest = [ //infos von http://islam.de/2860
		"20220502",
		"20230421",
		"20240410",
		"20250330",
		"20260320",
		"20270309"
	];
	
	public function getHTML($id){
		$this->customize();
		
		if(Applications::activeApplication() != "supportBox" AND $_SESSION["S"]->isUserAdmin()) {
			$D = new ADesktopGUI();
			return $D->getHTML($id);
		}
		
		$c = Applications::activeApplication()."DesktopGUI";

		try {
			$c = new $c();
			
			if($id == "1")
				return "
					<div class=\"DesktopCol\"><div id=\"desktopRight\" style=\"padding:10px;\">".$c->getHTML($id)."</div></div>
					<div class=\"DesktopCol DesktopCol2\"><div id=\"desktopMiddle\" style=\"padding:10px;width:90%;margin:auto;\"></div></div>
					<div class=\"DesktopCol DesktopCol3\"><div id=\"desktopLeft\" style=\"padding:10px;\"></div></div>
					".OnEvent::script(OnEvent::frame("desktopLeft", "Desktop", "2").OnEvent::frame("desktopMiddle", "Desktop", "3"))."<div style=\"clear:both;\"></div>";
			
			return $c->getHTML($id);
		} catch(ClassNotFoundException $e) {}
	
		
		$data = ADesktopGUI::dataGet();
		
		$backgroundStyle = "";
		/*try {
			if(file_exists(Util::getRootPath()."ubiquitous/Hintergrundbilder")){
				require_once Util::getRootPath()."ubiquitous/Hintergrundbilder/Hintergrundbild.class.php";

				$HG = Hintergrundbild::find();
				if($HG)
					$backgroundStyle = "background-image: url(".$HG->A("HintergrundbildImageURL").");background-size: cover;background-position: bottom center;background-repeat: no-repeat;";

			}
		} catch (Exception $ex) {

		}*/
		
		$message = "<small style=\"color:#aaa;\">Willkommen bei</small>
			<br>".Applications::activeApplicationLabel()."!";
		$style = "letter-spacing: 0.2em;";
		
		$isZuckerfest = false;
		$D = new Datum();
		for($i = 0; $i <= 3; $i++){
			if(in_array(date("Ymd", $D->time()), $this->zuckerfest))
				$isZuckerfest = true;
			
			$D->addDay();
		}
		
		if($isZuckerfest){
			$message = "<small style=\"color:#aaa;\">".Applications::activeApplicationLabel()." wünscht Ihnen</small><br>ein frohes <a href=\"https://de.wikipedia.org/wiki/Fest_des_Fastenbrechens\" target=\"_blank\">Zuckerfest</a>!";
			$style = "letter-spacing: 0.1em;";
			$backgroundStyle = "background-image: url(./images/seasons/sweets.svg);background-size:35%;background-position: 99% 1em;background-repeat: no-repeat;";
		}
		
		if(date("md") >= 1201 AND date("md") < 1224){
			$message = "<small style=\"color:#aaa;\">".Applications::activeApplicationLabel()." wünscht Ihnen</small><br>eine schöne Adventszeit!";
			$style = "letter-spacing: 0.1em;";
			$backgroundStyle = "background-image: url(./images/seasons/advent.svg);background-size:50%;background-position: 99% 2em;background-repeat: no-repeat;";
		}
		
		if(date("md") >= 1224 AND date("md") < 1227){
			$message = "<small style=\"color:#aaa;\">".Applications::activeApplicationLabel()." wünscht Ihnen</small><br>frohe Weihnachten!";
			$style = "letter-spacing: 0.1em;";
			$backgroundStyle = "background-image: url(./images/seasons/advent.svg);background-size:50%;background-position: 99% 2em;background-repeat: no-repeat;";
			#$backgroundStyle = "background-image: url(./images/seasons/weihnachten.svg);background-size:20em;background-position: 94% 2em;background-repeat: no-repeat;";
		}
		
		if(date("md") >= 101 AND date("md") < 107){
			$message = "<small style=\"color:#aaa;\">".Applications::activeApplicationLabel()." wünscht Ihnen</small><br>ein gutes neues Jahr!";
			$style = "letter-spacing: 0.1em;";
			$backgroundStyle = "background-image: url(./images/seasons/advent.svg);background-size:50%;background-position: 99% 2em;background-repeat: no-repeat;";
		}
		
		#if($message != "")
		#	$message = "<br><small style=\"display:inline-block;padding-top:1em;\">$message</small>";
		
		$html = "<div class=\"SpellbookContainer\" style=\"margin-right:0;$backgroundStyle\">
			<h1 class=\"prettyTitle\" style=\"text-align:center;font-size:4em;color:#444;padding-top:1.8em;padding-bottom:1.7em;$style\">
			$message</h1>";
		
		$B = new Button("Öffnen", "arrow_right", "iconicG");
		
		$T = new HTMLTable(2);
		$T->setColWidth(2, 20);
		$T->useForSelection(false);
		$T->weight("lightlyColored");
		
		if(Session::isPluginLoaded("mHilfe")){
			$T->addRow(["Die ersten Schritte mit open3A", $B]);
			if(mUserdata::getUDValueS("firstStepsSeen", "0") != "1"){
				$T->addRowClass("confirm");
				$T->addRowStyle("font-weight:bold;");
			}
			
			$T->addRowEvent("click", OnEvent::window(new mHilfeGUI(), "firstSteps"));
			
			$T->addRow(["Das Hilfe-Plugin", $B]);
			$T->addRowEvent("click", OnEvent::frame("Screen", "mHilfe"));
		}
		
		#$T->addRow(["Der Blog", $B]);
		#$T->addRowEvent("click", "window.open('https://www.open3a.de/page-Blog');");
		
		$T->addRow(["Die angezeigten Reiter anpassen", $B]);
		$T->addRowEvent("click", OnEvent::frame("Screen", "Spellbook"));
		
		#$T->addRow(["Das Forum <span style=\"color:grey;\">(Webseite)</span>", $B]);
		#$T->addRowEvent("click", "window.open('https://forum.furtmeier.it/');");
		
		$T->addRow(["E-Mail-Anfrage stellen <span style=\"color:grey;\">(Webseite)</span>", $B]);
		$T->addRowEvent("click", "window.open('https://www.open3a.de/page-Kontakt');");
		
		#$T->addRow(["Video aufnehmen <span style=\"color:grey;\">(Webseite)</span>", $B]);
		#$T->addRowEvent("click", "window.open('https://www.open3a.de/VHS','open3A VHS','height=650,width=875,scrollbars=yes,resizable=yes');");
		
		#$T->addRow(["Video aufnehmen", $B]);
		#$T->addRowEvent("click", OnEvent::window(new SupportGUI(), "captureVideo", "", "", "", "{width:500, height:300}"));
		
		if(!isset($data->hotline)){
			$T->addRow(["Hotline-Zeiten und Rufnummer <span style=\"color:grey;\">(Webseite)</span>", $B]);
			$T->addRowEvent("click", "window.open('https://www.open3a.de/page-Support');");

			$T->addRow(["Fernwartung herunterladen", $B]);
			$T->addRowEvent("click", OnEvent::popup("Fernwartung herunterladen", "Desktop", "-1", "popupFernwartung"));
		}
		
		$html .= $this->spell(new Button("Unterstützung", "hilfe", "icon"), "Unterstützung", $T);
		
		#https://www.open3a.de/page-Abo
		
		if(isset($data->webinare) AND count($data->webinare)){
			$B = new Button("Öffnen", "arrow_right", "iconicG");

			$T = new HTMLTable(3);
			$T->setColWidth(3, 20);
			$T->addColStyle(2, "text-align:right;color:grey;");
			$T->useForSelection(false);
			$T->weight("lightlyColored");

			foreach($data->webinare AS $item){
				if($item->date < time())
					continue;
				
				$T->addRow([
					$item->title,
					Util::CLDateParser($item->date).", ".Util::CLTimeParser($item->time)." Uhr",
					$B
				]);
				$T->addRowEvent("click", "window.open('$item->link');");
			}
			
			$html .= $this->spell(new Button("Webinare", "wand", "icon"), "Webinare", $T);
		}
		
		if(Environment::getS("blogShow", "1") != "0" AND Environment::getS("blogRSSURL", null) !== null){
			
			if(function_exists("curl_init")){
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 1);
				curl_setopt($ch, CURLOPT_TIMEOUT, 1); //timeout in seconds
				curl_setopt($ch, CURLOPT_URL, Environment::getS("blogRSSURL", ""));
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				$dataRSS = curl_exec($ch);
				curl_close ($ch);
			} else {
				$ctx = stream_context_create(array('https' => array('timeout' => 1)));
				$dataRSS = file_get_contents(Environment::getS("blogRSSURL", ""), 0, $ctx);
			}
			$data->blog = [];
			
			try {
				$XML = new SimpleXMLElement($dataRSS);

				$i = 0;
				foreach($XML->channel->item AS $item){
					$it = new stdClass();
					$it->title = $item->title;
					$it->date = strtotime($item->pubDate);
					$it->link = $item->link;

					$i++;
					$data->blog[] = $it;

					if($i == 7)
						break;
					
				}
				
			} catch (Exception $e){}
		}
		
		if(Environment::getS("blogShow", "1") != "0" AND isset($data->blog)){
			
			$B = new Button("Öffnen", "arrow_right", "iconicG");

			$T = new HTMLTable(2);
			$T->setColWidth(2, 20);
			$T->useForSelection(false);
			$T->weight("lightlyColored");

			foreach($data->blog AS $item){
				$T->addRow([
					$item->title,
					$B
				]);
				$T->addRowEvent("click", "window.open('$item->link');");
			}
			
			$html .= $this->spell(new Button("Blog", "blog", "icon"), Environment::getS("blogName", "open3A blog"), $T);/*.
			OnEvent::script(OnEvent::rme("ADesktop", "getOpen3ARSSHeaders", "", "function(t){ \$j('#blogContent').html(t.responseText); }"));*/
		}
		
		
		$CH = Util::getCloudHost();
		if(!$CH AND Phynx::customer() > 0 AND Phynx::abo() == "0"){
			$B = new Button("Mehr Info", "navigation");
			$B->style("float:right;margin-top:-27px;");
			$B->onclick("window.open('https://www.open3a.de/page-Abo');");
			
			$textAbo = "<div style=\"height:calc(187px - 7px - 7px);\">Ihnen gefällt open3A und Sie möchten etwas zurückgeben?<br>
				<br>
				Erzählen Sie doch Ihren Kollegen, Vorgesetzten und Kunden von open3A!<br> 
				<br>
				Oder unterstützen Sie open3A direkt mit einem Abo und Sie erhalten - zusätzlich zur immer aktuellen Version - <strong>10% Rabatt!</strong> 
				auf Ihre verwendeten Pakete und Plugins.</div>$B";
			
			$html .= $this->spell(new Button("Cloud", "support", "icon"), "Abo", $textAbo);
		}
		
		
		
		if(Session::isPluginLoaded("mShop") AND Phynx::customer() == "0"){
			$B = new Button("Zum Shop", "navigation");
			$B->loadPlugin("contentScreen", "mShop");
			$B->style("float:right;margin-top:-27px;");
			
			$T = "<div style=\"height:calc(187px - 7px - 7px);\">open3A ist eine Software mit vielen Möglichkeiten. Im Shop finden Sie zahlreiche Erweiterungen, die Ihre tägliche Arbeit vereinfachen. Es gibt zwei Arten:
				<ul>
					<li>Plugins - Ein Plugin fügt meist einen ganzen neuen Reiter hinzu, zum Beispiel Statistiken oder Verträge.</li>
					<li>Customizer - Kleine Erweiterungen, wie etwa für das Sortieren von Positionen oder andere Belegarten.</li>
				</ul></div>$B";
			$html .= $this->spell(new Button("Erweiterungen", "./ubiquitous/Shop/Shop.png", "icon"), "Erweiterungen", $T);
		}
		
		
		if(isset($data->hotline)){
			$T = new HTMLTable(3);
			#$T->setColWidth(3, 20);
			$T->addColStyle(2, "text-align:right;");
			$T->addColStyle(3, "text-align:right;");
			$T->weight("lightlyColored");
			#$T->useForSelection(false);
			
			foreach($data->hotline->times AS $hTime){
				$D = new Datum($hTime->start);
				$D->addDay();
				if($D->time() < time())
					continue;
				
				if($hTime->isHoliday){
					$T->addRow([
						"Urlaub: ".Util::CLDateParser($hTime->start)." bis ".Util::CLDateParser($hTime->end)
					]);
					$T->addRowColspan(1, 3);
				} else {
					$T->addRow([
						Util::CLWeekdayName(date("w", $hTime->start)),
						Util::CLDateParser($hTime->start),
						Util::CLTimeParser($hTime->timeStart)." bis ".Util::CLTimeParser($hTime->timeEnd)." Uhr"
					]);
					
					$DC = new Datum();
					$DC->normalize();
					
					if($DC->time() == $hTime->start AND date("Hi") > date("Hi", $hTime->timeStart - 3600) AND date("Hi") < date("Hi", $hTime->timeEnd - 3600))
						$T->addRowClass ("confirm");
				}
				$T->addCellStyle(1, "height:22px;");
			}
			
			$B = new Button("Fernwartung\nherunterladen", "./images/navi/fernwartung.png");
			$B->popup("", "Fernwartung herunterladen", "Desktop", -1, "popupFernwartung");
			$B->style("float:right;margin-top:-27px;");
			$B->className("confirm");
			
			$html .= $this->spell(new Button("Hotline", "hotline", "icon"), "Hotline", "<div style=\"height:calc(187px - 7px - 7px);\"><p class=\"prettySubtitle\" style=\"text-align:center;padding:12px;\"><a style=\"text-decoration:none;\" href=\"tel:".$data->hotline->number."\">".$data->hotline->number."</a></p>".$T."</div>".$B);
		}
		
		
		$noBM = mUserdata::getGlobalSettingValue("disableBackupManager", mUserdata::getUDValueS("noBackupManager", false));
		if(!$noBM){
			$htmlBackup = "";
			$F = new File(BackupManagerGUI::getBackupDir());

			if(!$F->A("FileIsWritable")) 
				$htmlBackup .= "
					<div class=\"dashboardButton\" style=\"margin-bottom:5px;\" onclick=\"contentManager.rmePCR('BackupManager', '', 'getWindow', '', 'Popup.displayNamed(\'BackupManagerGUI\',\'Backup-Manager\',transport);');\">
						<img style=\"float:right;margin-left:30px;\" src=\"./images/big/warnung.png\" />
						<p style=\"font-size:1.2em;font-weight:bold;color:#999999;\">
						open3A kann keine Sicherungen Ihrer Datenbank erstellen! <br>
						Klicken Sie hier für weitere Informationen.</p>
					</div>";

			$backedUp = BackupManagerGUI::checkForTodaysBackup();
			if($F->A("FileIsWritable") AND !$backedUp)
				$htmlBackup .= "
					<div class=\"dashboardButton\" style=\"margin-bottom:5px;\" onclick=\"contentManager.rmePCR('BackupManager', '', 'getWindow', '', 'Popup.displayNamed(\'BackupManagerGUI\',\'Backup-Manager\',transport);');\">
						<img style=\"float:right;margin-left:30px;\" src=\"./images/big/notice.png\" />
						<p style=\"font-size:1.2em;font-weight:bold;color:#999999;\">".T::_("Klicken Sie hier, um das tägliche Backup der Datenbank anzulegen.")."</p>
					</div>";

			if($F->A("FileIsWritable") AND $backedUp)
				$htmlBackup .= "
					<div class=\"dashboardButton\" style=\"margin-bottom:5px;height:auto;min-height:0px;\" onclick=\"contentManager.rmePCR('BackupManager', '', 'getWindow', '1', 'Popup.displayNamed(\'BackupManagerGUI\',\'Backup-Manager\',transport);');\">
						<p style=\"font-size:1.2em;font-weight:bold;color:#999999;\">".T::_("Ein neues Backup der Datenbank anlegen.")."</p>
					</div>";
			
			$BM = new BackupManagerGUI();
			$data = $BM->getBackupsList();
			$T = new HTMLTable(3);
			$T->addColStyle(2, "text-align:right;");
			$T->setColWidth(2, 80);
			$T->setColWidth(3, 20);
			$T->weight("lightlyColored");
			
			$B = new Button("", "check", "iconicG");
			$i = 0;
			foreach ($data as $name => $size) {
				if($i >= 3)
					break;
				
				
				$T->addRow([
					$name, 
					Util::formatByte($size,2),
					$B
				]);
				
				if($name == basename(BackupManagerGUI::getNewBackupName())) 
					$T->addRowClass ("confirm");
				
				$i++;
			}
			
			$html .= $this->spell(new Button("Datensicherung", "disk", "icon"), "Datensicherung", $htmlBackup.$T);
		}
		
		if(Util::getCloudHost() === null){
			$html .= $this->spell(new Button("Version", "version", "icon"), "Version", "<span id=\"versionContent\"></span>").
			OnEvent::script(OnEvent::rme("ADesktop", "getOpen3AVersion", "", "function(t){ \$j('#versionContent').html(t.responseText); }"));
		}
		
		$BR = "";
		if(Session::isPluginLoaded("mWebAuth")){
			$BR = new Button("WebAuth-Token\nregistrieren", "./plugins/WebAuth/WebAuth.png");
			$BR->onclick("WebAuth.newregistration(function(){".OnEvent::reload("Screen")."});");
			
			$U = new User(Session::currentUser()->getID());
			if($U->A("UserWebAuthCredentials") != ""){
				$BR = new Button("WebAuth-Token\nlöschen", "./plugins/WebAuth/lock_break.png");
				$BR->rmePCR("Spellbook", "-1", "clearToken", "", OnEvent::reload("Screen"));
			}
			#$BR->style("margin:10px;margin-left:0;");
			$BR->style("float:left;margin-top:-27px;");
			
		}
		
		$BP = new Button("Passwort\nändern", "refresh");
		$BP->style("margin:10px;margin-left:0;");
		$BP->popup("", "Passwort ändern", "Spellbook", "-1", "changePasswordPopup");
		$BP->style("float:right;margin-top:-27px;");
		
		$T = new HTMLTable(2);
		$T->weight("light");
		$T->setColWidth(1, 120);
		
		$T->addRow(["Benutzername:", Session::currentUser()->A("username")]);
		$T->addRow(["E-Mail-Adresse:", (Session::currentUser()->A("UserEmail") != "" ? Session::currentUser()->A("UserEmail") : "Nicht hinterlegt")]);
		$T->addRow(["Telefon:", (Session::currentUser()->A("UserTel") != "" ? Session::currentUser()->A("UserTel") : "Nicht hinterlegt")]);
		$T->addRow(["Position:", (Session::currentUser()->A("UserPosition") != "" ? Session::currentUser()->A("UserPosition") : "Nicht hinterlegt")]);
		
		$html .= $this->spell(new Button("Benutzer", "users", "icon"), "Benutzer", "<div style=\"height:calc(187px - 7px - 7px);\"><p style=\"padding-top:12px;padding-bottom:12px;\" class=\"prettySubtitle\">".Session::currentUser()->A("name")."</p> 
			 ".$T."</div>
				$BP$BR");
		
		
		try {
			$sk = mUserdata::getUDValueS("phynxColor", "standard");
		} catch (Exception $e){
			$sk = "standard";
		}
		
		$default = $this->getColors("standard");
		
		$collect = "";
		$TI = new HTMLTable(5);
		$TI->useForSelection(false);
		$TI->setColWidth(1, 20);
		$TI->setColWidth(3, 25);
		$TI->setColWidth(4, 25);
		$TI->setColWidth(5, 25);
		$TI->weight("lightlyColored");
		
		$T = clone $TI;
		$j = 0;
		$fp = opendir("../styles/");
		while(($file = readdir($fp)) !== false) {
			if($file[0] == ".") 
				continue;
			
			if(!is_dir("../styles/$file")) 
				continue;
			
			if($file == "tinymce")
				continue;
			if($file == "darkMode")
				continue;
			if($file == "future")
				continue;
			
			if($j == 4){
				$collect .= "<diV style=\"width:49%;display:inline-block;vertical-align:top;margin-right:2%;\">".$T."</div>";
				$T = clone $TI;
			}
			
			$label = ucfirst($file);
			if($file == "yellow")
				$label = ucfirst(T::_ ("gelb"));
			
			if($file == "grey")
				$label = ucfirst(T::_ ("grau"));
			
			if($file == "blue")
				$label = ucfirst(T::_ ("blau"));
			
			if($file == "green")
				$label = ucfirst(T::_ ("grün"));
			
			if($file == "lightBlue")
				$label = ucfirst(T::_ ("hellblau"));
			
			#if($file == "future")
			#	$label = ucfirst(T::_ ("weiß"));
			
			$matches = $this->getColors($file);
			
			$B = new Button("", "./images/i2/empty.png", "icon");
			
			if($sk == $file)
				$B = new Button("", "check", "iconicG");
			
			$T->addRow([
				$B,
				$label,
				"&nbsp;",
				"&nbsp;",
				"&nbsp;"
			]);
			
			if($sk == $file)
				$T->addRowClass ("backgroundColor1");
			
			$T->addRowEvent("click", OnEvent::rme("Colors", "saveContextMenu", ["1", "'$file'"], "function(){ ".OnEvent::frame("Screen", "Desktop")." Interface.setup();}"));
			
			for($i = 1; $i < 4; $i++)
				$T->addCellStyle($i + 2, "background-color:".(isset($matches[$i]) ? $matches[$i] : $default[$i]));
			
			$j++;
			#$kal[$file] = $label;
		}
		
		$B = new Button("", "./images/i2/empty.png", "icon");
		if(mUserdata::getUDValueS("phynxHighContrast", "") != "")
			$B = new Button("", "check", "iconicG");
		
		$T->addRow([
			$B,
			"Hoher Kontrast",
			"&nbsp;",
			"&nbsp;",
			"&nbsp;"
		]);
		$T->addRowColspan(2, 5);
		if(mUserdata::getUDValueS("phynxHighContrast", "") == "")
			$T->addRowEvent("click", OnEvent::rme("Colors", "saveContextMenu", ["5", "'./styles/standard/highContrast.css'"], "function(){ ".OnEvent::frame("Screen", "Desktop")." Interface.setup();}"));
		else
			$T->addRowEvent("click", OnEvent::rme("Colors", "saveContextMenu", ["5", "''"], "function(){ ".OnEvent::frame("Screen", "Desktop")." Interface.setup();}"));
		
		$collect .= "<diV style=\"width:49%;display:inline-block;vertical-align:top;\">".$T."</div>";
		
		
		#$html .= "<div class=\"backgroundColor4\" style=\"padding:10px;\">";
		$html .= $this->spell(new Button("Farben", "farben", "icon"), "Farben", $collect, true);
		
		
		
		$sk2 = mUserdata::getUDValueS("phynxLayout", "horizontal");
		$layouts = ["horizontal" => "Horizontal", "vertical" => "Vertikal", "desktop" => "Desktop", "fixed" => "Fixiert"];
		
		$T = new HTMLTable(2);
		$T->useForSelection(false);
		$T->setColWidth(1, 20);
		$T->weight("lightlyColored");
		
		foreach($layouts AS $k => $v){
			$B = new Button("", "./images/i2/empty.png", "icon");
			
			if($sk2 == $k)
				$B = new Button("", "check", "iconicG");
			
			$T->addRow([
				$B,
				$v
			]);
			
			if($sk2 == $k)
				$T->addRowClass ("backgroundColor1");
			
			$T->addRowEvent("click", OnEvent::rme("Colors", "saveContextMenu", ["2", "'$k'"], "function(){ ".OnEvent::frame("Screen", "Desktop")." Interface.setup();}"));
		}
		
	
		$html .= $this->spell(new Button("Layout", "theme", "icon"), "Layout", $T, true);
		
		$sk2 = mUserdata::getUDValueS("noAutoLogout", "false");
		$values = ["false" => "Ja", "true" => "Nein"];
		
		$T = new HTMLTable(2);
		$T->useForSelection(false);
		$T->setColWidth(1, 20);
		$T->weight("lightlyColored");
		
		foreach($values AS $k => $v){
			$B = new Button("", "./images/i2/empty.png", "icon");
		
			if($sk2 == $k)
				$B = new Button("", "check", "iconicG");
			
			$T->addRow([
				$B,
				$v
			]);
			
			if($sk2 == $k)
				$T->addRowClass ("backgroundColor1");
			
			$T->addRowEvent("click", OnEvent::rme("Colors", "saveContextMenu", ["3", "'$k'"], "function(){ if(confirm('Achtung: Die Anwendung muss neu geladen werden, damit die Einstellungen wirksam werden. Jetzt neu laden?')) document.location.reload(); }"));
		}
		
		$html .= $this->spell(new Button("Einstellungen", "system", "icon"), "Einstellungen", "<p>Automatisch abmelden?</p>".$T, true);
		
		
		$iconSet = mUserdata::getUDValueS("phynxIcons", "default");
		
		$N = new stdClass();
		$N->label = "Standard";
		$N->rel = "";
		$N->examples = ["address", "rechnung", "index"];
		$N->base = "";
		
		$values = ["default" => $N];
		$hasIconSet = false;
		while($return = Registry::callNext("IconSet")){
			foreach($return AS $k => $v)
				$values[$k] = $v;
			
			$hasIconSet = true;
		}
		
		$T = new HTMLTable(3);
		$T->useForSelection(false);
		$T->setColWidth(1, 20);
		$T->setColWidth(3, 130);
		$T->addColStyle(3, "text-align:center;");
		$T->weight("lightlyColored");
		foreach($values AS $k => $v){
			$B = new Button("", "./images/i2/empty.png", "icon");

			$Bs = [];
			foreach($v->examples AS $ks => $exFile){
				$rel = $v->rel;
				if($v->base != "" AND !file_exists($v->folder.$exFile))
					$rel = $values[$v->base]->rel;
				
				$B0 = new Button("", $rel.$exFile, "icon");
				$B0->style("width:32px;height:32px;".($ks < 2 ? "margin-right:10px;" : ""));
				$B0->useCustom(false);
				
				$Bs[] = $B0;
			}
			
			
			if($iconSet == $k)
				$B = new Button("", "check", "iconicG");
			
			$T->addRow([$B, $v->label, implode("", $Bs)]);
			
			if($iconSet == $k)
				$T->addRowClass ("backgroundColor1");
			
			$T->addRowEvent("click", OnEvent::rme("Colors", "saveContextMenu", ["4", "'$k'"], "function(){ ".OnEvent::frame("Screen", "Desktop")." Menu.refresh();}"));
		}
		
		if($hasIconSet)
			$html .= $this->spell(new Button("Symbole", "symbole", "icon"), "Symbole", $T, true);
		
		#$html .= "<div style=\"clear:both;\"></div>";
		
		$html .= "</div>";
		return $html.Aspect::joinPoint("below", $this, __METHOD__).OnEvent::script(OnEvent::rme("ADesktop", "dataUpdate"));/*.OnEvent::script("  \$j( function() { \$j( '.SpellbookContainer' ).sortable({
      placeholder: 'highlight'
    });  \$j( '.SpellbookContainer' ).disableSelection(); } );");*/
	}

	public function popupFernwartung(){
		$data = ADesktopGUI::dataGet();
		$Buttons = [];
		foreach($data->remote AS $remote){
			$BWin = new Button($remote->label, $remote->icon);
			if(strpos($remote->link, "open3a.de"))
				$BWin->onclick("document.location.href='$remote->link'");
			else
				$BWin->onclick("window.open('$remote->link');");
			$BWin->style("margin:10px;");
			if(in_array(Util::getOS(), $remote->os))
				$BWin->addClass("confirm");
			
			$Buttons[] = $BWin;
		}
		
		/*$BWin = new Button("Windows", "./images/download_for_windows.png");
		$BWin->onclick("document.location.href='https://get.anydesk.com/UMPofNFa/AnyDesk.exe'");
		$BWin->style("margin:10px;");
		if(Util::getOS() == "Windows_64" OR Util::getOS() == "Windows_32")
			$BWin->addClass("confirm");
		
		$BLinux64 = new Button("Linux\n64 Bit", "./images/download_for_linux.png");
		$BLinux64->onclick("document.location.href='https://get.anydesk.com/4e1wED5Q/AnyDesk.tar.gz'");
		$BLinux64->style("margin:10px;");
		if(Util::getOS() == "Linux_64")
			$BLinux64->addClass("confirm");
		
		$BLinux32 = new Button("Linux\n32 Bit", "./images/download_for_linux.png");
		$BLinux32->onclick("document.location.href='https://get.anydesk.com/ihOg9zzZ/AnyDesk.tar.gz'");
		$BLinux32->style("margin:10px;");
		if(Util::getOS() == "Linux_32")
			$BLinux32->addClass("confirm");
		
		$BMac = new Button("Mac OS", "./images/download_for_mac.png");
		$BMac->onclick("document.location.href='https://get.anydesk.com/4URqWuYU/AnyDesk.dmg'");
		$BMac->style("margin:10px;");
		if(Util::getOS() == "MacOS_64")
			$BMac->addClass("confirm");*/
		
		echo '<p>Hier erhalten Sie eine Fernwartungssoftware für unterschiedliche Betriebssysteme.</p>
				<p>Bitte laden Sie die Datei für Ihr Betriebssystem herunter und führen Sie sie anschließend aus. Um eine Verbindung herzustellen, geben Sie bitte die angezeigte Nummer der Hotline durch.</p>
				<div style="text-align:center;padding-bottom:2em;">'.implode("", $Buttons).'</div>';
	}
	
	private function spell($B, $title, $content, $lessImportant = false){
		$B->style("float:left;margin-right:10px;margin-top:-7px;margin-left:-5px;width:32px;height:32px;");
		
		return "<div style=\"\" class=\"SpellbookSpell\">
			<div style=\"margin:10px;\" class=\"borderColor1 spell backgroundColor0\">
				<div class=\"backgroundColor2\" style=\"padding:10px;padding-bottom:5px;".($lessImportant ? "background-color:#CCC;" : "")."\">
					$B<h2 style=\"margin-bottom:0px;margin-top:0px;\">$title</h2>
				</div>
				<div style=\"padding:7px;height:187px;overflow:auto;\" class=\"SpellbookDescription SpellbookKeepDescription\">
					$content
				</div>
			</div>
		</div>";
	}
	
	private function getColors($style){
		$css = file_get_contents(Util::getRootPath()."styles/$style/colors.css");

		preg_match_all("/\.backgroundColor([0-9])\s+{\s+background-color:([#0-9ABCDEFabcdef]+);/", $css, $matches);
		
		$colors = [];
		foreach($matches[1] AS $k => $bgcNum)
			$colors[$bgcNum] = $matches[2][$k];
		
		
		#echo "<pre>";
		#echo $style."\n";
		#print_r($colors);
		#echo "</pre>";
		return $colors;
	}
}
?>