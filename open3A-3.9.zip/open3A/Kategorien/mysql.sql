CREATE TABLE `Kategorie` (
  `KategorieID` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `parentID` int(10) NOT NULL DEFAULT 0,
  `type` varchar(10) NOT NULL DEFAULT '0',
  `isDefault` tinyint(4) NOT NULL DEFAULT 0,
  `KategorieKlickTippTagID` varchar(20) NOT NULL,
  PRIMARY KEY (`KategorieID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='personalPlaner_0.1;';
-- END
INSERT INTO `Kategorie` VALUES (5,'19,00%',0,'mwst',1,''),(6,'8,50%',0,'mwst',0,''),(41,'0,00%',0,'mwst',0,'');
-- END
