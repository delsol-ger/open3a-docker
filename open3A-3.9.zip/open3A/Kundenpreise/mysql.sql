CREATE TABLE `Kundenpreis` (
  `KundenpreisID` int(10) NOT NULL AUTO_INCREMENT,
  `kundennummer` int(10) NOT NULL DEFAULT 0,
  `ArtikelID` int(10) NOT NULL DEFAULT 0,
  `kundenPreis` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `KundenpreisVarianteArtikelID` int(10) NOT NULL,
  PRIMARY KEY (`KundenpreisID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='open3A_1.5;';
-- END
