<?php

if(!file_exists($_GET["updateDir"]))
	die();

$updateDir = $_GET["updateDir"];
$rootPath = $_GET["rootPath"];

if(file_exists($updateDir."interface/rme.php")){
	if(rename($updateDir."interface/rme.php", $rootPath."interface/rme.php"))
		echo "rme.php verschoben";
	
}