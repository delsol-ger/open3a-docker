<?php echo "This is a database-file."; /*
host&%%%&user&%%%&password&%%%&datab&%%%&httpHost
varchar(40)&%%%&varchar(20)&%%%&varchar(20)&%%%&varchar(30)&%%%&varchar(40)                                                                                                                                                       
localhost                               &%%%&root                &%%%&                    &%%%&phynx                         &%%%&*                                       %%&&&
*/ ?>
