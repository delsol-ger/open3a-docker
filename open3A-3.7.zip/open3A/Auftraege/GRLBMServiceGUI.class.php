<?php
/**
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses></http:>.
 * 
 *  2007 - 2022, open3A GmbH - Support@open3A.de
 */
class GRLBMServiceGUI extends GRLBMService implements iGUIHTML2 {
	function getHTML($id){
		$gui = new HTMLGUIX($this);
		$gui->name("GRLBMService");
	
		return $gui->getEditHTML();
	}
	
	public static function fixGUI($class, $GUI){
		if($class->getMyPrefix() != "S")
			return;
		
		$attributes = $GUI->getShowAttributes();

		array_unshift($attributes, "GRLBMServiceIsGarantie");
		if($class->A("GRLBMServiceTerminTag") != "" OR !Session::isPluginLoaded("mTodo")){
			array_unshift($attributes, "GRLBMServiceTerminUhr");
			array_unshift($attributes, "GRLBMServiceTerminTag");
		}

		array_unshift($attributes, "GRLBMServiceMitarbeiter");


		array_unshift($attributes, "GRLBMServiceArbeitsort");
		array_unshift($attributes, "GRLBMServiceAnsprechpartner");
		array_unshift($attributes, "GRLBMServiceAuftraggeber");

		unset($attributes[array_search("textbausteinUntenID", $attributes)]);

		$GUI->setShowAttributes($attributes);


		$GUI->setLabel("GRLBMServiceIsGarantie", "Optionen");
		$GUI->setLabel("GRLBMServiceTerminTag", "Termin Tag");
		$GUI->setLabel("GRLBMServiceTerminUhr", "Termin Uhrzeit");
		$GUI->setLabel("GRLBMServiceMitarbeiter", "Mitarbeiter");

		$GUI->setLabel("GRLBMServiceArbeitsort", "Arbeitsort");
		$GUI->setLabel("GRLBMServiceAnsprechpartner", "Ansprechpartner");
		$GUI->setLabel("GRLBMServiceAuftraggeber", "Auftraggeber");

		$GUI->setType("GRLBMServiceTerminTag", "calendar");
		$GUI->setLabel("textbausteinObenID", "Beschreibung");
		$GUI->setType("zahlungsziel", "hidden");



		$GUI->setParser("GRLBMServiceArbeitsort", "GRLBMServiceGUI::parserArbeitsort");
		$GUI->setParser("GRLBMServiceIsGarantie", "GRLBMServiceGUI::parserOptionen", array($class->A("GRLBMServiceIsGarantie"), $class->A("GRLBMServiceIsAbgeschlossen"), $class->A("GRLBMServiceIsBerechnung")));

		$Auftrag = new Auftrag($class->A("AuftragID"));
		$Adresse = new Adresse($Auftrag->A("AdresseID"));
		GRLBMServiceGUI::$currentAdresse = $Adresse;
		GRLBMServiceGUI::$currentAuftrag = $Auftrag;


		$B = new Button("Aus Kunde übernehmen", "./images/i2/insert.png", "icon");
		$B->onclick("\$j('[name=GRLBMServiceAuftraggeber]').val('".addslashes($Adresse->A("firma") != "" ? $Adresse->A("firma") : $Adresse->A("vorname")." ".$Adresse->A("nachname"))."')");
		if(trim($Adresse->A("firma")) != "" OR trim($Adresse->A("vorname")." ".$Adresse->A("nachname")) != "")
			$GUI->activateFeature("addCustomButton", $class, "GRLBMServiceAuftraggeber", $B);

		$GUI->setParser("GRLBMServiceMitarbeiter", "GRLBMServiceGUI::parserMitarbeiterButton", array($class->getID()));
		self::$currentElement = $class;
		$GUI->setParser("GRLBMServiceTerminUhr", "GRLBMServiceGUI::parserUhrzeit", array($class->A("GRLBMServiceNotified"), $class->getID()));
		$GUI->insertSpaceAbove("nummer");
		
	}
	
	public static function parserMitarbeiterButton($w, $l, $GRLBMID){
		$B = new Button("Mitarbeiter\nbearbeiten", "personal");
		$B->popup("", "Mitarbeiter bearbeiten", "GRLBMService", "-1", "popupMitarbeiter", [$GRLBMID]);
		
		return $B."";
	}
	
	public function popupMitarbeiter($GRLBMID){
		$G = new GRLBMGUI($GRLBMID);#, false);
		self::$currentElement = $G;
		$fields = [
			"GRLBMServiceMitarbeiter",
			"GRLBMServiceVon", 
			"GRLBMServiceStundensatz",
			
			"GRLBMServiceMitarbeiter2",
			"GRLBMServiceVon2", 
			"GRLBMServiceStundensatz2",
			
			"GRLBMServiceMitarbeiter3",
			"GRLBMServiceVon3", 
			"GRLBMServiceStundensatz3",
			
			"GRLBMServiceMitarbeiter4",
			"GRLBMServiceVon4", 
			"GRLBMServiceStundensatz4"
		];
		$F = new HTMLForm("serviceMitarbeiter", $fields);
		$F->useRecentlyChanged();
		
		$F->setValues($G);
		$F->getTable()->setColWidth(1, 120);
		
		$AC = Users::getUsers();
		$users = array("" => "Bitte auswählen...");
		while($U = $AC->n())
			$users[$U->getID()] = $U->A("name");
		
		$F->setType("GRLBMServiceVon", "parser", null, ["GRLBMServiceGUI::parserVonBis", ""]);
		$F->setType("GRLBMServiceVon2", "parser", null, ["GRLBMServiceGUI::parserVonBis", "2"]);
		$F->setType("GRLBMServiceVon3", "parser", null, ["GRLBMServiceGUI::parserVonBis", "3"]);
		$F->setType("GRLBMServiceVon4", "parser", null, ["GRLBMServiceGUI::parserVonBis", "4"]);
		
		$F->setType("GRLBMServiceMitarbeiter", "select", null, $users);
		$F->setType("GRLBMServiceMitarbeiter2", "select", null, $users);
		$F->setType("GRLBMServiceMitarbeiter3", "select", null, $users);
		$F->setType("GRLBMServiceMitarbeiter4", "select", null, $users);
		
		$F->insertSpaceAbove("GRLBMServiceMitarbeiter2", "Mitarbeiter 2");
		$F->insertSpaceAbove("GRLBMServiceMitarbeiter3", "Mitarbeiter 3");
		$F->insertSpaceAbove("GRLBMServiceMitarbeiter4", "Mitarbeiter 4");
		
		$F->setLabel("GRLBMServiceVon", "Zeitraum");
		$F->setLabel("GRLBMServiceVon2", "Zeitraum");
		$F->setLabel("GRLBMServiceVon3", "Zeitraum");
		$F->setLabel("GRLBMServiceVon4", "Zeitraum");
		
		$F->setLabel("GRLBMServiceMitarbeiter", "Mitarbeiter");
		$F->setLabel("GRLBMServiceMitarbeiter2", "Mitarbeiter");
		$F->setLabel("GRLBMServiceMitarbeiter3", "Mitarbeiter");
		$F->setLabel("GRLBMServiceMitarbeiter4", "Mitarbeiter");
		
		$F->setLabel("GRLBMServiceStundensatz", "Stundensatz");
		$F->setLabel("GRLBMServiceStundensatz2", "Stundensatz");
		$F->setLabel("GRLBMServiceStundensatz3", "Stundensatz");
		$F->setLabel("GRLBMServiceStundensatz4", "Stundensatz");
		
		$F->hideIf("GRLBMServiceMitarbeiter", "=", "", "onchange", ["GRLBMServiceVon", "GRLBMServiceStundensatz"]);
		$F->hideIf("GRLBMServiceMitarbeiter2", "=", "", "onchange", ["GRLBMServiceVon2", "GRLBMServiceStundensatz2"]);
		$F->hideIf("GRLBMServiceMitarbeiter3", "=", "", "onchange", ["GRLBMServiceVon3", "GRLBMServiceStundensatz3"]);
		$F->hideIf("GRLBMServiceMitarbeiter4", "=", "", "onchange", ["GRLBMServiceVon4", "GRLBMServiceStundensatz4"]);
		
		$F->setSaveClass("GRLBM", $GRLBMID, "function(){ ".OnEvent::closePopup("GRLBMService")." }");
		
		echo $F;
	}
	
	public static function parserVonBis($w, $l, $p){
		$c = new GRLBMServiceGUI(-1);
		
		$IV = new HTMLInput("GRLBMServiceVon$p", "time", self::$currentElement->A("GRLBMServiceVon$p"));
		$IV->style("width:50px;text-align:right;");
		$IV->placeholder("von");
		$IV->onkeyup(OnEvent::rme($c, "calcHours", array("\$j('[name=GRLBMServiceVon$p]').val()", "\$j('[name=GRLBMServiceBis$p]').val()", "\$j('[name=GRLBMServicePause$p]').val()"), "function(t){ \$j('[name=GRLBMServiceStunden$p]').val(t.responseText); }"));
		
		$IB = new HTMLInput("GRLBMServiceBis$p", "time", self::$currentElement->A("GRLBMServiceBis$p"));
		$IB->style("width:50px;text-align:right;");
		$IB->placeholder("bis");
		$IB->onkeyup(OnEvent::rme($c, "calcHours", array("\$j('[name=GRLBMServiceVon$p]').val()", "\$j('[name=GRLBMServiceBis$p]').val()", "\$j('[name=GRLBMServicePause$p]').val()"), "function(t){ \$j('[name=GRLBMServiceStunden$p]').val(t.responseText); }"));
		
		$IP = new HTMLInput("GRLBMServicePause$p", "time", self::$currentElement->A("GRLBMServicePause$p"));
		$IP->style("width:50px;text-align:right;");
		$IP->onkeyup(OnEvent::rme($c, "calcHours", array("\$j('[name=GRLBMServiceVon$p]').val()", "\$j('[name=GRLBMServiceBis$p]').val()", "\$j('[name=GRLBMServicePause$p]').val()"), "function(t){ \$j('[name=GRLBMServiceStunden$p]').val(t.responseText); }"));
		
		$IS = new HTMLInput("GRLBMServiceStunden$p", "time", self::$currentElement->A("GRLBMServiceStunden$p"));
		$IS->style("width:50px;text-align:right;");
		
		return $IV." - ".$IB."<span style=\"color:grey;\"> Uhr,</span> $IP <span style=\"color:grey;\">Pause <br>
			Stunden:</span> $IS";
	}
	
	public static function parserOptionen($w, $l, $p){
		$p = HTMLGUI::getArrayFromParametersString($p);
			
		$IG = new HTMLInput("GRLBMServiceIsGarantie", "checkbox", $p[0]);
		$IA = new HTMLInput("GRLBMServiceIsAbgeschlossen", "checkbox", $p[1]);
		$IB = new HTMLInput("GRLBMServiceIsBerechnung", "checkbox", $p[2]);
		
		return "<span style=\"width:100px;display:inline-block;\">".self::$labelGarantie."?</span>$IG<br><span style=\"width:100px;display:inline-block;\">Abgeschlossen?</span>$IA<br><span style=\"width:100px;display:inline-block;\">Berechnung?</span>$IB";
	}
	
	public static $currentElement;
	public static $currentAdresse;
	public static $currentAuftrag;
	
	public static function parserArbeitsort($w){
		$B = new Button("Aus Kunde übernehmen", "./images/i2/insert.png", "icon");
		$B->onclick("\$j('[name=GRLBMServiceArbeitsort]').val('".addslashes((trim(self::$currentAdresse->A("strasse")." ".self::$currentAdresse->A("nr")) != "" ? self::$currentAdresse->A("strasse")." ".self::$currentAdresse->A("nr").", " : "").self::$currentAdresse->A("plz"))." ".addslashes(self::$currentAdresse->A("ort"))."')");
		$B->style("float:right;");
		
		$I = new HTMLInput("GRLBMServiceArbeitsort", "text", $w);
		
		if(Session::isPluginLoaded("mAdresseNiederlassung")){
			$AC = AdresseNiederlassung::get(Kappendix::getAdresseIDToKundennummer(self::$currentAuftrag->A("kundennummer")));
			
			$options = array("" => "Hauptsitz");

			while($N = $AC->n())
				$options["AdresseNiederlassungID:".$N->getID()] = $N->A("AdresseNiederlassungPLZ")." ".$N->A("AdresseNiederlassungOrt").", ".$N->A("AdresseNiederlassungStrasse")."";
			
			$I = new HTMLInput("GRLBMServiceArbeitsort", "select", self::$currentElement->A("GRLBMServiceArbeitsort"), $options);

			return $I."";
		}
		
		return $B.$I;
	}
	
	public static function parserUhrzeit($w, $l, $p){
		$p = HTMLGUI::getArrayFromParametersString($p);
		$BN = new Button("Terminbestätigung", "./images/i2/mail".($p[0] ? "ed" : "").".png", "icon");
		$BN->style("float:right;");
		$BN->doBefore("saveClass('GRLBM','$p[1]',function(){ %AFTER }, 'GRLBMForm');");
		$BN->popup("", "Terminbestätigung", "Util", "-1", "EMailPopup", array("'mKalender'", "-1", "'notification::CustomizerBelegService2GUI::$p[1]::0'"));
		
		if(!Session::isPluginLoaded("mKalender"))
			$BN = "";
		
		$I = new HTMLInput("GRLBMServiceTerminUhr", "time", $w);
		$I->style("width:90%");

		return $BN.$I;
	}
	
	public function calcHours($h1, $h2, $pause){
		echo Util::CLTimeParserE(Util::CLTimeParserE($h2, "store") - Util::CLTimeParserE($h1, "store") - Util::CLTimeParserE($pause, "store"));
	}
	
	/*public static function getMitarbeiterToID($PersonalID, $echo = false){
		$P = "kein Mitarbeiter ausgewählt";
		if($PersonalID != "0" AND Session::isPluginLoaded("mPersonal")){
			$Personal = new Personal($PersonalID);
			$P = $Personal->A("vorname")." ".$Personal->A("nachname");
		}
		
		if($echo)
			echo $P;
		
		return $P;
	}*/
}
?>