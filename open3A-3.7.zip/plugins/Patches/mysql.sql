CREATE TABLE `Patch` (
  `PatchID` int(10) NOT NULL AUTO_INCREMENT,
  `PatchType` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `PatchDescription` text COLLATE utf8_unicode_ci NOT NULL,
  `PatchValue` text COLLATE utf8_unicode_ci NOT NULL,
  `PatchExecuted` tinyint(1) NOT NULL,
  `PatchDate` int(17) NOT NULL,
  `PatchApplication` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `PatchNummer` int(10) NOT NULL,
  PRIMARY KEY (`PatchID`),
  UNIQUE KEY `PatchNummer` (`PatchNummer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='personalPlaner_0.1;';
-- END
