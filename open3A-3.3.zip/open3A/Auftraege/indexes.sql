
ALTER TABLE `Posten` ADD INDEX ( `GRLBMID` ) 
ALTER TABLE `GRLBM` ADD INDEX ( `AuftragID` , `isM` ) 
ALTER TABLE `Auftrag` ADD INDEX ( `lieferantennummer` ) 