CREATE TABLE `Exp` (
  `ExpID` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `plugin` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `felder` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `selectors` text COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sep` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `newline` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `kodierung` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `sort` text COLLATE utf8_unicode_ci NOT NULL,
  `showID` tinyint(1) NOT NULL,
  `textSep` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ExpID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='open3A_1.5;';
-- END
INSERT INTO `Exp` VALUES (1,'Adressen für Serienbrief','Adressen','firma, vorname, nachname, strasse, nr, plz, ort','','serienbrief.txt','txt',',','Unix','UTF-8','',0,'2');
-- END
