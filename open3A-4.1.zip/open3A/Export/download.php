<?php
/*
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  2007 - 2020, open3A GmbH - Support@open3A.de
 */

session_name("ExtConnDownloadExport");

define("PHYNX_NO_SESSION_RELOCATION", true);

require_once realpath(__DIR__."/../../system/connect.php");

$absolutePathToPhynx = realpath(dirname(__FILE__)."/../../")."/";

$e = new ExtConn($absolutePathToPhynx);
$e->useUser();
#echo substr(Util::eK(), 0, 24);
if(!$_GET["token"] OR substr(Util::eK(), 0, 24) != $_GET["token"])
	die("Ungültiges Token!");

$e->loadPlugin("open3A", "Auftraege");
$e->loadPlugin("open3A", "Export");
$e->loadPlugin("open3A", "Adressen");
$e->loadPlugin("open3A", "Artikel");
$e->loadPlugin("openWaWi", "Lieferanten", true);
$e->addClassPath(FileStorage::getFilesDir());

if(!$_GET["export"])
	die("Keine Export-Klasse angegeben!");

$E = $_GET["export"]."GUI";
if(strpos($E, "export") !== 0)
	die("Ungültige Klasse!");

$E = new $E();

$E->getExportData($_GET["arg1"]);

$e->cleanUp();
?>