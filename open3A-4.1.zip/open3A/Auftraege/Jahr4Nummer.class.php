<?php
/*
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2024, open3A GmbH - Support@open3A.de
 */
#namespace open3A;
class Jahr4Nummer extends Auftrag implements iReNr {
	
	function getLabel(){
		return "JahrNummer, z.B. 080001";
	}
	
	public static function getNextNumber($type){
		$since = new Datum();
		$since->setToJan1st();
		$since->subWeek();
		$since->subWeek();
		$since->subWeek();
		
		$jahr = date("y");
		$startNumber = $re_nr = $jahr."0001";
		
		$is = array("R", "L", "G", "B", "M", "A");
		$AC = anyC::get("GRLBM");
		if(in_array($type, $is))
			$AC->addAssocV3("is$type", "=", "1");
		else
			$AC->addAssocV3 ("isWhat", "=", $type);
		$AC->addAssocV3("datum", ">=", $since->time());
		
		if($type == "A" AND !Auftrag::getBelegArten("B")){
			$AC->addAssocV3("isB","=","1", "OR", "2");
			$AC->addAssocV3("datum", ">=", $since->time(), "AND", "2");
		}
		
		$re_nr = $AC->getIncrementedField("nummer");
		
		if($re_nr - 1 < $startNumber) 
			$re_nr = $startNumber;
		
		if($re_nr == 1) 
			$re_nr = $startNumber;
		
		if($jahr < 10) 
			$re_nr = "0".$re_nr;
		
		$re_nr2 = $re_nr."";
		if($jahr > $re_nr2[0].$re_nr2[1]) 
			$re_nr = $startNumber;
		
		return $re_nr;
	}
}
?>
