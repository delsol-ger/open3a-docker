<?php
/**
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2024, open3A GmbH - Support@open3A.de
 */
#namespace open3A;

class mVorlageGUI extends anyC implements iGUIHTMLMP2 {

	public function getHTML($id, $page){
	/*	$GUI = new HTMLColGUI($this);
		$GUI->cols(2);
		$GUI->content("right", $this->contentRight($id, $page));
		$GUI->content("left", $this->contentLeft());
		
		$GUI->widths(array("left" => "50%", "right" => "50%"));
		
		return $GUI;
		
	}

	private function contentRight($id, $page){*/
		$this->addAssocV3("VorlageIsDeleted", "=", "0");
		
		$dir = FileStorage::getFilesDir();#Util::getRootPath()."specifics/";
		
		$FS = new File($dir);
		
		if(!$FS->A("FileIsWritable")){
			$T = new HTMLTable(1);
			
			$B = new Button("Verzeichnis nicht beschreibbar", "warning", "icon");
			$B->style("float:left;margin-right:10px;");
			
			$T->addRow(array("{$B}Das Verzeichnis <code>$dir</code> ist nicht beschreibbar. Bitte machen Sie dieses Verzeichnis beschreibbar, damit die Vorlagen erstellt werden können."));
			
			die($T);
			#return $T;
		}
		
		$this->lCV3();

		$gui = new HTMLGUIX($this);
		$gui->version("mVorlage");
		#$gui->targetFrame("contentScreenRight");
		$gui->name("Vorlage");
		
		$gui->attributes(array("VorlageName"));
		
		$gui->parser("VorlageName", "parserName");
		
		#$DeleteIDs = array();
		/*$AC = anyC::get("Auftrag");
		$AC->addGroupV3("AuftragVorlage");
		$AC->setFieldsV3(array("AuftragVorlage", "COUNT(*) AS anzahl"));
		while($A = $AC->getNextEntry()){
			if(strpos($A->A("AuftragVorlage"), "Vorlage_VorlageID") !== 0)
				continue;
			
			if($A->A("anzahl") <= 10)
				continue;
			
			#$DeleteIDs[] = str_replace("Vorlage_VorlageID", "", $A->A("AuftragVorlage"));
		}*/
		
		#if($AC->numLoaded() > 10)
		#	Red::alertD ("Diese Vorlage kann nicht mehr gelöscht werden, das sie in mehr als 10 Aufträgen verwendet wird.");
		
		
		#$gui->blacklists(array(), $DeleteIDs);
		
		return $gui->getBrowserHTML($id).OnEvent::script("var Vorlage = { reloadLeft: function(){ ".OnEvent::reload("Left")." } }");
	}
	
	public static function parserName($w, Vorlage $E){
		$used = "";
		$AC = anyC::get("Stammdaten", "ownTemplate", $E->className());
		while($S = $AC->n())
			$used .= ($used != "" ? ", " : "").($S->A("aktiv") ? "<span style=\"font-weight:bold;color:black;\">" : "").($S->A("firmaKurz") != "" ? $S->A("firmaKurz") : $S->A("firmaLang")).($S->A("aktiv") ? "</span>" : "");
		
		return $w.($used != "" ? "<br><small style=\"color:grey;\">$used</small>" : "");
	}
	
	private function contentLeft(){
		
		$AC = anyC::get("Vorlage");
		$V = $AC->n();
		$V = new VorlageGUI($V->getID());
		
		$string = $V->getGRLBMPDF("A", true);
		return "<embed id=\"pdfPreview\" src=\"data:application/pdf;base64,". base64_encode($string)."\" type=\"application/pdf\" width=\"100%\" height=\"100px\" />".OnEvent::script("\$j('#pdfPreview').css('height', contentManager.maxHeight());");
	}
	
	public static function doSomethingElse(){
		#if(FileStorage::getFilesDir() != Util::getRootPath()."specifics/") //moved to Auftraege::doSomethingElse
		#	addClassPath(FileStorage::getFilesDir());
	}

}
?>