<?php
/*
 *  This file is part of phynx.

 *  phynx is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  phynx is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2024, open3A GmbH - Support@open3A.de
 */
#namespace open3A;
class SupportGUI {
	
	public static $errorMessage;
	
	public static function mailAddress(){
		return array("open3A GmbH", "Support@open3A.de");
	}
	
	public function getID(){
		return -1;
	}
	
	public function EMailPopupAttachmentsSP(){
		$dir = FileStorage::getElementDir("Support", 0);
		
		$T = new HTMLTable(3);
		$T->setTableStyle("width: 100%;table-layout: fixed;");
		$T->setColWidth(2, 25);
		$T->setColWidth(3, 25);
		$dir = new DirectoryIterator($dir);
		foreach ($dir as $file) {
			if($file->isDot()) continue;
			if($file->isDir()) continue;

			$BD = new Button("Bild löschen", "trash_stroke", "iconic");
			$BD->doBefore("if(!confirm('Bild löschen?')) return; %AFTER");
			$BD->rmePCR("Support", -1, "deleteScreenshot", ["'".$file->getFilename()."'"], OnEvent::reloadSidePanel("Support"));
			
			$BP = new Button("Bild anzeigen", "./images/i2/details.png", "icon");
			$BP->popup("", "Vorschau", "File", str_replace("+", ";:plus:;", $file->getPathname()), "previewWindow", "", "", "{width:600, hPosition: 'center'}");
			
			$T->addRow([$file->getFilename(), $BP, $BD]);
			$T->addCellStyle(1, "width:calc(100% - 50px);overflow: hidden;text-overflow: ellipsis;white-space: nowrap;");
			
		}
		
		echo $T;
	}
	
	public function deleteScreenshot($filename){
		$dir = FileStorage::getElementDir("Support", 0);
		unlink($dir."/$filename");
	}
	
	public function saveScreenshot($data){
		$dir = FileStorage::getElementDir("Support", 0);
		if(!file_exists($dir))
			mkdir($dir, 0777, true);
		
		file_put_contents($dir."/Bildschirmfoto_".date("Ymd_His").".png", base64_decode(str_replace("data:image/png;base64,", "", $data)));
	}
	
	public function fatalError($error, $request = "", $return = false, $inWindow = false){
		$dir = FileStorage::getElementDir("Support", 0);
		if(file_exists($dir)){
			$dir = new DirectoryIterator($dir);
			foreach ($dir as $file) {
				if($file->isDot()) continue;
				if($file->isDir()) continue;

				unlink($file->getPathname());
			}
		}
		
		$error = trim($error);#."\n\nZeit:\n".Util::CLDateTimeParser(time())."\n\nBrowser-Anfrage:\n".htmlentities($request));
		
		$B = new Button("Fehler", ($inWindow ? "." : "")."./images/big/sad.png", "icon");
		$B->style("float:left;margin-right:10px;margin-bottom:30px;");
		
		$r = "<div id=\"questionContainer\"><h1>$B Es ist ein Fehler aufgetreten, das tut mir leid!</h1><p>Sie können mit diesem Modul nicht arbeiten,<br>wahrscheinlich funktionieren aber die Anderen.</p>";
		
		$BJa = new Button("Weiter", ($inWindow ? "." : "")."./images/navi/navigation.png");
		$BJa->style("float:right;margin:10px;");
		$BJa->onclick("if(\$j('[name=addSS]').prop('checked')){ document.getElementById('darkOverlay').setAttribute('data-html2canvas-ignore','true'); document.getElementById('editDetailsSupport').setAttribute('data-html2canvas-ignore','true'); html2canvas(document.querySelector('body')).then(canvas => { ".OnEvent::rme($this, "saveScreenshot", ["canvas.toDataURL()"], "function(){ ".OnEvent::popupSidePanel("Support", "-1", "EMailPopupAttachmentsSP", array("'Support'", "'-1'", "''"))." }")." }); } \$j('#questionContainer').slideUp(); \$j('#mailContainer').slideDown();");
		$BJa->className("backgroundColor1");
		
		$BSs = new HTMLInput("addSS", "checkbox", "1");
		$BSs->id("addSS");
		$BSs->style("float:left;margin-left:10px;margin-top:0;");
		
		
		$BNein = new Button("Nein,\ndanke", ($inWindow ? "." : "")."./images/navi/kuendigung.png");
		$BNein->style("margin:10px;");
		$BNein->className("backgroundColor4");
		if(!$inWindow)
			$BNein->onclick(OnEvent::closePopup("Support"));
		else
			$BNein->onclick("window.close();");
		
		$r .= "
			<div style=\"clear:both;padding-top:5px;padding-bottom:10px;\" class=\"backgroundColor4\">
			
				<div style=\"float:right;width:170px;\">
					$BJa
					".($inWindow ? "" : "{$BSs}
					<label style=\"display:inline;vertical-align:top;float:none;width:auto;text-align:left;\" for=\"addSS\">Bild mitschicken</label>")."
				</div>
				<p style=\"padding:10px;font-size:14px;line-height: 1.5;padding-bottom:0;\">
					Damit wir das Problem beheben können,<br>übertragen Sie bitte die Fehlermeldung<br>an den Support:
				</p>
				<div style=\"clear:both;\"></div>
			</div>";
		$r .= "<pre style=\"margin:10px;margin-top:20px;padding-bottom:10px;font-size:10px;max-width:590px;overflow:auto;clear:both;color:grey;\">".preg_replace("/^\<br[ \/]*\>\s*/", "", stripslashes(trim($error)))."</pre>
				$BNein
					</div>";
		
		SupportGUI::$errorMessage = stripslashes(strip_tags($error));
		$r .= "<div style=\"display:none;\" id=\"mailContainer\">".UtilGUI::EMailPopup("SupportGUI", "-1", $inWindow ? "1" :"0", "function(transport){ \$j('#messageContainer').html(transport.responseText); \$j('#mailContainer').slideUp(); \$j('#messageContainer').slideDown(); }", !$inWindow ? OnEvent::closePopup("Support") : "window.close();", true, true)."</div><div style=\"display:none;\" id=\"messageContainer\"></div>";
		
		if($return)
			return $r;
		
		echo $r;
	}
	
	
	public static function sendEmail($subject, $body, $recipient, $inWindow, $files, $cc, $sender){
		$S = new SupportGUI();
		$data = $S->getEMailData();
		
		$mailfrom = $data["fromAddress"];
		if(trim($mailfrom) == "" AND $sender == "")
			Red::errorD("Bitte geben Sie eine Absender-Adresse ein!");
		
		if(trim($mailfrom) == "" AND $sender != "")
			$mailfrom = $sender;
		
		$mailto = $data["recipients"][$recipient][1];
		
		$CH = Util::getCloudHost();
		$skipOwn = false;
		if($CH)
			$skipOwn = true;
		
		$mimeMail2 = new phynxMailer($mailto, $subject, $body);
		$mimeMail2->from($mailfrom, $data["fromName"]);
		
		$sdir = FileStorage::getElementDir("Support", 0);
		if(file_exists($sdir)){
			$dir = new DirectoryIterator($sdir);
			foreach ($dir as $file) {
				if($file->isDot()) continue;
				if($file->isDir()) continue;

				$mimeMail2->attach($file->getPathname());
			}
		}
		
		$B = new Button("Danke!", ($inWindow ? "." : "")."./images/big/thanks.png", "icon");
		$B->style("float:left;margin-right:10px;margin-bottom:20px;");
		
		$BOK = new Button("Fenster\nschließen", ($inWindow ? "." : "")."./images/navi/bestaetigung.png");
		if(!$inWindow)
			$BOK->onclick(OnEvent::closePopup("Support"));
		else
			$BOK->onclick ("window.close();");
		$BOK->style("float:right;margin:10px;");

		if(false AND $mimeMail2->Send())
			echo "<p style=\"font-size:14px;margin-top:15px;\">$B Danke für Ihre Unterstützung!</p>
				<p style=\"font-size:14px;\">Sie erhalten in Kürze eine Antwort per E-Mail.</p>";
		else {
			echo "<p style=\"padding:5px;color:red;\">
				Fehler beim Senden der E-Mail. 
				Bitte überprüfen Sie Ihre Server-Einstellungen im Admin-Bereich.</p>
				<p>Nachfolgend wird Ihre Nachricht angezeigt, falls Sie sie in die Zwischenablage kopieren (Strg + c) und manuell an <b>$mailto</b> möchten.</p><pre style=\"color:grey;max-height:300px;font-size:10px;padding:5px;width:590px;overflow:auto;\">".wordwrap(stripslashes($body), 80)."</pre>";
		}
		echo OnEvent::script("\$j('#editDetailsSupportSidePanel').fadeOut();");
		
		if(file_exists($sdir)){
			$dir = new DirectoryIterator($sdir);
			foreach ($dir as $file) {
				if($file->isDot()) continue;
				if($file->isDir()) continue;

				unlink($file->getPathname());
			}
		}
		
		$CH = Util::getCloudHost();
		if($CH != null){
			if(isset($CH->versionLast) AND $CH->versionLast != ""){
				echo "<div class=\"backgroundColor4\" style=\"clear:both;padding:10px;padding-bottom:20px;\">";
				echo "<h2>Möchten Sie testen, ob es in einer älteren Version funktioniert?</h2>";
				echo "<p>Sämtliche Änderungen in der älteren Version werden in die aktuelle Version übertragen.</p>";
				echo "<p><a href=\"".$CH->versionLast."/{$CH->appPrefix}_".$_SESSION["phynx_customer"]."\" target=\"_blank\">Vorherige Version öffnen</a></p>";
				echo "</div>";
			}
		} else {
			$versions = [];
			$dir = new DirectoryIterator(Util::getRootPath());
			foreach ($dir as $file) {
				if($file->isDot()) 
					continue;
				
				if(!$file->isDir()) 
					continue;
				
				if(strpos($file->getFilename(), "phynxBackup_") === false)
					continue;
				
				$versions[] = $file->getFilename();

			}
			arsort($versions);
			
			if(count($versions)){
				echo "<div class=\"backgroundColor4\" style=\"clear:both;padding:10px;padding-bottom:20px;\">";
				echo "<h2>Möchten Sie testen, ob es in einer älteren Version funktioniert?</h2>";
				echo "<p>Sämtliche Änderungen in der älteren Version werden in die aktuelle Version übertragen.</p>";
				echo "<p><a href=\"".str_replace("/interface/rme.php", "", $_SERVER["SCRIPT_URI"])."/$versions[0]\" target=\"_blank\">Version $versions[0] öffnen</a></p>";
				echo "</div>";
			}
		}
		
		
		echo $BOK;
		
		#LINKS ZU vorherigen Versionen, auch aus Cloud
	}
	
	public function getEMailData(){
		return array(
			"fromName" => Session::currentUser()->A("name"),
			"fromAddress" => Session::currentUser()->A("UserEmail"),
			"recipients" => array(self::mailAddress()),
			"subject" => "Fehlermeldung in ".Applications::activeApplicationLabel()." ".Applications::activeVersion(),
			"body" => "<p>Hallo Support-Team,</p>

<p>bei der Nutzung von ".Applications::activeApplication()." ".Applications::activeVersion()." ist ein Fehler aufgetreten, <span style=\"color:red;\">während ich folgendes getan habe:</span></p>


<p>…</p>


<p>Weiter unten sende ich die Fehlermeldung sowie einige Informationen, die Ihnen beim Finden des Problems helfen könnten.</p>

<p>Freundliche Grüße,<br>
".Session::currentUser()->A("name")."</p>


<div style=\"font-family:monospace;\">".str_replace("\n", "<br>", self::$errorMessage."")."<br>
<br>
URL:<br>
".str_replace("interface/rme.php", "", $_SERVER["SCRIPT_URI"])."<br>
<br>
Anwendung:<br>
".Applications::activeApplicationLabel()." ".Applications::activeVersion()."<br>
<br>
Benutzer-ID:<br>
".Session::currentUser()->getID()."<br>
<br>
PHP-Version:<br>
". phpversion()."<br>
<br>
Alle geladenen Module:<br>
".implode(", ", get_loaded_extensions())."<br>
<br>
Mein Browser:<br>
".$_SERVER["HTTP_USER_AGENT"]."<br>
<br>
Mein Server:<br>
".$_SERVER["SERVER_SOFTWARE"]."</div>");
	
	}
}
?>