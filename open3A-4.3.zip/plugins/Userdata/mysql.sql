CREATE TABLE `Userdata` (
  `UserdataID` int(10) NOT NULL AUTO_INCREMENT,
  `UserID` int(10) NOT NULL DEFAULT 0,
  `name` varchar(50) NOT NULL DEFAULT '',
  `wert` varchar(3000) NOT NULL,
  `typ` varchar(50) NOT NULL,
  PRIMARY KEY (`UserdataID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='personalPlaner_0.1;';
-- END
