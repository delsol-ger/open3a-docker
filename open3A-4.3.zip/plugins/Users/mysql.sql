CREATE TABLE `User` (
  `UserID` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(70) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `isAdmin` tinyint(1) NOT NULL DEFAULT 0,
  `SHApassword` varchar(200) NOT NULL,
  `language` varchar(50) NOT NULL,
  `UserEmail` varchar(200) NOT NULL,
  `UserICQ` varchar(15) NOT NULL,
  `UserJabber` varchar(100) NOT NULL,
  `UserSkype` varchar(50) NOT NULL,
  `UserTel` varchar(50) NOT NULL,
  `UserPosition` varchar(150) NOT NULL,
  `UserLoginToken` varchar(250) NOT NULL,
  `UserType` tinyint(2) NOT NULL,
  `UserWebAuthCredentials` text NOT NULL,
  `UserCustomValue1` varchar(100) NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
-- END
INSERT INTO `User` VALUES
(1,'Admin','Admin',';;;-1;;;',1,'4e7afebcfbae000b22c7c85e5560f89a2a0280b4','','','','','','','','',0,'','');
-- END
CREATE TABLE `UserOld` (
  `UserOldID` int(10) NOT NULL AUTO_INCREMENT,
  `UserOldUserID` int(10) NOT NULL,
  `name` varchar(70) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `isAdmin` tinyint(1) NOT NULL DEFAULT 0,
  `SHApassword` varchar(200) NOT NULL,
  `language` varchar(50) NOT NULL DEFAULT 'de_DE',
  `UserEmail` varchar(200) NOT NULL,
  `UserICQ` varchar(15) NOT NULL,
  `UserJabber` varchar(100) NOT NULL,
  `UserSkype` varchar(50) NOT NULL,
  `UserTel` varchar(50) NOT NULL,
  `UserPosition` varchar(150) NOT NULL,
  `UserLoginToken` varchar(250) NOT NULL,
  `UserType` tinyint(2) NOT NULL,
  `UserWebAuthCredentials` text NOT NULL,
  PRIMARY KEY (`UserOldID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='multiCMS_1.0;';
-- END
