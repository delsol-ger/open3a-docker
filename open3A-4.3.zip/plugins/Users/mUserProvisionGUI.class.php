<?php
/*
 *  This file is part of phynx.

 *  phynx is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  phynx is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;
class mUserProvisionGUI extends Users implements iGUIHTMLMP2{
	public function getHTML($id, $page){
		$allowedUsersProvision = Environment::getS("allowedUsersProvision", null);
		
		$this->addAssocV3("UserType", "=", "2");
		$this->addOrderV3("name");
		$this->loadMultiPageMode($id, $page);
		#if($this->A == null) 
		#	$this->lCV3($id);
		
		$gui = new HTMLGUIX($this);
		$gui->screenHeight();
		$gui->name("Provisionsbenutzer");
		
		$gui->attributes(array("name"));
		
		$CH = Util::getCloudHost();
		
		$TR = new HTMLTable(1);
		$TR->addTableClass("browserContainerSubHeight");
		if($allowedUsersProvision !== null AND $id == -1){
			$B = new Button("", "notice", "icon");
			$B->style("float:left;margin-right:10px;");
			
			$add = "";
			if($CH == null)
				$add = "<br><br><strong>Weitere Benutzer <a href=\"https://www.open3a.de/page-Benutzer\" target=\"_blank\">erhalten Sie im Shop</a></strong>";
			
			$TR->addRow(array($B."Bitte beachten Sie: Sie können insgesamt $allowedUsersProvision Provisionsbenutzer anlegen. $add"));
		}
		
		
		$B = $gui->addSideButton ("Zurück", "back");
		$B->loadFrame("contentRight", "Users");
		
		
		$gui->prepend($TR);
		$gui->customize($this->customizer);
		
		return $gui->getBrowserHTML($id);
	}
	
	public function getCollectionOf() {
		return "UserProvision";
	}
	
}
?>