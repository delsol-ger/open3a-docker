<?php
/*
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;

session_name("ExtConnUpselling");

require_once realpath(dirname(__FILE__)."/../../system/connect.php");

$absolutePathToPhynx = realpath(dirname(__FILE__)."/../../")."/";

$e = new ExtConn($absolutePathToPhynx);

#$e->loadPlugin("personalKartei", "Lohngruppen", true);

$e->useDefaultMySQLData();
$e->useUser();

$dir = new \DirectoryIterator(Util::getRootPath()."customizer");
foreach ($dir AS $file) {
	if($file->isDot()) 
		continue;
	
	if($file->isDir()) 
		continue;

	$class = str_replace(".class.php", "", $file->getFilename());
	
	$C = new $class();
	#echo $class.": ".$C->getLabel()."<br>";
}
#echo "<pre>";
$requestCustomizers = [];
foreach(Aspect::$pointCuts[$_GET["mode"]][$_GET["method"]] AS $callback){
	$ex = explode("::", $callback);
	
	$requestCustomizers[] = $ex[0];
}

echo json_encode($requestCustomizers);
/*
$connection = true;
$options = array(
	"location" => "http://www.open3a.de/page-SOAP",
	"uri" => "http://www.open3a.de/page-SOAP",
	"trace" => true);
try {
	$S = new SoapClient(null, $options);
	$I = $S->getCustomizerDescription($requestCustomizers);
} catch (SoapFault $ex){
	$connection = false;
	print_r($ex);
	print_r(htmlentities($S->__getLastRequest()));
	print_r(htmlentities($S->__getLastResponse()));
}



if($connection){
	try {
		echo $I;
	} catch (Exception $ex){

	}
}*/


$e->cleanUp();