<?php
/**
 *  This file is part of plugins.

 *  plugins is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  plugins is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses></http:>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;

class UpsellGUI extends Upsell {
	function __construct($ID) {
		parent::__construct($ID);
		
		$this->customize();
	}
	
	function getHTML($id){
		$gui = new HTMLGUIX($this);
		$gui->name("Upsell");
	
		return $gui->getEditHTML();
	}
	
	private function list($xml){
		$C = "";
		foreach($xml AS $extension){
			#print_r($extension);
			if(class_exists($extension->name, false))
				continue;

			$beschreibung = ($extension->description != "" ? $extension->description : $extension->shortDescription/*($extension->longDescription != "" ? base64_decode($extension->longDescription) : $extension->shortDescription)*/);
			if(trim($beschreibung) == "")
				continue;
			
			$B = new Button("Im Shop\nanzeigen", "./plugins/Upselling/upsell.png");
			$B->onclick("window.open('$extension->shop');");
			$B->className("backgroundColor2");
			$B->style("margin:5px;margin-top:auto;margin-left:auto;");
			
			$I = new Button($extension->nameShop, $extension->icon, "icon");
			$I->style("float:left;margin-right:10px;margin-top:-7px;margin-left:-5px;width:32px;");
					
			$T = new HTMLTable(3);
			$T->addColStyle(3, "text-align:right;");
			#$T->setColWidth(4, 20);
			$T->setColWidth(3, 80);
			$T->setColWidth(1, 20);
			$T->useForSelection(false);
			$T->setTableStyle("width:100%;");
			
			$T->addRow([
				$I,
				$extension->nameShop,
				Util::CLFormatNumber($extension->price)."€"#,
				#$B
			]);
			
			$T->addRowEvent("click", $B->getAction());
			$T->addRowClass("backgroundColor1");
			$C .= "<div style=\"box-sizing:border-box;margin-bottom:15px;display:flex;\" class=\"spell\">
						<div style=\"display:flex;flex-direction: column;width:100%;\">
						<div class=\"backgroundColor2\" style=\"padding:10px;padding-bottom:5px;\">
							$I
							
							<h2 style=\"margin-bottom:0px;margin-top:0px;\"><div style=\"float:right;\">".Util::CLFormatNumber($extension->price)."€</div>$extension->nameShop</h2>
						</div>
						<div class=\"SpellbookDescription\">
							
							<p>".$beschreibung."</p>
						</div>
						
						$B
						
					</div>
				</div>";
		}
		
		echo "<p>Folgende weitere Funktionen finden Sie in unserem Shop:</p><div style=\"box-sizing:border-box;margin:5px;gap:10px;display:grid;width:calc(100%- 10px);grid-template-columns: repeat(2, 1fr);\">".$C."</div>";
	}
	
	function showExtensions($target, $plugin){
		$found = Aspect::$pointCuts[$target][$plugin];
		$xml = new SimpleXMLElement(file_get_contents("https://www.open3a.de/page-Info/plugins_".implode(":", $found)));
		
		$this->list($xml);
	}
	
	function showFunctions($mode, $method){
		#print_r(file_get_contents("https://deploy.open3a.de/Data/info.php"));
		
		#$xml = new SimpleXMLElement(file_get_contents("http://localhost/plugins/Upselling/info.php?mode=$mode&method=$method"));
		$xml = new SimpleXMLElement(file_get_contents("https://www.open3a.de/page-Info/customizer_{$mode}_$method"));
		$this->list($xml);
	}
}
?>