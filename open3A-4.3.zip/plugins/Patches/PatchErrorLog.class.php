<?php
/**
 *  This file is part of plugins.

 *  plugins is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  plugins is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses></http:>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;

class PatchErrorLog extends PersistentObject {
	public static function log(\Throwable $e){
		$F = new Factory("PatchErrorLog");
			
		$F->sA("PatchErrorLogTime", time());
		$F->sA("PatchErrorLogClass", get_class($e));
		$F->sA("PatchErrorLogMesage", $e->getMessage());
		$F->sA("PatchErrorLogFile", str_replace(Util::getRootPath(), "", $e->getFile()));
		$F->sA("PatchErrorLogLine", $e->getLine());
		$F->sA("PatchErrorLogTrace", $e->getTraceAsString());
		$F->sA("PatchErrorLogTraceArray", json_encode($e->getTrace()));
		$F->sA("PatchErrorLogServerURL", str_replace(["interface/rme.php", "interface/frame.php", "interface/set.php"], "", $_SERVER["SCRIPT_URI"]));
		$F->sA("PatchErrorLogServerSoftware", $_SERVER["SERVER_SOFTWARE"]);
		$F->sA("PatchErrorLogAnwendungName", Applications::activeApplicationLabel());
		$F->sA("PatchErrorLogAnwendungVersion", Applications::activeVersion());
		$F->sA("PatchErrorLogAnwendungBenutzerID", Session::currentUser() != null ? Session::currentUser()->getID() : "0");
		$F->sA("PatchErrorLogPHPVersion", phpversion());
		$F->sA("PatchErrorLogPHPModule", json_encode(get_loaded_extensions()));
		$F->sA("PatchErrorLogUserBrowser", $_SERVER["HTTP_USER_AGENT"]);
		$F->sA("PatchErrorLogUserOS", Util::getOS());
		
		return $F->store();
	}
}
?>