<?php

if(!file_exists($_GET["updateDir"]))
	die();

$updateDir = $_GET["updateDir"];
$rootPath = $_GET["rootPath"];

if(file_exists($updateDir."interface/rme.php")){
	if(rename($updateDir."interface/rme.php", $rootPath."interface/rme.php")){
		echo "rme.php verschoben<br>";
		#rmdir($updateDir."interface");
	}
}

function emptyDir($dirPath){
	echo "leere $dirPath<br>";
	$dir = new DirectoryIterator($dirPath);
	foreach($dir as $file) {
		if($file->isDot())
			continue;

		if($file->isDir()) {
			emptyDir($file->getPathname());

			rmdir($file->getPathname());
			continue;
		}

		unlink($file->getPathname());
	}
}
emptyDir($updateDir);
echo "lösche $updateDir<br>";
rmdir($updateDir);