CREATE TABLE `Patch` (
  `PatchID` int(10) NOT NULL AUTO_INCREMENT,
  `PatchType` varchar(30) NOT NULL,
  `PatchDescription` text NOT NULL,
  `PatchValue` text NOT NULL,
  `PatchExecuted` tinyint(1) NOT NULL,
  `PatchDate` int(17) NOT NULL,
  `PatchApplication` varchar(30) NOT NULL,
  `PatchNummer` int(10) NOT NULL,
  PRIMARY KEY (`PatchID`),
  UNIQUE KEY `PatchNummer` (`PatchNummer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='personalPlaner_0.1;';
-- END
CREATE TABLE `PatchErrorLog` (
  `PatchErrorLogID` int(11) NOT NULL AUTO_INCREMENT,
  `PatchErrorLogTime` int(11) NOT NULL,
  `PatchErrorLogClass` varchar(50) NOT NULL,
  `PatchErrorLogMesage` text NOT NULL,
  `PatchErrorLogFile` varchar(500) NOT NULL,
  `PatchErrorLogLine` int(11) NOT NULL,
  `PatchErrorLogTrace` text NOT NULL,
  `PatchErrorLogServerURL` varchar(1000) NOT NULL,
  `PatchErrorLogServerSoftware` varchar(200) NOT NULL,
  `PatchErrorLogAnwendungName` varchar(150) NOT NULL,
  `PatchErrorLogAnwendungVersion` varchar(50) NOT NULL,
  `PatchErrorLogAnwendungBenutzerID` int(11) NOT NULL,
  `PatchErrorLogPHPVersion` varchar(100) NOT NULL,
  `PatchErrorLogPHPModule` text NOT NULL,
  `PatchErrorLogUserBrowser` varchar(1000) NOT NULL,
  `PatchErrorLogUserOS` varchar(100) NOT NULL,
  `PatchErrorLogTraceArray` text NOT NULL,
  PRIMARY KEY (`PatchErrorLogID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
-- END
