CREATE TABLE `Kundenpreis` (
  `KundenpreisID` int(10) NOT NULL AUTO_INCREMENT,
  `kundennummer` int(10) NOT NULL DEFAULT 0,
  `ArtikelID` int(10) NOT NULL DEFAULT 0,
  `kundenPreis` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `note` text NOT NULL,
  `KundenpreisVarianteArtikelID` int(10) NOT NULL,
  `KundenpreisKategorieID` int(11) NOT NULL,
  PRIMARY KEY (`KundenpreisID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='open3A_1.5;';
-- END
