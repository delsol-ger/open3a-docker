<?php
/*
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;

class Bericht_OffeneAuftraegeNachKundeGUI extends Bericht_OffeneAngeboteNachKundeGUI implements iBerichtDescriptor {
	function __construct() {
		$this->useVariables(["useBOANKInterval"]);
		$this->useVariableDefault("useBOANKInterval", "0");
		
		$this->status = ["confirmed", "delivered", "billedPartly"];
		$this->typ = "B";
		
		parent::__construct();
		
		$this->fieldsToShow = array("nummer","belegTyp","datum","Netto","NettoTR", "NettoRest","Name", "kundennummer");
	}
 	
 	public function getLabel(){
		return "Unberechnete Aufträge nach Kunde";
 	}
 		
	public function getHTML($id){
 		$phtml = parent::getHTML($id);
 		
		$F = new HTMLForm("BP", array("useBOANKInterval"), "Zeitraum");
		$F->getTable()->setColWidth(1, 120);
		
		$years = [0 => "Alle"];
		$date = date("Y");
		$date -= 2;
		for($i = 0; $i < 6; $i++)
			$years[$date + $i] = $date + $i;
		
		$F->setType("useBOANKInterval", "select", $this->userdata["useBOANKInterval"], $years);
		#$F->setType("useBOAEnde", "date", ($this->userdata != null AND isset($this->userdata["useBOAEnde"])) ? $this->userdata["useBOAEnde"] : "");
		$F->setDescriptionField("useBOANKInterval", "Nach letztem in Auftrag erstellten Beleg");
		$F->setLabel("useBOANKInterval", "Zeitraum");
		#$F->setLabel("useBOAEnde", "Ende");
		
		$F->setSaveBericht($this);
		$F->useRecentlyChanged();
		
 		return $phtml.$F;
 	}
	
	public function getPDF($save = false) {
		if($this->userdata["useBOANKInterval"] != 0)
			$this->collection->addAssocV3("DATE_FORMAT(FROM_UNIXTIME(auftragDatum), '%Y')", "=", $this->userdata["useBOANKInterval"]);
		
		$this->sum = array("Netto", "NettoTR", "NettoRest");
		
		$this->setLabel("Netto", "AB");
		$this->setLabel("NettoTR", "AR/TR");
		$this->setLabel("NettoRest", "Restbetrag");
		
 		$this->setAlignment("NettoTR","R");
 		$this->setAlignment("NettoRest","R");
		
		$this->setSumParser("NettoTR", "Util::PDFCurrencyParser");
		$this->setSumParser("NettoRest", "Util::PDFCurrencyParser");
		
		$this->setFieldParser("NettoTR","Bericht_OffeneAuftraegeNachKundeGUI::parserTR");
		$this->setFieldParser("NettoRest","Bericht_OffeneAuftraegeNachKundeGUI::parserRest");
		
		return parent::getPDF($save);
	}
	
	public static function parserRest($w, $l, $A){
		self::$sums["NettoRest"] += $A->Netto - $A->abzug;
		
		return Util::PDFCurrencyParser($A->Netto - $A->abzug);
	}
	
	public static function parserTR($w, $l, $A){
		$A->abzug = 0;
		if($A->status == "billedPartly"){
			$AC = anyC::get("GRLBM", "AuftragID", $A->AuftragID);
			$AC->addAssocV3("isR", "=", "1");
			$AC->addAssocV3("isTeilrechnung", "=", "1", "AND", "2");
			$AC->addAssocV3("isAbschlagsrechnung", "=", "1", "OR", "2");
			$AC->setFieldsV3(["SUM(nettobetrag) AS abzug"]);
			$G = $AC->n();
			if($G)
				$A->abzug = $G->A("abzug");
		}
		
		self::$sums["NettoTR"] += $A->abzug;
		
		return Util::PDFCurrencyParser($A->abzug);
	}
 } 
 ?>