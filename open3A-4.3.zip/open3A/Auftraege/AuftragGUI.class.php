<?php
/*
 *  This file is part of open3A.

 *  open3A is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  open3A is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */
#namespace open3A;
class AuftragGUI extends Auftrag implements iGUIHTML2, iLinkable, icontextMenu {
	public $newDisplayedFields = array();
	protected $showRowKundennummer = true;
	protected $showRowLieferantennummer = false;
	protected $showRowUStIdNr = true;
	public $showButtonEditAdresse = true;
	protected $showButtonsBeleg = true;
	public static $referenzTypen = [916 => "Referenzpapier (916)", 50 => "Preisantwort (50)", 130 => "Rechnungsdatenblatt (130)"];
	
	public function newDisplayedFields(array $fields){
		$this->newDisplayedFields = array_merge($this->newDisplayedFields, $fields);
	}

	function getHTML($id){
		if(strpos($id, "_") !== false){
			$ex = explode("_", $id);
			
			$this->ID = $ex[0];
			BPS::setProperty("AuftragGUI", "GRLBMID", $ex[1]);
		}
		
		T::load(__DIR__, "Auftraege");
		$pSpecData = mUserdata::getPluginSpecificData("Auftraege");
		$bps = $this->getMyBPSData();

		$gui = new HTMLGUI();
		$gui->setObject($this);
		
		if($this->A ==  null AND $id != -1) $this->loadMe();
		
		if($id == -1)
			$id = $this->newWithDefaultValues();
		
		$this->checkUserRestrictions($pSpecData);

		$_SESSION["BPS"]->registerClass("mGRLBMGUI");
		$_SESSION["BPS"]->setACProperty("AuftragID", $this->ID);
		
		$d = null;
		#$BelegeTab = new HTMLSideTable("right");
		$L = new HTMLList();
		$L->addListStyle("list-style-type:none;padding-top:0px;margin-left:10px;");
		
		if(Session::isPluginLoaded("mMail")){
			$AC = anyC::get("DBMail2Object", "DBMail2ObjectTargetClass", "Auftrag");
			$AC->addAssocV3("DBMail2ObjectTargetClassID", "=", $this->getID());
			$M = $AC->n();
			if($M){
				$Bu = new Button("E-Mails", "mail");
				$Bu->id("EMailButton");
				#$Bu->className("backgroundColor2");
				$Bu->rmePCR("Auftrag", $this->getID(), "listEMails", "", "function(t){ \$j('#subframe').html(t.responseText); }");
				#$Bu->onclick("Auftrag.createGRLBM('$this->ID','Auftrag','$B');");
				
				
				$Bu->style("width:100%;min-width:120px;background-position: calc(100% - 3px) center;");
				
				$L->addItem ($Bu);
				$L->addItemStyle("display:inline-block;margin-top:10px;max-width:150px;margin-left:0px;margin-right:10px;width:calc(25% - 15px);");
			}
		}
		
		$i = 0;
		foreach($this->getBelegArten() AS $B){
			if(isset($pSpecData["pluginSpecificCanOnlySeeKalk"]) AND $B != "Kalk") 
				continue;
			
			if(isset($pSpecData["pluginSpecificCantCreate$B"])) 
				continue;
			
			#if(isset($pSpecData["pluginSpecificCantCreateR"]) AND $B == "R") continue;
			#if(isset($pSpecData["pluginSpecificCantCreateL"]) AND $B == "L") continue;
			#if(isset($pSpecData["pluginSpecificCantCreateG"]) AND $B == "G") continue;
			#if(isset($pSpecData["pluginSpecificCantCreateA"]) AND $B == "A") continue;

			$_SESSION["BPS"]->setACProperty("type", $B);
			$tests = new mGRLBMGUI();
			$tests->addAssocV3("AuftragID", "=", $this->ID);
			
			$tests->lCV3();
			$test = $tests->getNextEntry();

			if($this->showButtonsBeleg){
				if($tests->numLoaded() <= 1)
					$label = Stammdaten::getLongType($B);
				else
					$label = Stammdaten::getPluralType($B);
				
				$Bu = new Button($label, Stammdaten::getIconType($B));
				$Bu->onclick("Auftrag.createGRLBM('$this->ID','Auftrag','$B');");
				$Bu->name($test == null ? "1" : "2");
				$Bu->id($B."Button");
				$Bu->style("width:100%;min-width:120px;background-position: calc(100% - 3px) center;");
				
				Aspect::joinPoint("belegButtons", $this, __METHOD__, array($Bu));
				
				if($test == null)
					$Bu->className("backgroundColor0");

				$L->addItem($Bu);
				$L->addItemStyle("display:inline-block;margin-top:10px;max-width:150px;margin-left:0px;margin-right:10px;width:calc(25% - 15px);");#.($i > 0 ? "margin-left:15px;" : "margin-left:10px;"));
			}
			
			if($test != null AND ($B != "Kalk" OR $d == null))
				$d = $tests;

			$i++;
		}

		if(Session::isPluginLoaded("mUpsell")){
			$L->addItem(Upsell::getButtonBig("belege", "Auftrag::getBelegArten"));
			$L->addItemStyle("display:inline-block;margin-top:10px;max-width:150px;margin-left:0px;margin-right:10px;width:calc(25% - 15px);");
		}
		
		$js = "";
		if($bps != -1 AND isset($bps["GRLBMID"])){ //Load specific GRLBM
			$d = new GRLBMGUI($bps["GRLBMID"]);
			BPS::unsetProperty("AuftragGUI", "GRLBMID");
			$js .= OnEvent::script("\$j('#".$d->getMyPrefix()."Button').removeClass('backgroundColor3').removeClass('backgroundColor0').addClass('backgroundColor1');");
		}
		

		$html = "";

		$ADTab = new HTMLTable(2);
		$ADTab->setTableStyle("width:100%;border:0px;");
		$ADTab->setColWidth(1, 150);
		$ADTab->weight("light");
		
		$ADTab2 = new HTMLTable(2);
		$ADTab2->setTableStyle("width:100%;border:0px;");
		$ADTab2->setColWidth(1, 120);
		$ADTab2->weight("light");
		
		if($this->A("AdresseID") !== null){
			$anyC = anyC::get("Auftrag", "AdresseID", $this->A("AdresseID"));
			$AdresseUsed = $anyC->getTotalNum();
		} else
			$AdresseUsed = 0;
		
		$confirmMessage = "if(confirm('Achtung: Beim Bearbeiten der Adresse über diesen Knopf geht die Verbindung zur Kundennummer und die USt-IdNr verloren! Die Adressänderung wirkt sich auf alle Belege in diesem Auftrag aus. Fortfahren?'))";
		$confirmChange = Aspect::joinPoint("changeAdresseConfirm", $this, __METHOD__, array($confirmMessage), $confirmMessage);
		
		
		$ButtonChangeAdresse = $this->alterAdresseButtons();
		
		$ButtonEditAdresse = new Button("Adresse bearbeiten","./images/i2/edit.png", "icon");
		$ButtonEditAdresse->style("float:right;");
		if($AdresseUsed == 1){
			#$ButtonEditAdresse->doBefore("$confirmChange %AFTER");
			$ButtonEditAdresse->editInPopup("AuftragAdresse", $this->A("AdresseID"));#"contentManager.loadFrame('contentRight','Adresse',{$this->A->AdresseID},0,'AdresseGUI;displayMode:auftragsAdresse;AuftragID:$this->ID')");
		} else
			$ButtonEditAdresse->onclick("alert('Diese Adresse kann nicht bearbeitet werden, da sie in ".($AdresseUsed - 1)." anderen ".($AdresseUsed == 2 ? "Auftrag" : "Aufträgen")." verwendet wird.');");

		if($this->A("kundennummer") > 0)
			$this->showButtonEditAdresse = false;
		
		if(!$this->showButtonEditAdresse)
			$ButtonEditAdresse = "";
		
		$hasLocked = count($this->hasLocked()) > 0;
		
		if($hasLocked){
			$ButtonEditAdresse = "";
			#$ButtonChangeAdresse = "";
		}
		
		$Adresse = new Adresse($this->A("AdresseID"));

		$AspectAdresse = Aspect::joinPoint("adresse", $this, __METHOD__, $Adresse);
		if($AspectAdresse != null) $Adresse = $AspectAdresse;

		
		$BKlickTel = "";
		if(Session::isPluginLoaded("mklickTel")){
			$BKlickTel = klickTel::getButtonSmall($this->A("AdresseID"));
			$BKlickTel->style("float:right;margin-right:10px;");
		}
		
		$BA = "";
		if($this->A("kundennummer") > 0){
			$AdresseID = Kappendix::getAdresseIDToKundennummer($this->A("kundennummer"));
			$BA = new Button("Adresse öffnen", "./images/i2/redo.png", "icon");
			$BA->loadPlugin("contentRight", "Adressen", "", $AdresseID, "{single:'Adresse'}");
			$BA->style("float:right;margin-right:10px;");
		}
		
		$BNew = new Button("In Kunde umwandeln", "./images/i2/kunde.png", "icon");
		$BNew->style("float:right;");
		$BNew->onclick("if(confirm('Möchten Sie diese Adresse in die Datenbank übernehmen und eine Kundennummer anlegen?')) ".OnEvent::rme($this, "makeToCustomer", array(), OnEvent::reload("Left")));
		if($this->A("kundennummer") > 0)
			$BNew = "";
		
		$ADTab->addRow(
			($this->A("AdresseID") != "0" ? "<div style=\"float:right;\">".$ButtonChangeAdresse."<br>".$ButtonEditAdresse."</div>$BKlickTel".($this->A("AdresseID") != "0" ? (is_array($Adresse) ? implode("", $Adresse) : $Adresse) : "") : "<div style=\"float:right;\">".$ButtonChangeAdresse."</div>").
			($this->showRowKundennummer ? "<div style=\"clear:both;\"><span style=\"color:grey;\">{$BNew}".T::_("Kundennummer").": ". ($this->A("kundennummer") > 0 ? AdressenGUI::getContactButton($this->A("kundennummer"), "\$j('#AuftragAdresseNiederlassungIDID".$this->getID()."').length ? \$j('#AuftragAdresseNiederlassungIDID".$this->getID()."').val() : 0").$BA.$this->A("kundennummer") : "keine")."</span></div>" : ""));
		$ADTab->addRowColspan(1, 2);
		$ADTab->addCellStyle(1, "padding-left:0px;");
		
		if(Aspect::joinPoint("paymentMorale", $this, __METHOD__, [], true) AND Session::isPluginLoaded("mStatistik") AND Session::isPluginLoaded("Uebersicht") AND $this->A("kundennummer") > 0){
			$Zahlungsmoral = ZahlungsmoralGUI::getAverage($this->A("kundennummer"));
			$ADTab->addRow(array(T::_("Zahlungsmoral").": ".$Zahlungsmoral." Tag".($Zahlungsmoral == 1 ? "" : "e")));
			$ADTab->addRowColspan(1, 2);
			$ADTab->addCellStyle(1, "padding-left:0px;");

		}
		
		$userHiddenPlugins = mUserdata::getHiddenPlugins(true);
		if(Aspect::joinPoint("paymentInfo", $this, __METHOD__, [], true) AND Session::isPluginLoaded("Uebersicht") AND $this->A("kundennummer") > 0 AND !isset($userHiddenPlugins["Uebersicht"])){
			$AC = anyC::get("Auftrag", "kundennummer", $this->A("kundennummer"));
			$AC->addJoinV3("GRLBM", "AuftragID", "=", "AuftragID");
			$AC->addAssocV3("GRLBMID", "IS NOT", "NULL");
			$AC->addAssocV3("isPayed", "=", "0");
			$AC->addAssocV3("isR", "=", "1", "AND", "2");
			$AC->addAssocV3("isG", "=", "1", "OR", "2");
			$AC->setFieldsV3(array("SUM(bruttobetrag) AS bruttobetrag2", "isG", "GRLBMID", "COUNT(*) AS anz", "GROUP_CONCAT(DISTINCT GRLBMID SEPARATOR ',') AS ids"));
			$AC->addGroupV3("isR");
			$AC->addGroupV3("isG");
			
			$mahnungen = 0;
			$op = 0;
			$opi = 0;
			while($G = $AC->n()){
				$op += $G->A("bruttobetrag2") * ($G->A("isG") ? -1 : 1);
				$opi += $G->A("anz");
				#echo $G->A("ids");
				$ACM = anyC::get("GRLBM", "isM", "1");
				$ACM->addAssocV3("AuftragID", "IN", "(".trim($G->A("ids"), ",").")");
				$ACM->setFieldsV3(array("COUNT(DISTINCT AuftragID) AS anz"));
				$ACM->addGroupV3("isM");
				$count = $ACM->n();
				if($count)
					$mahnungen += $count->A("anz");
			}
			
			$gemahnt = "";
			if($mahnungen > 0)
				$gemahnt = "<br><span style=\"text-align:center;width:100%;background-color:rgba(220, 50, 0, 0.8);display:inline-block;padding:5px;color:white;font-weight:bold;\">Davon gemahnt: $mahnungen</span>";
			
			$ADTab->addRow(array(T::_("Aktuell offene Posten").": ".$opi." (".Util::CLFormatCurrency($op).")$gemahnt"));
			$ADTab->addRowColspan(1, 2);
			$ADTab->addCellStyle(1, "padding-left:0px;");

		}
		
		if(Session::isPluginLoaded("mAdresseNiederlassung") AND $this->A("kundennummer") > 0 AND Kappendix::getAdresseIDToKundennummer($this->A("kundennummer"))){
			#$AC = AdresseNiederlassung::getList(Kappendix::getAdresseIDToKundennummer($this->A("kundennummer")));
			$options = AdresseNiederlassung::getOptions(Kappendix::getAdresseIDToKundennummer($this->A("kundennummer")));
			if($options AND count($options)){
				/*$options = array("0" => "Keine");
				
			if($AC->numLoaded() > 0){
				$options = array("0" => "Keine");
				
				while($N = $AC->n()){
					$N->fillMeUp();
					
					$l = $N->A("AdresseNiederlassungPLZ")." ".$N->A("AdresseNiederlassungOrt").($N->A("AdresseNiederlassungStrasse") != "" ? ", ".$N->A("AdresseNiederlassungStrasse")." ".$N->A("AdresseNiederlassungNr") : "");
					if($N->A("AdresseNiederlassungBelegtext") != "")
						$l = $N->A("AdresseNiederlassungBelegtext");
					
					$options[$N->getID()] = Aspect::joinPoint("alterOption", $this, __METHOD__, [$N, $l], $l);
				}*/
				
			
				if(!isset($options[$this->A("AuftragAdresseNiederlassungID")]))
					$options[$this->A("AuftragAdresseNiederlassungID")] = "Unbekannt (wurde evtl. gelöscht)";
			
				$I = new HTMLInput("AuftragAdresseNiederlassungID", "select", $this->A("AuftragAdresseNiederlassungID"), $options);
				$I->activateMultiEdit("Auftrag", $this->getID());
				
				$ADTab2->addLV(Aspect::joinPoint("alterFilialeLabel", $this, __METHOD__, [], "Filiale").":", $I);
			}
			
		}
		
		
		if($this->showRowLieferantennummer)
			$ADTab2->addLV(T::_("LieferantenNr.").":", $this->A->lieferantennummer != -2 ? $this->A("lieferantennummer") : "keine");
		
		
		if($this->showRowUStIdNr)
			$ADTab2->addLV(T::_("USt-IdNr/St.Nr.").":", "<input type=\"text\" value=\"".$this->A->UStIdNr."\" ".(Aspect::joinPoint ("ustidReadonly", $this, __METHOD__, null, $this->A->kundennummer == -2) ? " class=\"multiEditInput2\" onfocus=\"oldValue = this.value;\" onblur=\"if(oldValue != this.value) saveMultiEditInput('Auftrag','".$this->getID()."','UStIdNr');\" id=\"UStIdNrID".$this->getID()."\" type=\"text\" onkeydown=\"if(event.keyCode == 13) saveMultiEditInput('Auftrag','".$this->getID()."','UStIdNr');\" style=\"width:95%;text-align:left;\"" : "readonly=\"readonly\"")." />");

		if(Session::isPluginLoaded("mProjekt")){
			$O = array(Aspect::joinPoint("alterNoProjektLabel", $this, __METHOD__, [], "kein Projekt"));
			
			$AC = Projekt::forAuftrag($this->A("kundennummer"));
			if(Applications::activeApplication() == "openWaWi"){
				$AC = anyC::get("Projekt");
				$AC->addAssocV3("ProjektStatus", "IN", "(0, 1)");
				$AC->addOrderV3("ProjektName");
			}
			
			Aspect::joinPoint("projects", $this, __METHOD__, array($AC));
			while($P = $AC->getNextEntry())
				$O[$P->getID()] = $P->A("ProjektName");
			
			if($this->A("ProjektID") > 0 AND !isset($O[$this->A("ProjektID")])){
				$P = new Projekt($this->A("ProjektID"));
				$O[$P->getID()] = $P->A("ProjektName");
			}
			
			$PI = new HTMLInput("ProjektID", "select", $this->A("ProjektID"), $O);
			$PI->onchange("if(\$j(this).val() != 0) { \$j('#AuftragProjektEditButton').show(); \$j('#AuftragProjektNewButton').hide(); } else { \$j('#AuftragProjektEditButton').hide(); \$j('#AuftragProjektNewButton').show(); }");
			$PI->activateMultiEdit("Auftrag", $this->getID());
			
			
			$BNew = new Button("Projekt erstellen", "./images/i2/new.png", "icon");
			$BNew->style("float:right;margin-top:4px;");
			$BNew->popup("", "Projekt erstellen", "Projekt", "-1", "newForAuftragPopup", array($this->getID()));
			$BNew->id("AuftragProjektNewButton");
			if($this->A("ProjektID") != "0")
				$BNew->style("float:right;margin-top:4px;display:none;");
			
			
			$BEdit = new Button("Projekt bearbeiten", "./images/i2/edit.png", "icon");
			$BEdit->style("float:right;margin-top:4px;");
			$BEdit->popup("", "Projekt bearbeiten", "Projekt", "'+\$j('#ProjektIDID".$this->getID()."').val()+'", "editForAuftragPopup", array($this->getID()));
			$BEdit->id("AuftragProjektEditButton");
			if($this->A("ProjektID") == "0")
				$BEdit->style("float:right;margin-top:4px;display:none;");
			
			if(Applications::activeApplication() != "open3A")
				$BNew = "";
			
			
			Aspect::joinPoint("alterProjekt", $this, __METHOD__, array($BNew, $BEdit, $PI));
			
			$ADTab2->addLV(Aspect::joinPoint("alterProjektLabel", $this, __METHOD__, [], "Projekt").":", $BNew.$BEdit.$PI);
		}
		
		
		if(Session::isPluginLoaded("mBestellung")){
			if(!Session::isPluginLoaded("mProjekt")){
				$ADTab2->addRow(array());
				$ADTab2->addRowClass("backgroundColor0");
			}
			
			$Order = anyC::getFirst("Bestellung", "BestellungAuftragID", $this->getID());
			if($Order != null){
				$BOrder = new Button("Bestellung anzeigen", "./ubiquitous/Bestellungen/Bestellung18.png", "icon");
				$BOrder->style("float:right;");
				$BOrder->loadPlugin("contentRight", "mBestellung", "", $Order->getID());
				
				$O = $BOrder."Bestellnummer ".($Order->getNummer());
			} else {
				$BOrder = new Button("Bestellung erstellen", "./ubiquitous/Bestellungen/Bestellung18.png", "icon");
				$BOrder->style("float:right;");
				$BOrder->rmePCR("Bestellung", "-1", "createFromAuftrag", $this->getID(), "function(transport){ contentManager.loadPlugin('contentRight', 'mBestellung', '', transport.responseText); }");
				
				$O = $BOrder."keine Bestellung zugeordnet";
			}
			
			$ADTab2->addLV("Bestellung:", $O);
		}
		
		
		$gui->customize($this->customizer);
		
		if(Session::isPluginLoaded("mDBPlugin")){
			$i = 1;
			foreach($this->newDisplayedFields AS $l => $I)
				if($I instanceof HTMLInput AND $I->getName() == "AuftragDBPluginSelect$i")
					$i++;
				
			$AC = anyC::get("DBPlugin", "DBPluginNum", "1");
			$AC->addOrderV3("DBPluginID", "ASC");
			
			while($P = $AC->n()){
				$func = $P->getFunctionsRight();
				if($func["selectInAuftrag1"] == "")
					continue;
				
				/*$values = ["" => "Bitte auswählen…"];
				$ACS = anyC::get($P->getThim()."Data");
				$ACS->addAssocV3($func["selectInAuftrag1"], "=", $this->A("AdresseIDOriginal"));
				$ACS->addOrderV3($func["selectInAuftragD1"]);
				while($S = $ACS->n())
					$values[$P->getThim().":".$S->getID()] = $S->A($func["selectInAuftragD1"]);
				
				$I = new HTMLInput("AuftragDBPluginSelect$i", "select", $this->A("AuftragDBPluginSelect$i"), $values);
				$I->activateMultiEdit("Auftrag", $this->getID());*/

				$BE = new Button("Zuordnung löschen", "./images/i2/clear.png", "icon");
				$BE->rmePCR("Auftrag", $this->getID(), "saveMultiEditField", ["'AuftragDBPluginSelect$i'", "''"], "function(){ \$j('[name=AuftragDBPluginSelect{$i}Display]').val(''); }");
				
				$I = new HTMLInput("AuftragDBPluginSelect$i", "text", $this->A("AuftragDBPluginSelect$i"));
				$I->autocomplete("m".$P->getThim()."Data", null, false, '"{\"targetID\": \"'.$this->A("AdresseIDOriginal").'\"}"', $BE);
				$I->onchange(OnEvent::rme($this, "saveMultiEditField", ["'AuftragDBPluginSelect$i'", "'".$P->getThim().":'+this.value"]));
				
				$this->newDisplayedFields([$P->A("DBPluginName").":" => $I]);
				
				$i++;
				if($i == 2)
					break;
			}
		}
		
		if(Session::isPluginLoaded("mFeRD"))
			$ADTab2->addLV("Referenzen", $this->referenzenToHTML());
		
		foreach($this->newDisplayedFields AS $label => $value)
			$ADTab2->addLV($label, $value);

		$html .= "$js
	<div style=\"min-height:50px;\" id=\"subframe\">".($d != null ? $d->getHTML(-1,0) : "")."</div>";

		$BOP = $gui->getOperationsHTML(get_parent_class($this),$this->ID);
		foreach($BOP AS $B){
			$B->type("iconicG");
			$B->style("margin-top:13px;margin-left:5px;");
		}
		
		return "<div class=\"prettyTitle\">".T::_("Auftrag").implode("", $BOP)."</div>
			<div class=\"AuftragBelegContent\">
				<div style=\"width:270px;display:inline-block;vertical-align:top;\">
					<div style=\"padding-left:10px;padding-right:10px;\">".$ADTab."</div>
				</div>
				<div style=\"width:calc(100% - 275px);display:inline-block;vertical-align:top;\">
					<div style=\"padding-left:10px;padding-right:10px;border-left:1px solid #DDD;\">".$ADTab2."</div>
				</div>
			</div>
			".($this->showButtonsBeleg ? "<div style=\"height:40px;\"></div><div id=\"AuftragMessage\"></div><div style=\"padding-right:10px;\" class=\"AuftragBelegContent backgroundColor4\"><div class=\"prettySubtitle\" style=\"\">".T::_("Belege des Auftrags")."</div><div class=\"AuftragBelegContent backgroundColor3\" id=\"AuftragBelegeOperations\" style=\"padding-right:10px;\">".$L."</div></div>" : "").$html.OnEvent::script("if(typeof Auftrag == 'undefined') window.setTimeout(function(){ Auftrag.reWidth(); }, 400); else Auftrag.reWidth();");
	}
	
	public function referenzenToHTML(){
		$data = $this->A("AuftragReferenzen");
		
		if(trim($data) == "")
			$data = "[]";
		
		$j = json_decode($data);
		
		$T = new HTMLTable(3);
		$T->setTableStyle("font-size:12px;");
		$T->setColWidth(3, 20);
		#$T->addColStyle(2, "text-align:right;");
		$T->weight("lightColored");
		$T->useForSelection(false);
		
		#$Users = Users::getUsersArray(null, false, [0, 2]);

		
		foreach($j AS $k => $e){
			$B = new Button("Eintrag löschen", "trash_stroke", "iconic");
			$B->doBefore("if(!confirm('Eintrag löschen?')) return; %AFTER");
			$B->rmePCR("Auftrag", $this->getID(), "referenzenDeleteEntry", [$k], OnEvent::rme($this, "referenzenToHTML", [], "function(t){ \$j('#AuftragReferenzen').html(t.responseText); }"));
			#$B->style("font-size:16px;");
			#$K = new Kategorie($e->KID);
			
			
			$T->addRow([
				self::$referenzTypen[$e->type],
				$e->wert,
				$B
			]);
			$T->addCellStyle(4, "padding:0;");
		}
		
		$B = new Button("Referenz hinzufügen", "./images/i2/add.png", "icon");
		$B->style("float:right;");
		$B->contextMenu("Auftrag", $this->getID(), "Referenzen");
		
		$T->addRow([
			"Referenz hinzufügen",
			"",
			$B
		]);
		$T->addRowColspan(1, 2);
		$T->addCellStyle(1, "text-align:left;");
		$T->addCellStyle(4, "padding:0;");
		$T->addRowEvent("click", $B->getAction());

		$html = "<div id=\"AuftragReferenzen\">$T</div>";
		
		return $html;
	}
	
	public function referenzenDeleteEntry($k){
		$j = json_decode($this->A("AuftragReferenzen"));
		
		unset($j[$k]);
		
		$this->changeA("AuftragReferenzen", json_encode(array_values($j)));
		$this->saveMe();
	}
	
	public function referenzenSaveNew($type, $wert){
		if(trim($type) == "null")
			Red::alertD("Bitte wählen Sie einen Typ aus!");
		
		if(trim($wert) == "")
			Red::alertD("Bitte geben Sie einen Wert ein!");
		
		$data = $this->A("AuftragReferenzen");
		if(trim($data) == "")
			$data = "[]";
		
		$j = json_decode($data);
		$n = new stdClass();
		$n->type = $type;
		$n->wert = $wert;
		
		$j[] = $n;
		
		$this->changeA("AuftragReferenzen", json_encode($j));
		$this->saveMe();
	}
	
	public function listEMails(){
		#echo $this->getID();
		$Mail = new mDBMail2ObjectGUI(-1);
		$Mail->setOwner("Auftrag", $this->ID);#
		echo "<div style=\"clear:right;padding-top:60px;\" class=\"prettySubtitle\">E-Mails zu diesem Auftrag</div><div style=\"min-height:300px;\">".$Mail->getTable()."</div>";
		echo OnEvent::script("Auftrag.highlightSection('EMail');Auftrag.reWidth();");
		#$GUIF->addTab($Mail, "Mails", "./lightCRM/Mail/Mail.png");
	}
	
	public function makeToCustomer(){
		$A = new Adresse($this->A("AdresseID"));
		$A->changeA("AuftragID", "-1");
		$A->changeA("type", "default");
		$id = $A->newMe();
		
		$Kunden = new Kunden();
		$KID = $Kunden->createKundeToAdresse($id);
		$K = new Kappendix($KID);
		
		$this->changeA("kundennummer", $K->A("kundennummer"));
		$this->saveMe();
	}
	
	public function alterAdresseButtons(){
		$BAdresse = new Button("Adresse\n".($this->A->AdresseID != 0 ? "neu zuweisen" : "hinzufügen"), "./open3A/Auftraege/lieferAdresse.png", "icon");
		$BAdresse->pop("Adressen", -1, "changeAdressePopup", [0, $this->getID()]);

		return $BAdresse;
	}
	
/*
	public static function renrParser($w,$l,$p){
		$s = HTMLGUI::getArrayFromParametersString($p);
		if($w != "") return "<input type=\"text\" value=\"$w\" id=\"rechnungNummer\" name=\"rechnungNummer\" readonly=\"readonly\" />";
		else return "<input type=\"button\" value=\"Rechnung erstellen\" onclick=\"createRechnung('$s[0]','".$s[1]."');\" />";
	}*/

	public function getAdresseCopy($AdresseID){
		parent::getAdresseCopy($AdresseID);
		echo "Adresse übernommen";
	}

	public function createGRLBM($type, $returnID = false, $belegNummer = false, $referenz = "", $datum = null, $additional = array()){
		echo parent::createGRLBM($type, $returnID, $belegNummer, $referenz, $datum, $additional);
	}

	function getGRLBMPDF($copy, $pdf = null, $GRLBMID = null, $print = false, $subBeleg = null, $isPreview = false){
		try {
			Aspect::joinPoint("checks", $this, __METHOD__, array($copy, $GRLBMID));
			
			if($GRLBMID == null)
				throw new Exception("No GRLBM ID given in ".__FILE__." in method ".__METHOD__);

			if($pdf == "") 
				$pdf = "";
			
			$brief = $this->getLetter("", $copy == "true" ? true : false, $GRLBMID, $print, $subBeleg, $isPreview);
			if(Util::usePDFViewer() AND $pdf == null){
				$filename = $brief->generate(true, $pdf);
				Util::PDFViewer($filename);
			} else 
				$brief->generate(false, $pdf);
			
			if($print){
				$G = new GRLBM($GRLBMID, false);
				$G->markMeAsPrinted($copy == "true");
				#$G->changeA("isPrinted".($copy == "true" ? "Copy" : ""), "1");
				#$G->changeA("isPrinted".($copy == "true" ? "Copy" : "")."Time", time());
				#$G->saveMe(true, false, false);
				
				#if(Session::isPluginLoaded("mNextcloudUser")){
				#	$NU = NextcloudUser::getUser();
				#	if($NU AND $NU->A("NextcloudUserAutoupload"))
				#		$NU->getFileForUpload("Auftrag", $this->getID(), $GRLBMID, true);
				#}
			}
			
		} catch(TableDoesNotExistException $e){
			Util::alienAutloaderUnload();
			$S = new SupportGUI();
			echo Util::getBasicHTMLError($S->fatalError("Table '".$e->getTable()."' not found!\n\n".$e->getTraceAsString(), "", true, true), "Es ist ein Fehler aufgetreten!");
			#echo Util::getBasicHTMLError("<p class=\"error\" style=\"font-size:15px;font-weight:bold;\">".get_class($e).": ".$e->getTable()."</p>", "Es ist ein Fehler aufgetreten!");
		}  catch(ClassNotFoundException $e){
			Util::alienAutloaderUnload();
			$S = new SupportGUI();
			echo Util::getBasicHTMLError($S->fatalError("Field '".$e->getClassName()."' not found!\n\n".$e->getTraceAsString(), "", true, true), "Es ist ein Fehler aufgetreten!");
		} catch (Exception $e){
			Util::alienAutloaderUnload();
			$S = new SupportGUI();
			echo Util::getBasicHTMLError($S->fatalError($e->getMessage()."\n\n".$e->getTraceAsString(), "", true, true), "Es ist ein Fehler aufgetreten!");
			
			#echo Util::getBasicHTMLError("<p class=\"error\" style=\"font-size:15px;font-weight:bold;\">".get_class($e).": ".$e->getMessage()."</p>", "Es ist ein Fehler aufgetreten!");
		}
	}

	function getGRLBMPDFPreview($copy, $pdf = null, $GRLBMID = null){
		if($GRLBMID == null)
			throw new Exception("No GRLBM ID given in ".__FILE__." in method ".__METHOD__);

		if($pdf == "") $pdf = "";

		$brief = $this->getLetter("", $copy == "true" ? true : false, $GRLBMID);
		$brief->generate(false, $pdf);
	}

	public static function getEMailTBs(Adresse $A, Stammdaten $Stammdaten, GRLBM $GRLBM, $die = true){
		$alteredA = Aspect::joinPoint("alterAdresse", __CLASS__, __METHOD__, array($A, $GRLBM), $A);
		#if($alteredA != null) $A = $alteredA;
		
		//removed in 1.6 but still required for automatic recovery [06.11.2011]
		$T = new Textbausteine();
		list($k, $v) = $T->getTBs("emailBetreff", $GRLBM->getMyPrefix(), true, $Stammdaten->getID());
		$betreff = isset($k[0]) ? $k[0] : null;
		
		
		$T = new Textbausteine();
		list($k, $v) = $T->getTBs("emailText", $GRLBM->getMyPrefix(), true, $Stammdaten->getID());
		$text = isset($k[0]) ? $k[0] : null;

		$rechnungsdatum = $GRLBM->A("datum");
		$gesamtsumme = $GRLBM->A("bruttobetrag")*1;
		if($GRLBM->getMyPrefix() == "M"){
			$T = new Textbausteine();
			list($k, $v) = $T->getTBs("emailMahnung".$GRLBM->A("nummer"), "", true, $Stammdaten->getID());
			if(isset($k[0]))
				$text = $k[0];
			
			$G = new GRLBM($GRLBM->A("AuftragID"), false);
			$rechnungsdatum = Util::CLDateParser($G->A("datum"));
			
			
			$AC = anyC::get("GRLBM", "AuftragID", $GRLBM->A("AuftragID"));
			$AC->addAssocV3("isM", "=", "1");
			$AC->setFieldsV3(array("SUM(gebuehren) AS gesamt"));
			$T = $AC->n();
			$gebuehren = 0;
			if($T)
				$gebuehren = $T->A("gesamt");
			
			$gesamtsumme += $gebuehren;
		}
		
		if($text == null)
			$text = -1;
		
	    $replace = array(
			"{Firmenname}",
			"{Vorname}",
			"{Nachname}",
			"{Benutzername}",
			"{BenutzerPosition}",
			"{BenutzerTelefon}",
			"{Anrede}",
			"{Rechnungsdatum}",
			"{Belegdatum}",
			"{Lieferdatum}",
			"{Belegnummer}",
			"{Gesamtsumme}",
			"{+1Woche}",
			"{+2Wochen}",
			"{+3Wochen}",
			"{+1Monat}",
			"{ProjektName}",
			"{BelegMonatText}",
			"{BelegJahr}");
		
		$date = Util::CLDateParser($GRLBM->A("datum"), "store");
		if($date == -1) $date = $GRLBM->A("datum");
		
		$D = new Datum($date);
		$D->addMonth();
		
		$lang = "de";
		if($A->A("AdresseSpracheID") AND Session::isPluginLoaded("mSprache")){
			$S = new Sprache($A->A("AdresseSpracheID"));
			$lang = $S->A("SpracheSprache");
		}
		
		$projektName = "";
		if(Session::isPluginLoaded("mProjekt")){
			$Auftrag = new Auftrag($GRLBM->A("AuftragID"));
			if($Auftrag->A("ProjektID")){
				$P = new Projekt($Auftrag->A("ProjektID"));
				$projektName = $P->A("ProjektName");
			}
		}
		
		$replaceWith = array(
			$Stammdaten->A("firmaLang"),
			$A->A("vorname"),
			$A->A("nachname"),
			Session::currentUser()->A("name"),
			Session::currentUser()->A("UserPosition"),
			Session::currentUser()->A("UserTel"),
			Util::formatAnrede($lang, $A),
			$rechnungsdatum,
			$GRLBM->hasParsers ? $GRLBM->A("datum") : Util::CLDateParser($GRLBM->A("datum")),
			$GRLBM->hasParsers ? $GRLBM->A("lieferDatum") : Util::CLDateParser($GRLBM->A("lieferDatum")),
			$GRLBM->A("prefix").$GRLBM->A("nummer").(($GRLBM->A("GRLBMVersion") AND $GRLBM->A("isA")) ? "-".$GRLBM->A("GRLBMVersion") : ""),
			Util::CLFormatCurrency($gesamtsumme, true),
			Util::CLDateParser($date + 7 * 3600 * 24),
			Util::CLDateParser($date + 14 * 3600 * 24),
			Util::CLDateParser($date + 21 * 3600 * 24),
			Util::CLDateParser($D->time()),
			$projektName,
			Util::CLMonthName(date("m", $date)),
			date("Y", $date)
		);
		
		
	    $T = new Textbaustein($text);
	    
		if($betreff != null AND $T->A("betreff") == ""){//fix removal of TB type "E-Mail Betreff"
			$TBetreff = new Textbaustein($betreff);
			$T->changeA("betreff", $TBetreff->A("text"));
			$T->saveMe(true, false);
			
			$TBetreff->deleteMe();
		}
		
		$T = Aspect::joinPoint("alterTB", __CLASS__, __METHOD__, array($T, $GRLBM, $A, $lang), $T);
		
		$Subject = $T->A("betreff");
		$Body    = $T->A("text");
		
		if(Session::isPluginLoaded("mMultiLanguage") AND $A->A("AdresseSpracheID") > 0){
			$S = new Sprache($A->A("AdresseSpracheID"));
			$TText = MultiLanguage::getTranslationL($S->A("SpracheSprache"), "Textbaustein", $T->getID(), "text");
			if($TText)
				$Body = $TText;
			
			$TSubject = MultiLanguage::getTranslationL($S->A("SpracheSprache"), "Textbaustein", $T->getID(), "betreff");
			if($TSubject)
				$Subject = $TSubject;
		}
		
		if(preg_match_all("/{\+([0-9]+)Tage}/", $Body, $regs))
			foreach($regs[1] AS $mv)
				$Body = str_replace("{+{$mv}Tage}", Util::CLDateParser($date + $mv * 3600 * 24), $Body);
			
		
	    if($GRLBM->getMyPrefix() != "M"){
			$Subject = str_ireplace(array("{Rechnungsnummer}", "{Belegnummer}"), $GRLBM->A("prefix").$GRLBM->A("nummer").(($GRLBM->A("GRLBMVersion") AND $GRLBM->A("isA")) ? "-".$GRLBM->A("GRLBMVersion") : ""), $Subject."");
			$Body    = str_ireplace(array("{Rechnungsnummer}", "{Belegnummer}"), $GRLBM->A("prefix").$GRLBM->A("nummer").(($GRLBM->A("GRLBMVersion") AND $GRLBM->A("isA")) ? "-".$GRLBM->A("GRLBMVersion") : ""), $Body);
		} else {
			$GRLBMOrig = new GRLBM($GRLBM->A("AuftragID"));
			
			$Subject = str_ireplace("{Rechnungsnummer}", $GRLBMOrig->A("prefix").$GRLBMOrig->A("nummer"), $Subject);
			$Body    = str_ireplace("{Rechnungsnummer}", $GRLBMOrig->A("prefix").$GRLBMOrig->A("nummer"), $Body);
			
			$replaceWith[5] = $GRLBMOrig->A("datum");
			
			if($GRLBMOrig->A("nummer") > 1){
				$AC = anyC::get("GRLBM", "isM", "1");
				$AC->addAssocV3("AuftragID", "=", $GRLBM->A("AuftragID"));
				$AC->addAssocV3("nummer", "=", "1");
				$M1 = $AC->n();
				if($M1){
					$Subject = str_ireplace("{1.Mahnungsdatum}", Util::CLDateParser($M1->A("datum")), $Subject);
					$Body    = str_ireplace("{1.Mahnungsdatum}", Util::CLDateParser($M1->A("datum")), $Body);
				}
			}
			
			if($GRLBMOrig->A("nummer") > 2){
				$AC = anyC::get("GRLBM", "isM", "1");
				$AC->addAssocV3("AuftragID", "=", $GRLBM->A("AuftragID"));
				$AC->addAssocV3("nummer", "=", "2");
				$M2 = $AC->n();
				if($M2){
					$Subject = str_ireplace("{2.Mahnungsdatum}", Util::CLDateParser($M2->A("datum")), $Subject);
					$Body    = str_ireplace("{2.Mahnungsdatum}", Util::CLDateParser($M2->A("datum")), $Body);
				}
			}
			
			
			$Subject = str_ireplace("{Belegnummer}", $GRLBM->A("prefix").$GRLBMOrig->A("nummer")."/".$GRLBM->A("nummer"), $Subject);
			$Body    = str_ireplace("{Belegnummer}", $GRLBM->A("prefix").$GRLBMOrig->A("nummer")."/".$GRLBM->A("nummer"), $Body);
		}
		
		$Subject = str_ireplace($replace, $replaceWith, $Subject);		
	    $Body    = str_ireplace($replace, $replaceWith, $Body);
		
		
		if(Session::isPluginLoaded("mMicropayment")){
			$Body = Micropayment::replace(
				$Body, "Rechnung ".$GRLBM->A("prefix").$GRLBM->A("nummer"),
				$GRLBM->A("bruttobetrag") * 100,
				"Gesamt-Betrag gem. Rechnung ".$GRLBM->A("prefix").$GRLBM->A("nummer"));
		}
		
		#$Subject = str_replace(array("{Rechnungsdatum}","{Belegdatum}"), $GRLBM->A("datum"), $Subject);
		#$Body    = str_replace(array("{Rechnungsdatum}","{Belegdatum}"), $GRLBM->A("datum"), $Body);
	    
		
		$Subject = Aspect::joinPoint("alterSubject", null, __METHOD__, array($A, $Subject, $GRLBM), $Subject);
		$Body = Aspect::joinPoint("alterBody", null, __METHOD__, array($A, $Body, $Stammdaten, $GRLBM), $Body);
		
		return array($Subject, $Body);
	}

	public static function getEMailSender($Stammdaten = null, ?GRLBM $GRLBM = null, $die = true){
		if($Stammdaten == null) 
			$Stammdaten = mStammdaten::getActiveStammdaten();

		#$ud = new mUserdata();
		#$sender = $ud->getUDValue("sendBelegViaEmailSender", "firm");
		[$from, $fromName] = $Stammdaten->getEMailAbsender($GRLBM);
		#if($sender == "firm") {
		#	$from = $Stammdaten->A("email");
		#	$fromName = str_replace(",", "", $Stammdaten->A("firmaLang"));
		#}
		#if($sender == "user") {
		#	$from = $_SESSION["S"]->getCurrentUser()->A("UserEmail");
		#	$fromName = $_SESSION["S"]->getCurrentUser()->A("name");
		#}

		$fromName = Aspect::joinPoint("senderName", __CLASS__, __METHOD__, array($fromName, $Stammdaten), $fromName);
		$from = Aspect::joinPoint("senderAddress", __CLASS__, __METHOD__, array($from, $Stammdaten), $from);
		
		if(defined("PHYNX_GLOBAL_CRON"))
			syslog(LOG_INFO, "Sending emails from $fromName<$from>");
		
		if(trim($from) == ""){
			if($die) 
				Red::errorD ("Bitte überprüfen Sie die Absender-Adressen in den Stammdaten");
			else 
				throw new Exception("E-Mail: Please check the firms e-mail address in the Stammdaten");
		}
		#if($_SESSION["S"]->getCurrentUser()->getA()->UserEmail == "" AND $sender == "user"){
		#	if($die)
		#		Red::errorD ("Bitte überprüfen Sie die Absender-Adresse des Benutzers und in den Stammdaten");
		#	else
		#		throw new Exception("E-Mail: Please check the users e-mail address");
		#}

		return array($fromName, $from);
	}

	function getViaEMailWindow($GRLBMID, $sendVia = "E-Mail", $AnsprechpartnerID = "0"){
		T::load(__DIR__, "Auftraege");
		$G = new GRLBM($GRLBMID);
		$AnAdresse = new Adresse($this->A("AdresseID"));


		$Recipients = array();
		$Recipients[0] = array(
			$AnAdresse->A("firma") != "" ? $AnAdresse->A("firma") : $AnAdresse->A("vorname")." ".$AnAdresse->A("nachname"),
			$AnAdresse->A("email"),
			T::_("Firmenadresse"));
		
		if($AnAdresse->A("email2"))
			$Recipients[-2] = array(($AnAdresse->A("firma") != "" ? $AnAdresse->A("firma") : $AnAdresse->A("vorname")." ".$AnAdresse->A("nachname"))." (privat)",
			$AnAdresse->A("email2"),
			"Privat");
		
		if($this->A("AdresseIDOriginal")){
			$OriginalAdresse = new Adresse($this->A("AdresseIDOriginal"));
			if($AnAdresse->A("email") != $OriginalAdresse->A("email")){
				$Recipients[-3] = array(
					$OriginalAdresse->A("firma") != "" ? $OriginalAdresse->A("firma") : $OriginalAdresse->A("vorname")." ".$OriginalAdresse->A("nachname"),
					$OriginalAdresse->A("email"),
					T::_("Neue E-Mail"));
			}
		}
		
		if(Session::isPluginLoaded("mAnsprechpartner")){
			$ASPs = null;
			if($this->A("kundennummer") > 0)
				$ASPs = Ansprechpartner::getAllAnsprechpartner($this->A("kundennummer"), $this->A("AuftragAdresseNiederlassungID"));
			if($this->A("lieferantennummer") > 0)
				$ASPs = Ansprechpartner::getAllAnsprechpartnerTo("Lieferant", $this->A("lieferantennummer"));
			
			if($ASPs)
				while($ASP = $ASPs->getNextEntry()){

					$name = trim($ASP->A("AnsprechpartnerVorname")." ".$ASP->A("AnsprechpartnerNachname"));
					if($name == "")
						$name = $ASP->A("AnsprechpartnerPosition");

					$belegarten = [];
					if($ASP->A("AnsprechpartnerGetsR"))
						$belegarten[] = "Rechnungen";
					if($ASP->A("AnsprechpartnerGetsL"))
						$belegarten[] = "Lieferscheine";
					if($ASP->A("AnsprechpartnerGetsA"))
						$belegarten[] = "Angebote";
					if($ASP->A("AnsprechpartnerGetsB"))
						$belegarten[] = "Bestätigungen";
					
					$Recipients[$ASP->getID()] = array(
						$name,
						$ASP->A("AnsprechpartnerEmail"),
						count($belegarten) ? "Ansprechpartner für ". implode(", ", $belegarten) : "");
				}
			
			if($AnsprechpartnerID != "0"){
				$ARecipient = new Ansprechpartner($AnsprechpartnerID);

				$AnAdresse->changeA("vorname", $ARecipient->A("AnsprechpartnerVorname"));
				$AnAdresse->changeA("nachname", $ARecipient->A("AnsprechpartnerNachname"));
				$AnAdresse->changeA("anrede", $ARecipient->A("AnsprechpartnerAnrede"));
				$AnAdresse->changeA("email", $ARecipient->A("AnsprechpartnerEmail"));
				$AnAdresse->changeA("titelPrefix", $ARecipient->A("AnsprechpartnerTitel"));
				$AnAdresse->changeA("titelSuffix", $ARecipient->A("AnsprechpartnerTitelSuffix"));
			}
		}
		
		if(Session::isPluginLoaded("Kunden") AND Kappendix::getKappendixToKundennummer($this->A("kundennummer"))){
			$K = Kappendix::getKappendixToKundennummer($this->A("kundennummer"));
			if($K->A("KappendixProvisionUserID") > 0){
				$User = new User($K->A("KappendixProvisionUserID"));
				#if($User->A("UserEmail") != "")
				$Recipients[-4] = [$User->A("name"), $User->A("UserEmail"), "Provisionsempfänger"];
			}
		}
		
		$Empfaenger = array();
		$CCEmpfaenger = array(-1 => "Nicht verwenden");
		foreach($Recipients AS $k => $R){
			$Empfaenger[$k] = $R[0]." &lt;$R[1]&gt;";
			$CCEmpfaenger[$R[1]] = $R[0]." &lt;$R[1]&gt;";
		}
		
		$Empfaenger[-1] = T::_("Anderer Empfänger");
		$CCEmpfaenger[-2] = T::_("Anderer Empfänger");
		
		$IR = new HTMLInput("EMailRecipientSelection", "select", $AnsprechpartnerID, $Empfaenger);
		$IR->onchange("if(this.value != '-1') Auftrag.windowMail(".$this->getID().", '$GRLBMID', '$sendVia', this.value); else { \$j('[name=otherRecipient]').show(); \$j('#regularRecipient').hide(); }");
		#if(count($Empfaenger) == 1)
		#	$IR = $Empfaenger[0];
		
		$BP0 = new Button("Empfänger hinzufügen", "./images/i2/add.png", "icon");
		$BP0->style("float:right;margin-top:5px;");
		$BP0->onclick("\$j('#EMailCC1Row').toggle();");
		if($sendVia != "E-Mail")
			$BP0 = "";
		
		$BP1 = new Button("Empfänger hinzufügen", "./images/i2/add.png", "icon");
		$BP1->style("float:right;margin-top:5px;");
		$BP1->onclick("\$j('#EMailCC2Row').toggle();");
				
		$Stammdaten = new Stammdaten($this->A("AuftragStammdatenID"));#mStammdaten::getActiveStammdaten();
		if($this->A("AuftragStammdatenID") == 0)
			$Stammdaten = mStammdaten::getActiveStammdaten();
		
		list($Subject, $Body) = AuftragGUI::getEMailTBs($AnAdresse, $Stammdaten, $G);
		list($fromName, $from) = AuftragGUI::getEMailSender($Stammdaten, $G);
		$recipient = $Recipients[$AnsprechpartnerID][1];
		
		$IO = new HTMLInput("otherRecipient", "text");
		$IO->style(($AnsprechpartnerID != -1 ? "display:none;" : "")."margin-top:5px;");
		$IO->placeholder("E-Mail-Adresse");
		
		$IS = new HTMLInput("EMailSubject", "text", $Subject);
		$IS->id("EMailSubject$this->ID");
		
		$IB = new HTMLInput("EMailBody", "textarea", $Body);
		$IB->id("EMailBody$this->ID");
		$IB->setClass("tinyMCEEditor");
		$IB->style("width:100%;height:300px;font-size:10px;");
		
		Aspect::joinPoint("inputs", $this, __METHOD__, [$IR, $IO, $IS, $IB, $G]);
		
		$tab = new HTMLTable(2);
		$tab->setTableStyle("table-layout: fixed;");
		$tab->setColWidth(1, "120px;");
		$tab->addLV(T::_("Absender").":", "$fromName &lt;$from&gt;");
		$tab->addLV(T::_("Empfänger").":", $BP0.$IR."<br>$IO<div id=\"regularRecipient\"><small style=\"color:grey;\">$recipient<br>".$Recipients[$AnsprechpartnerID][2]."</small></div>");
		$tab->setTableID("auftraegeEmailTable");
		
		$IOCC1 = new HTMLInput("otherRecipientCC1", "text");
		$IOCC1->style("display:none;margin-top:5px;");
		$IOCC1->placeholder("E-Mail-Adresse");
		
		$IOCC2 = new HTMLInput("otherRecipientCC2", "text");
		$IOCC2->style("display:none;margin-top:5px;");
		$IOCC2->placeholder("E-Mail-Adresse");
		
		$CC1 = new HTMLInput("EMailCC1$this->ID", "select", -1, $CCEmpfaenger);
		$CC1->onchange("if(this.value != '-2') \$j('[name=otherRecipientCC1]').hide(); else \$j('[name=otherRecipientCC1]').show();");
		
		$CC2 = new HTMLInput("EMailCC2$this->ID", "select", -1, $CCEmpfaenger);
		$CC2->onchange("if(this.value != '-2') \$j('[name=otherRecipientCC2]').hide(); else \$j('[name=otherRecipientCC2]').show();");
		
		$tab->addLV("CC:", $BP1.$CC1.$IOCC1);
		$tab->addRowStyle("display:none;");
		$tab->setRowID("EMailCC1Row");
		
		$tab->addLV("CC:", $CC2.$IOCC2);
		$tab->addRowStyle("display:none;");
		$tab->setRowID("EMailCC2Row");
		
		$ud = new mUserdata();
		if($_SESSION["S"]->getCurrentUser()->A("UserEmail") != "" AND $ud->getUDValue("BCCToUser", "false") == "true" AND trim($Stammdaten->A("alwaysBcc")) == "")
			$tab->addLV("BCC:",$_SESSION["S"]->getCurrentUser()->A("UserEmail"));

		if($Stammdaten->A("alwaysBcc") != ""){
			$tab->addLV("BCC:",$Stammdaten->A("alwaysBcc"));
			$tab->addCellStyle(2, "overflow: hidden;text-overflow: ellipsis;white-space: nowrap;");
		}
		
		if($Stammdaten->A("alwaysBccR") AND in_array($G->getMyPrefix(), ["R", "T", "G"])){
			$tab->addLV("BCC:",$Stammdaten->A("alwaysBccR"));
			$tab->addCellStyle(2, "overflow: hidden;text-overflow: ellipsis;white-space: nowrap;");
		}
		
		$tab->addLV(T::_("Betreff").":", $IS);
		
		$tab->addRow(array($IB));
		$tab->addRowColspan(1, 2);
		$tab->addRowClass("backgroundColor0");

		$BAbort = new Button("Abbrechen","stop");
		$BAbort->onclick(OnEvent::closePopup("Auftrag"));

		$BGo = new Button("E-Mail\nsenden","okCatch");
		$BGo->style("float:right;");
		$BGo->loading();
		if($sendVia == "E-Mail")
			$BGo->onclick((strpos($Body, "<p") !== false ? "\$j('#EMailBody$this->ID').val(tinyMCE.get('EMailBody$this->ID').getContent());" : "")." Auftrag.directMail('$this->ID', $GRLBMID, '$recipient', $('EMailSubject$this->ID').value, \$j('#EMailBody$this->ID').val(), \$j('#mailAttachments input:checked').serialize(), \$j('[name=otherRecipient]').val(), \$j('[name=EMailCC1$this->ID]').val(), \$j('[name=EMailCC2$this->ID]').val(), 0, \$j('[name=otherRecipientCC1]').val(), \$j('[name=otherRecipientCC2]').val()); ".OnEvent::closePopup("Auftrag"));
		if($sendVia == "sign")
			$BGo->onclick((strpos($Body, "<p") !== false ? "\$j('#EMailBody$this->ID').val(tinyMCE.get('EMailBody$this->ID').getContent());" : "")." Auftrag.plSign('$this->ID', $GRLBMID, '$recipient', $('EMailSubject$this->ID').value, \$j('#EMailBody$this->ID').val(), \$j('[name=otherRecipient]').val()); ".OnEvent::closePopup("Auftrag"));

		#$BDL = "";
		/*if($sendVia == "E-Mail"){
			$BDL = new Button("E-Mail herunterladen", "download", "iconicL");
			$BDL->style("float:right;margin-right:5px;margin-top:5px;");
			$BDL->onclick((strpos($Body, "<p") !== false ? "\$j('#EMailBody$this->ID').val(tinyMCE.get('EMailBody$this->ID').getContent());" : "")." Auftrag.directMail('$this->ID', $GRLBMID, '$recipient', $('EMailSubject$this->ID').value, \$j('#EMailBody$this->ID').val(), \$j('#mailAttachments input:checked').serialize(), \$j('[name=otherRecipient]').val(), \$j('[name=EMailCC1$this->ID]').val(), \$j('[name=EMailCC2$this->ID]').val(), 1); ".OnEvent::closePopup("Auftrag"));
		}*/
		
		Aspect::joinPoint("buttons", $this, __METHOD__, array($BGo, $BAbort));
		
		$tab->addRow(array($BGo.$BAbort));
		$tab->addRowColspan(1, 2);

		echo "<div style=\"display:flex;\">";
		
		echo "<div style=\"width:400px;display:inline-block;vertical-align:top;\">$tab</div>";
		
		if(strpos($Body, "<p") !== false)
			echo OnEvent::script("
				setTimeout(function(){
				".tinyMCEGUI::editorMail ("EMailBody$this->ID", null, "undo redo | pastetext | bold italic underline | fullscreen code")."
			}, 100);");
		
		
		
		$T = new HTMLTable(3, T::_("Anhänge"));
		$T->setTableStyle("table-layout:fixed;width:180px;");
		$T->setTableID("mailAttachments");
		$T->weight("light");
		$T->setColWidth(1, 20);
		$T->setColWidth(3, 20);
		#$T->maxHeight(400);
		$B = new Button("PDF", "./images/i2/pdf.gif", "icon");
		$G = new GRLBM($GRLBMID);
		$nummer = $G->A("nummer");
		if($G->getMyPrefix() == "M"){
			$refG = new GRLBM($G->A("AuftragID"));
			$nummer = $refG->A("nummer")."-".$nummer;
		}
			
		$version = "";
		try {
			$t = new CustomizerBelegVersionGUI();
			$version = (($G->A("GRLBMVersion") AND in_array($G->getMyPrefix(), CustomizerBelegVersionGUI::$belegarten)) ? "-".$G->A("GRLBMVersion") : "");
		} catch (ClassNotFoundException $ex) {}
		
		$T->addRow(array($B, $G->A("prefix").$nummer.$version));
		
		if($sendVia == "E-Mail"){
			$AC = anyC::get("GRLBM");
			$AC->addAssocV3("AuftragID", "=", $this->getID(), "AND", "1");
			$AC->addAssocV3("GRLBMID", "!=", $GRLBMID, "AND", "1");
			$AC->addAssocV3("isM", "=", "0", "AND", "1");
			
		
			if($G->getMyPrefix() == "O"){
				$AB = anyC::getFirst("GRLBM", "GRLBMOrderGRLBMIDs", ",$GRLBMID,");
				if($AB){
					$AC->addAssocV3("AuftragID", "=", $AB->A("AuftragID"), "OR", "2");
					$AC->addAssocV3("isM", "=", "0", "AND", "2");
				}
			}
			
			while($G2 = $AC->n()){
				$included = 0;
				if($G->getMyPrefix() == "M" AND mUserdata::getUDValueS("sendBelegViaEmailAttachInvoice", "false") == "true" AND $G2->getID() == $G->A("AuftragID"))
					$included = 1;
				
				$I = new HTMLInput("attach_".$G2->getID(), "checkbox", $included);
				if($included)
					$I->isDisabled (true);
				
				Aspect::joinPoint("include", $this, __METHOD__, [$G2, $I]);
				
				$T->addRow(array($B, $G2->A("prefix").$G2->A("nummer").(($G2->A("GRLBMVersion") AND $G2->A("isA")) ? "-".$G2->A("GRLBMVersion") : ""), $I));
			}
		}
		
    	if($sendVia == "E-Mail" AND Session::isPluginLoaded("mFile") AND mUserdata::getUDValueS("sendBelegViaEmailAttachments", "false") == "true"){
			$B = new Button("Datei", "./plugins/Files/File18.png", "icon");
			$D = new mDateiGUI();
			$D->addAssocV3("DateiClassID", "=", $GRLBMID);
			$D->addAssocV3("DateiClass", "=", "GRLBM");
			
			while($f = $D->getNextEntry()){
				$T->addRow(array($B, basename($f->A("DateiPath")), ""));
				
				$T->addCellStyle(2, "word-wrap:break-word");
			}
			
			#$attachmentsDir = FileStorage::getFilesDir()."GRLBMID".str_pad($GRLBMID, 4, "0", STR_PAD_LEFT);
			$attachmentsDir = FileStorage::getElementDir("GRLBM", $GRLBMID);
			if(file_exists($attachmentsDir)){
				$dir = new DirectoryIterator($attachmentsDir);
				foreach ($dir as $file) {
					if($file->isDot()) continue;
					if($file->isDir()) continue;

					$T->addRow(array($B, $file->getFilename(), ""));
					
					$T->addCellStyle(2, "word-wrap:break-word");
				}
			}
    	}
		
		Aspect::joinPoint("attachments", $this, __METHOD__, array($T));
		
		echo "<div style=\"flex:1;overflow:auto;width:100%;display:inline-block;vertical-align:top;max-height:450px;\" id=\"auftraegeAttachmentsTable\">$T</div>";
		echo "</div>".OnEvent::script("window.setTimeout(function(){\$j('#auftraegeAttachmentsTable').css('max-height', \$j('#auftraegeEmailTable').height()+'px');}, 100);");
	}
	
	static function getNextNumber($t){
		return parent::getNextNumber($t);
	}
	
	public function getMyStammdaten(){
		return parent::getMyStammdaten();
	}

	public function saveMultiEditField($field,$value){
		parent::saveMultiEditField($field,$value);
		Red::messageD("Änderung gespeichert");
	}

	public function getContextMenuHTML($identifier) {
		$I = new HTMLInput("type", "select", "0", self::$referenzTypen);
		$I->size(3);
		$I->style("width:100%;");
		echo "<div style=\"font-weight:bold;padding:5px;\" class=\"backgroundColor2\">Typ:</div>".$I;
		
		$IW = new HTMLInput("wert", "text");
		$IW->style("width:100%;text-align:right;");
		echo "<div style=\"font-weight:bold;padding:5px;\" class=\"backgroundColor2\">Wert:</div>".$IW;
		
		
		$B = new Button("Hinzufügen", "gutschrift");
		$B->style("margin:5px;float:right;");
		$B->rmePCR("Auftrag", $identifier, "referenzenSaveNew", ["\$j('[name=type]').val()", "\$j('[name=wert]').val()"], OnEvent::closeContext().OnEvent::rme(new Auftrag($identifier), "referenzenToHTML", [], "function(t){ \$j('#AuftragReferenzen').html(t.responseText); }"));
		echo $B;
	}
}
?>