/*
 *
 *  This file is part of phynx.

 *  phynx is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  phynx is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2025, open3A GmbH - Support@open3A.de
 */

 
var Overlay = {
	isInit: false,
	white: false,
	loginBox: false,
	initWhite: false,
	dark: false,
	blocked: false,
	
	init: function(){
		$j(window).resize(Overlay.fit);
		
		Overlay.isInit = true;
		Overlay.fit();
		//new Effect.Appear($('lightOverlay'), {duration: 0.5});
		$j('#lightOverlay').fadeIn(500);
		Overlay.initWhite = true;
		
		setTimeout("$('container').style.display = 'block'", 500);
	},
	
	show: function(isReLogin = false){
		userControl.isReLogin = isReLogin; 
		
		if(!Overlay.loginBox) {
			$j('#boxInOverlay').fadeIn(200);
			//new Effect.Appear("boxInOverlay", {duration: 0.2});
			Overlay.loginBox = true;
			
			setTimeout("$('loginUsername').focus()",300);
			var data = $j.jStorage.get('phynxUserData', null);
			//var data = cookieManager.getCookie('userLoginData');
			if(data != null) {
				//data = data.split(":");
				$j('#loginUsername').val(data.username);
				$j('#loginPassword').val(";;cookieData;;");
				$j('#loginSHAPassword').val(data.password);
				$j('#saveLoginData').prop("checked", true);
				
				if(typeof Util.querySt('application') == 'undefined')
					$j('#anwendung').val(data.application);
				
				$j('#doAutoLogin').prop("checked", data.autologin);
				
				$j('#doAutoLoginContainer').fadeIn();
				
				if(data.autologin)
					userControl.autoLogin();
			} else
				$j('#doAutoLoginContainer').fadeOut();
			
			if(!$j.jStorage.storageAvailable())
				$j('#saveLoginDataContainer').hide();
		}
		if(!Overlay.white && !Overlay.initWhite) {
			$j('#lightOverlay').fadeIn(500);
			//new Effect.Appear($('lightOverlay'), {duration: 0.5});
			Overlay.white = true;
			$j('#windows').hide();
			
			if(!isReLogin){
				setTimeout("$('contentLeft').update('')", 600);
				setTimeout("$('contentRight').update('')", 600);
			}			
		}
	},

	block: function(){
		Overlay.blocked = true;
	},

	release: function(){
		Overlay.blocked = false;
	},

	showDark: function(duration, opacityTo){
		if(Overlay.dark) return;
		
		if(typeof duration == "undefined")
			duration = 0.1;
		if(typeof opacityTo == "undefined")
			opacityTo = 0.8;
		
		$j('#darkOverlay').fadeTo(duration * 1000 , opacityTo);
		//new Effect.Appear($('darkOverlay'), {duration: duration, to: opacityTo});
		Overlay.dark = true;
	},

	hideDark: function(duration){
		if(!Overlay.dark) return;

		if(Overlay.blocked) return;

		if(typeof duration == "undefined")
			duration = 0.1;

		$j('#darkOverlay').fadeOut();
		Overlay.dark = false;
	},

	hide: function(){

		if(Overlay.initWhite) {
			setTimeout(function(){
				$j('#lightOverlay').fadeOut();
			},600);
			Overlay.initWhite = false;
		}

		if(Overlay.white) {
			$j('#lightOverlay').fadeOut();
			Overlay.white = false;
		}
		if(Overlay.loginBox) {
			$j('#boxInOverlay').fadeOut();
			$j('#windows').show();
			Overlay.loginBox = false;
		}
	},
	
	fit: function(){
	
		var size = Overlay.getPageSize();
		$('lightOverlay').style.width = size[0]+'px';
		$('lightOverlay').style.height = size[1]+'px';

		$('darkOverlay').style.width = size[0]+'px';
		$('darkOverlay').style.height = size[1]+'px';

		$('boxInOverlay').style.top = "20%";
		$('boxInOverlay').style.left = (size[0]/2 - 200)+"px";
	},
	
    getPageSize: function(windowSize) {
	        
	     var xScroll, yScroll;
		
		if (window.innerHeight && window.scrollMaxY) {	
			xScroll = window.innerWidth + window.scrollMaxX;
			yScroll = window.innerHeight + window.scrollMaxY;
		} else if (document.body.scrollHeight > document.body.offsetHeight){ // all but Explorer Mac
			xScroll = document.body.scrollWidth;
			yScroll = document.body.scrollHeight;
		} else { // Explorer Mac...would also work in Explorer 6 Strict, Mozilla and Safari
			xScroll = document.body.offsetWidth;
			yScroll = document.body.offsetHeight;
		}
		
		var windowWidth, windowHeight;
		
		if (self.innerHeight) {	// all except Explorer
			if(document.documentElement.clientWidth){
				windowWidth = document.documentElement.clientWidth; 
			} else {
				windowWidth = self.innerWidth;
			}
			windowHeight = self.innerHeight;
		} else if (document.documentElement && document.documentElement.clientHeight) { // Explorer 6 Strict Mode
			windowWidth = document.documentElement.clientWidth;
			windowHeight = document.documentElement.clientHeight;
		} else if (document.body) { // other Explorers
			windowWidth = document.body.clientWidth;
			windowHeight = document.body.clientHeight;
		}	
		
		if(typeof windowSize != "undefined" && windowSize) return [windowWidth,windowHeight];
		
		// for small pages with total height less then height of the viewport
		if(yScroll < windowHeight){
			pageHeight = windowHeight;
		} else { 
			pageHeight = yScroll;
		}
	
		// for small pages with total width less then width of the viewport
		if(xScroll < windowWidth){	
			pageWidth = xScroll;		
		} else {
			pageWidth = windowWidth;
		}

		return [pageWidth,pageHeight];
	}
}

var Util = {
	/*
	 * Kopiert vom phpBB-Forum
	 */
	insert_text: function(text, spaces, inputElement){
		if(!inputElement) return;

		var textarea = inputElement;

		if (spaces) {
			text = ' ' + text + ' ';
		}

		if (!isNaN(textarea.selectionStart)) {
			var sel_start = textarea.selectionStart;
			var sel_end = textarea.selectionEnd;

			Util.mozWrap(textarea, text, '')
			textarea.selectionStart = sel_start + text.length;
			textarea.selectionEnd = sel_end + text.length;
		} else if (textarea.createTextRange && textarea.caretPos) {
			if (baseHeight != textarea.caretPos.boundingHeight) {
				textarea.focus();
				Util.storeCaret(textarea);
			}

			var caret_pos = textarea.caretPos;
			caret_pos.text = caret_pos.text.charAt(caret_pos.text.length - 1) == ' ' ? caret_pos.text + text + ' ' : caret_pos.text + text;
		} else {
			textarea.value = textarea.value + text;
		}

		inputElement.focus();

	},

	/**
	* Insert at Caret position. Code from
	* http://www.faqts.com/knowledge_base/view.phtml/aid/1052/fid/130
	*/
	storeCaret: function(textEl)
	{
		if (textEl.createTextRange)
		{
			textEl.caretPos = document.selection.createRange().duplicate();
		}
	},

	/**
	* From http://www.massless.org/mozedit/
	*/
	mozWrap: function(txtarea, open, close)
	{
		var selLength = txtarea.textLength;
		var selStart = txtarea.selectionStart;
		var selEnd = txtarea.selectionEnd;
		var scrollTop = txtarea.scrollTop;

		if (selEnd == 1 || selEnd == 2)
		{
			selEnd = selLength;
		}

		var s1 = (txtarea.value).substring(0,selStart);
		var s2 = (txtarea.value).substring(selStart, selEnd)
		var s3 = (txtarea.value).substring(selEnd, selLength);

		txtarea.value = s1 + open + s2 + close + s3;
		txtarea.selectionStart = selEnd + open.length + close.length;
		txtarea.selectionEnd = txtarea.selectionStart;
		txtarea.focus();
		txtarea.scrollTop = scrollTop;

		return;
	},

	/*
	Die folgenden drei Funktionen wurden kopiert von kostenlose-javascripts.de
	http://www.kostenlose-javascripts.de/javascripts/verschiedenes/passwortgenerator.html
	*/
	getRandomNum: function(lbound, ubound) {
		return (Math.floor(Math.random() * (ubound - lbound)) + lbound);
	},

	getRandomChar: function(number, lower, upper, other, extra) {
		var numberChars = "0123456789";
		var lowerChars = "abcdefghijklmnopqrstuvwxyz";
		var upperChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		var otherChars = "!@#$*()-_[{]}|;:./";
		var charSet = extra;

		if (number == true)
			charSet += numberChars;

		if (lower == true)
			charSet += lowerChars;

		if (upper == true)
			charSet += upperChars;

		if (other == true)
			charSet += otherChars;

		return charSet.charAt(Util.getRandomNum(0, charSet.length));
	},

	getPassword: function(length, extraChars, firstNumber, firstLower, firstUpper, firstOther, latterNumber, latterLower, latterUpper, latterOther) {
		var rc = "";
		if (length > 0)
			rc = rc + Util.getRandomChar(firstNumber, firstLower, firstUpper, firstOther, extraChars);

		for (var idx = 1; idx < length; ++idx) {
			rc = rc + Util.getRandomChar(latterNumber, latterLower, latterUpper, latterOther, extraChars);
		}

		return rc;
	},
	
	Button: function(label, image, options){
		if(typeof options == "undefined")
			options = {};
		
		if(typeof options.type == "undefined")
			options.type = "bigButton";
	
		var id = "";
		if(options.id)
			id = "id=\""+options.id+"\"";
	
		var style = "";
		if(options.style)
			style = "style=\""+options.style+"\"";
	
		var onclick = "";
		if(options.onclick)
			onclick = "onclick=\""+options.onclick+"\"";
	
		var classes = "";
		if(options["class"])
			classes = "class=\""+options["class"]+"\"";
	
		var html = "";
		
		if(options.type == "icon")
			html = "<img "+id+" "+style+" "+onclick+" "+classes+" src=\""+image+"\" title=\""+label+"\" />";
		
		return html;
	},
	
	hexToRgb: function(hex) {
		var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
		return result ? {
			r: parseInt(result[1], 16),
			g: parseInt(result[2], 16),
			b: parseInt(result[3], 16)
		} : null;
	},

	querySt: function(ji) {
		hu = window.location.search.substring(1);
		gy = hu.split('&');
		for (i=0;i<gy.length;i++) {
			ft = gy[i].split('=');

			if (ft[0] == ji)
				return ft[1];
		}
	}
}